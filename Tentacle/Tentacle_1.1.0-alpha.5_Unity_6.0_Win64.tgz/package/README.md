# Tentacle for Unity

Connect a Unity project to the [Tentacle](https://www.tentacle.live) desktop app:
stream events, chat, viewer properties, custom controls, custom events and OBS
calls, from C# or from the inspector.

Tentacle runs on the streamer's machine and hosts the connection; this package
dials in to it. Nothing in your game opens a listening socket, so there is no
firewall prompt, and several games can be connected at once - a play-mode
session beside a packaged build, for instance.

## Requirements

- Unity 6.0 LTS (6000.0) or newer
- Editor and Windows Standalone, on Mono or IL2CPP
- The Tentacle desktop app, on the same machine

## Getting started

Nothing to configure. Add the package and the plugin connects to a running
Tentacle on its own:

```csharp
using Tentacle;
using UnityEngine;

public sealed class Greeter : MonoBehaviour
{
    private Tentacle_Stream stream;

    private void OnEnable()
    {
        stream = TentacleRuntime.Stream;
        stream.OnChatMessage_Anywhere += HandleChatMessage;
    }

    private void OnDisable()
    {
        // The stream subscribed to, not TentacleRuntime again: when play mode
        // ends the package shuts down before Unity disables components, and
        // touching TentacleRuntime then would start it up again.
        stream.OnChatMessage_Anywhere -= HandleChatMessage;
    }

    private void HandleChatMessage(TclStreamEvent_Anywhere_ChatMessage message, TclViewer viewer)
    {
        Debug.Log(viewer.DisplayName + " said " + message.Text);
    }
}
```

Prefer to wire things up in the scene? Drop a **Tentacle Event Relay** component
on a GameObject and fill in its UnityEvents from the inspector.

The names are the Unreal plugin's, minus Unreal's type prefixes, so what you
know from one carries over to the other.

## What you get

**Stream events.** `TentacleRuntime.Stream` raises `OnChatMessage_Anywhere`,
`OnChatCommand_Anywhere`, `OnFollow_Anywhere`, `OnDonation_Anywhere`,
`OnSubscription_Anywhere`, `OnBan_Anywhere` and the rest, cross-platform where
Twitch and Kick agree. Every Twitch and Kick event kind also has an event of its
own, which hands you that kind already typed:

```csharp
TentacleRuntime.Stream.OnCheer_Twitch += (cheer, viewer) => Debug.Log(cheer.Bits + " bits");
TentacleRuntime.Stream.OnChannelFollowed_Kick += (followed, viewer) => Debug.Log(followed.Follower.Username + " followed");
```

`OnEvent_Anywhere`, `OnEvent_Twitch` and `OnEvent_Kick` carry everything, for
handling many kinds in one place with a type test such as
`e is TclStreamEvent_Twitch_Cheer cheer`.

Every event about a viewer arrives with that viewer, already resolved. A
reconnect's replay is de-duplicated, so a handler never runs twice for one
event.

**Custom controls.** Sliders, switches, colour pickers and buttons the streamer
drives live from Tentacle's panel. Add a `Tentacle > Custom Control (Slider)`
component, set its label and range in the inspector, and wire its UnityEvents
there, or react from code:

```csharp
GetComponent<TclCustomControlComponent_Slider>().OnValueChangedFromApp.AddListener((value, previous) =>
{
    transform.localScale = Vector3.one * value;
});
```

The control appears in Tentacle when the object is enabled and disappears when
it is not. Put one under a `Custom Control (Group)` to file it under a heading.
Values arrive as Unity types - a `Color` for a colour picker, a `Vector3` for a
vector field.

**Viewer properties.** Per-viewer values the streamer defined - scores, levels,
currencies, flags - read and written by name:

```csharp
if (viewer.AddToProperty_Int("Game", "Score", 10, out var score) == TclSetPropertyResult.Success)
{
    Debug.Log("Score is now " + score);
}

if (viewer.GetProperty_Int("Game", "Lives", out var lives) == TclFindPropertyResult.Found)
{
    Debug.Log(lives);
}
```

Writes apply locally at once and reconcile with Tentacle in the background, so a
score updated per kill never waits on a round trip.

**Custom events.** Named events the streamer configured, so the game reacts to a
name and never has to encode the trigger rules:

```csharp
TentacleRuntime.CustomEvents.Subscribe("Spawn Boss", (customEvent, viewer) => SpawnBoss());
```

Or add a `Tentacle > Custom Event Listener` component, list the names, and wire
its **On Triggered** in the inspector. Names are matched case-insensitively
unless you ask for exact matching.

**Chat and OBS.** `TentacleRuntime.Stream.SendChatMessage("gg")` and
`TentacleRuntime.Obs.SetCurrentProgramScene("Ending")`. The game needs no OBS
credentials; Tentacle already holds the connection the streamer configured.

## Settings

Optional. With no asset in the project the defaults apply. To change them,
create one at **Assets > Create > Tentacle > Settings** inside any `Resources`
folder, named `TentacleSettings`: auto-connect, the session label shown in
Tentacle, reconnect backoff, and how much the plugin logs.

## Notes

- Tentacle not running is an ordinary state, never an error. The plugin retries
  with backoff and connects whenever the app comes up.
- Every event fires on the main thread, inside the frame that delivers it, so a
  handler may touch GameObjects freely.
- Entering and leaving play mode repeatedly leaves no orphaned sockets and no
  duplicated sessions in Tentacle.

## Support

Docs and downloads: [tentacle.live](https://www.tentacle.live)
