// Copyright Tentacle. All Rights Reserved.
using System.Collections.Generic;

namespace Tcl
{
    // Mirrors the Unreal plugin's FTclDeduplicator, including its default
    // window of 100 ids.
    /// <summary>
    /// Fixed-size FIFO de-duplicator for message and event ids, remembering the
    /// last 100 by default.
    ///
    /// Tentacle replays recent stream events when a client connects, so without
    /// this a reconnect would re-fire every handler for events the game already
    /// reacted to. The window is a count, not a time span - the replay is
    /// bounded by count, and a time window would need a clock the caller has no
    /// reason to supply.
    ///
    /// Features:
    /// - O(1) membership through a set, with a queue giving the eviction order
    /// - Deliberately not thread-safe: it is only ever touched while draining the
    ///   inbound queue on the engine's main thread
    /// </summary>
    public sealed class TentacleDeduplicator
    {
        // Matches the Unreal plugin.
        /// <summary>Default window: the last 100 ids.</summary>
        public const int DefaultCapacity = 100;

        private readonly HashSet<string> seen;
        private readonly Queue<string> order;
        private readonly int capacity;

        /// <summary>Creates a de-duplicator remembering the last <paramref name="capacity"/> ids.</summary>
        public TentacleDeduplicator(int capacity = DefaultCapacity)
        {
            // A non-positive capacity would either divide by zero below or make
            // every id "new" while still growing the set, so clamp it to one.
            this.capacity = capacity > 0 ? capacity : 1;
            seen = new HashSet<string>();
            order = new Queue<string>();
        }

        /// <summary>How many ids are currently remembered.</summary>
        public int Count
        {
            get { return seen.Count; }
        }

        /// <summary>
        /// Records <paramref name="id"/> and reports whether it is new. A null or
        /// empty id is always treated as new: an event the app failed to identify
        /// must still reach the game rather than being collapsed with every other
        /// unidentified one.
        /// </summary>
        public bool TryAdd(string id)
        {
            if (string.IsNullOrEmpty(id)) return true;
            if (seen.Contains(id)) return false;

            if (order.Count >= capacity)
            {
                seen.Remove(order.Dequeue());
            }

            seen.Add(id);
            order.Enqueue(id);
            return true;
        }

        /// <summary>Forgets every id.</summary>
        public void Clear()
        {
            seen.Clear();
            order.Clear();
        }
    }
}
