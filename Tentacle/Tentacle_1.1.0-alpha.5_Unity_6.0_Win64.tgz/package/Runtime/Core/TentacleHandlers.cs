// Copyright Tentacle. All Rights Reserved.
using System;

namespace Tcl
{
    /// <summary>
    /// Raises the runtime's C# events one subscriber at a time.
    ///
    /// A multicast delegate invoked directly stops at the first subscriber that
    /// throws, so one broken handler in a game would silently starve every
    /// handler subscribed after it. Each subscriber here runs in its own
    /// try/catch instead: a throw is reported and the next subscriber still runs,
    /// and nothing escapes into the pump that raised the event.
    /// </summary>
    internal static class TentacleHandlers
    {
        /// <summary>Raises a no-argument event, isolating each subscriber.</summary>
        public static void Raise(Action handler, string what)
        {
            if (handler == null) return;
            foreach (var subscriber in handler.GetInvocationList())
            {
                try
                {
                    ((Action)subscriber)();
                }
                catch (Exception exception)
                {
                    Report(what, exception);
                }
            }
        }

        /// <summary>Raises a one-argument event, isolating each subscriber.</summary>
        public static void Raise<T>(Action<T> handler, T argument, string what)
        {
            if (handler == null) return;
            foreach (var subscriber in handler.GetInvocationList())
            {
                try
                {
                    ((Action<T>)subscriber)(argument);
                }
                catch (Exception exception)
                {
                    Report(what, exception);
                }
            }
        }

        /// <summary>Raises a two-argument event, isolating each subscriber.</summary>
        public static void Raise<T1, T2>(Action<T1, T2> handler, T1 first, T2 second, string what)
        {
            if (handler == null) return;
            foreach (var subscriber in handler.GetInvocationList())
            {
                try
                {
                    ((Action<T1, T2>)subscriber)(first, second);
                }
                catch (Exception exception)
                {
                    Report(what, exception);
                }
            }
        }

        /// <summary>Raises a three-argument event, isolating each subscriber.</summary>
        public static void Raise<T1, T2, T3>(Action<T1, T2, T3> handler, T1 first, T2 second, T3 third, string what)
        {
            if (handler == null) return;
            foreach (var subscriber in handler.GetInvocationList())
            {
                try
                {
                    ((Action<T1, T2, T3>)subscriber)(first, second, third);
                }
                catch (Exception exception)
                {
                    Report(what, exception);
                }
            }
        }

        /// <summary>Logs a subscriber that threw, naming the kind of handler it was.</summary>
        private static void Report(string what, Exception exception)
        {
            TentacleLog.Error("Tentacle: a " + what + " handler threw: " + exception);
        }
    }
}
