// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // Engine-neutral on purpose: nothing here references UnityEngine, so the
    // whole protocol, cache and dispatch layer is exercised by edit-mode tests
    // with no scene, no play mode, and no socket. The Unity layer is a thin shell
    // that owns an instance and calls Pump.
    /// <summary>
    /// The connection to Tentacle, and everything a game reaches it through.
    ///
    /// Tentacle hosts the engine socket and this dials in, so the client owns the
    /// whole lifecycle: find Tentacle, open the socket, complete the
    /// handshake, and start again with a growing delay whenever any of that
    /// fails. Tentacle is a desktop app the streamer opens and closes at will, so
    /// "not connected" is an ordinary state, never an error.
    ///
    /// In Unity, <c>Tentacle</c> owns one and calls <see cref="Pump"/>
    /// every frame.
    ///
    /// Features:
    /// - Everything that arrives from Tentacle reaches the game inside
    ///   <see cref="Pump"/>, on the caller's thread, so handlers may touch
    ///   engine objects freely
    /// - Reconnect with capped, jittered backoff; both opening the socket and
    ///   the handshake are bounded, so nothing waits on a peer indefinitely
    /// - Registered custom controls are replayed on every new session, because
    ///   Tentacle drops a session's controls the moment its socket closes
    /// - No remote failure escapes: a closed Tentacle, a refused upgrade, a peer
    ///   that never answers or a rejected handshake all resolve to a state
    ///   change and a retry
    /// - Closing or disposing cancels an attempt still in flight, so no socket
    ///   and no receive thread can outlive the client that started them
    /// </summary>
    public sealed class TentacleClient : IDisposable
    {
        /// <summary>Message type of the opening handshake frame.</summary>
        public const string SessionHelloType = "Session_Hello";

        /// <summary>Message type Tentacle answers the handshake with.</summary>
        public const string SessionWelcomeType = TentacleWebSocketTransport.SessionWelcomeType;

        private readonly TentacleClientOptions options;
        private readonly TentacleInboundQueue inbound;
        private readonly ITentacleSocket socket;
        private readonly TentacleHttpClient http;
        private readonly Random jitter = new Random();

        private readonly ConcurrentQueue<Action> deferred = new ConcurrentQueue<Action>();

        /// <summary>
        /// Callers waiting for work queued through <see cref="RunOnPumpAsync"/>,
        /// so disposing can let them go: a disposed client never pumps again.
        /// Guarded by itself, as is <see cref="disposed"/> while this is touched.
        /// </summary>
        private readonly List<TaskCompletionSource<bool>> pumpWaiters = new List<TaskCompletionSource<bool>>();

        private bool wantConnection;
        private bool disposed;
        private Task<bool> connectAttempt;
        private CancellationTokenSource connectCancellation;
        private int consecutiveFailures;
        private double retryAtSeconds;
        private double connectDeadlineSeconds;
        private double handshakeDeadlineSeconds;

        // The counterpart of the Unreal plugin's OnConnectionStatusChanged.
        /// <summary>
        /// Raised when <see cref="ConnectionStatus"/> changes: inside
        /// <see cref="Pump"/>, apart from the change a call to
        /// <see cref="Disconnect"/> makes, which is raised during that call.
        /// </summary>
        public event Action<ConnectionStatus> OnConnectionStatusChanged;

        /// <summary>Where the connection stands.</summary>
        public ConnectionStatus ConnectionStatus { get; private set; }

        /// <summary>
        /// The id Tentacle assigned this session, or empty when not connected.
        /// A new one is issued on every reconnect.
        /// </summary>
        public string SessionId { get; private set; }

        /// <summary>The endpoints the last connection attempt used.</summary>
        public TentacleEndpoints Endpoints { get; private set; }

        /// <summary>Stream events, chat, and the game's own chat messages.</summary>
        public Tentacle_Stream Stream { get; private set; }

        /// <summary>Controls this game puts in Tentacle's custom-controls panel.</summary>
        public Tentacle_CustomControls CustomControls { get; private set; }

        /// <summary>Named events the streamer configured.</summary>
        public Tentacle_CustomEvents CustomEvents { get; private set; }

        /// <summary>OBS requests relayed through Tentacle.</summary>
        public Tentacle_Obs Obs { get; private set; }

        /// <summary>Per-viewer values the streamer defined.</summary>
        public Tentacle_ViewerProperties ViewerProperties { get; private set; }

        /// <summary>Every viewer this session has been told about.</summary>
        public Tentacle_Viewers Viewers { get; private set; }

        /// <summary>Tentacle's chat bot as the streamer configured it, with every command it answers, kept current.</summary>
        public Tentacle_Bot Bot { get; private set; }

        /// <summary>
        /// The generated tRPC client, for procedures this runtime does not wrap.
        /// Its base URL is kept current with the discovered endpoints.
        /// </summary>
        public TentacleHttpClient Http
        {
            get { return http; }
        }

        /// <summary>Creates a client. Nothing connects until <see cref="Connect"/> is called.</summary>
        public TentacleClient(TentacleClientOptions options)
        {
            this.options = options ?? new TentacleClientOptions();
            if (this.options.Identity == null) this.options.Identity = new TentacleEngineIdentity();
            if (this.options.ReconnectPolicy == null) this.options.ReconnectPolicy = new TentacleReconnectPolicy();
            if (this.options.Clock == null) this.options.Clock = TentacleStopwatchClock.Instance;

            SessionId = "";
            ConnectionStatus = ConnectionStatus.Disconnected;
            Endpoints = this.options.Endpoints ?? new TentacleEndpoints();

            inbound = new TentacleInboundQueue(this.options.InboundQueueCapacity);
            http = new TentacleHttpClient(Endpoints.HttpBaseUrl, null, this.options.HttpClient);
            socket = this.options.Socket ?? new TentacleWebSocketTransport();

            ViewerProperties = new Tentacle_ViewerProperties(this);
            Viewers = new Tentacle_Viewers(ViewerProperties);
            Stream = new Tentacle_Stream(this, this.options.StreamDeduplicationWindow);
            CustomControls = new Tentacle_CustomControls(this);
            CustomEvents = new Tentacle_CustomEvents(this);
            Obs = new Tentacle_Obs(this);
            Bot = new Tentacle_Bot();

            SubscribeToSocket();
        }

        /// <summary>
        /// Routes the socket's events onto the inbound queue. All three of these
        /// run on the transport's thread and do nothing but hand the payload
        /// over; interpreting it waits for the next <see cref="Pump"/>.
        /// </summary>
        private void SubscribeToSocket()
        {
            socket.MessageReceived += (type, data) => inbound.EnqueueMessage(type, data);
            socket.Disconnected += reason => inbound.EnqueueNotice(TentacleInboundKind.Closed, reason);
            socket.Faulted += message => inbound.EnqueueNotice(TentacleInboundKind.Faulted, message);
        }

        /// <summary>
        /// Asks the client to hold a connection, retrying until
        /// <see cref="Disconnect"/> is called. Idempotent; the first attempt runs
        /// on the next <see cref="Pump"/>.
        /// </summary>
        public void Connect()
        {
            if (disposed) return;

            string problem;
            if (!options.Identity.IsValid(out problem))
            {
                // Connecting with an invalid hello would be refused by the server
                // on every attempt, which is a retry loop that can never succeed.
                TentacleLog.Error("Tentacle: cannot connect because " + problem);
                return;
            }

            if (wantConnection) return;
            wantConnection = true;
            consecutiveFailures = 0;
            retryAtSeconds = options.Clock.NowSeconds;
        }

        /// <summary>
        /// Stops holding a connection and closes any open session. Safe to call
        /// when already disconnected.
        /// </summary>
        public void Disconnect()
        {
            wantConnection = false;
            CloseSession();
            SetConnectionStatus(ConnectionStatus.Disconnected);
        }

        /// <summary>
        /// Advances the client: delivers everything the socket received, and
        /// drives connection and reconnection timing. Call this once per frame
        /// from the engine's main thread. Every event that comes from Tentacle
        /// fires inside this call.
        /// </summary>
        public void Pump()
        {
            if (disposed) return;

            RunDeferred();
            DrainInbound();
            AdvanceConnection();
        }

        /// <summary>
        /// Runs whatever a background completion asked to happen on this thread.
        ///
        /// A handler that throws is reported and the rest still run: one game
        /// callback must not be able to strand the others.
        /// </summary>
        private void RunDeferred()
        {
            Action work;
            while (deferred.TryDequeue(out work))
            {
                try
                {
                    work();
                }
                catch (Exception exception)
                {
                    TentacleLog.Error("Tentacle: deferred work threw: " + exception);
                }
            }
        }

        /// <summary>
        /// Queues <paramref name="work"/> to run at the start of the next
        /// <see cref="Pump"/>.
        ///
        /// Everything a game reads - the viewer cache, property values - is only
        /// ever touched on the pumping thread. Anything that finishes elsewhere
        /// and needs to change it comes back through here rather than mutating
        /// it where it completed.
        /// </summary>
        internal void Post(Action work)
        {
            if (work == null || disposed) return;
            deferred.Enqueue(work);
        }

        /// <summary>
        /// Queues <paramref name="work"/> for the next <see cref="Pump"/>, like
        /// <see cref="Post"/>, and returns a task that completes once it has run:
        /// true when it ran, false when the client was disposed first.
        ///
        /// For a request whose answer must change what a game reads, and raise
        /// what a game hears, on the pumping thread, while its caller still
        /// awaits the change. Await it; blocking the pumping thread on it would
        /// wait for a Pump that cannot come.
        /// </summary>
        internal Task<bool> RunOnPumpAsync(Action work)
        {
            // Continuations run on the pool, never inline inside the Pump that
            // completes this, so an awaiting caller cannot run inside the frame's
            // dispatch.
            var done = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
            lock (pumpWaiters)
            {
                if (work == null || disposed)
                {
                    done.TrySetResult(false);
                    return done.Task;
                }
                pumpWaiters.Add(done);
            }

            deferred.Enqueue(() =>
            {
                lock (pumpWaiters) pumpWaiters.Remove(done);
                try
                {
                    work();
                    done.TrySetResult(true);
                }
                catch (Exception exception)
                {
                    TentacleLog.Error("Tentacle: deferred work threw: " + exception);
                    done.TrySetResult(false);
                }
            });
            return done.Task;
        }

        /// <summary>Lets go of every caller still waiting for a Pump; nothing will pump again.</summary>
        private void ReleasePumpWaiters()
        {
            TaskCompletionSource<bool>[] waiting;
            lock (pumpWaiters)
            {
                waiting = pumpWaiters.ToArray();
                pumpWaiters.Clear();
            }
            foreach (var waiter in waiting) waiter.TrySetResult(false);
        }

        /// <summary>Delivers everything the receive loop handed over.</summary>
        private void DrainInbound()
        {
            var dropped = inbound.TakeDroppedCount();
            if (dropped > 0)
            {
                TentacleLog.Warn(
                    "Tentacle: dropped " + dropped + " inbound messages; the game was not pumping fast enough");
            }

            TentacleInbound item;
            while (inbound.TryDequeue(out item))
            {
                switch (item.Kind)
                {
                    case TentacleInboundKind.Message:
                        HandleMessage(item.Type, item.Payload);
                        break;
                    case TentacleInboundKind.Closed:
                        HandleTransportEnded(item.Text ?? "the connection closed");
                        break;
                    case TentacleInboundKind.Faulted:
                        HandleTransportEnded(item.Text ?? "the connection failed");
                        break;
                }
            }
        }

        /// <summary>Dispatches one decoded message to the surface that owns it.</summary>
        private void HandleMessage(string type, JsonValue payload)
        {
            switch (type)
            {
                case SessionWelcomeType:
                    HandleWelcome(payload);
                    return;
                case "CustomControls_Initialize":
                    // The app asks for the current control set after its own UI
                    // reconnects; the session is unchanged, so this is a replay
                    // rather than a fresh registration.
                    CustomControls.ReRegisterAll();
                    return;
                case "CustomControls_ControlEvent":
                    CustomControls.HandleControlEvent(payload);
                    return;
                case "CustomEvents_Event":
                    CustomEvents.HandleEvent(payload);
                    return;
                case "CustomEvents_Definitions":
                    CustomEvents.HandleDefinitions(payload);
                    return;
                case "Bot_Commands":
                    Bot.HandleCommands(payload);
                    return;
                case "Stream_ChatJoin":
                    Stream.HandleChatJoin(payload);
                    return;
                case "Stream_Event":
                    Stream.HandleEvent(payload);
                    return;

                // ViewerAction_Action is deliberately unhandled: viewer actions
                // are still an experimental app feature, so neither plugin
                // exposes them. The Unreal plugin drops the message the same way.
            }
        }

        /// <summary>
        /// Completes the handshake: records the session id, replays the control
        /// registry, and loads the viewer-property registry.
        /// </summary>
        private void HandleWelcome(JsonValue payload)
        {
            var sessionId = payload != null ? JsonRead.ReadOptionalString(payload, "sessionId") : null;
            if (string.IsNullOrEmpty(sessionId))
            {
                // A welcome without an id is not a usable session. Dropping the
                // socket puts us back on the retry path rather than leaving a
                // half-open connection nothing will ever close.
                TentacleLog.Warn("Tentacle: the handshake reply carried no session id");
                HandleTransportEnded("the handshake reply carried no session id");
                return;
            }

            SessionId = sessionId;
            consecutiveFailures = 0;
            handshakeDeadlineSeconds = 0.0;
            SetConnectionStatus(ConnectionStatus.Connected);
            TentacleLog.Info("Tentacle: connected (session " + sessionId + ")");

            // Tentacle forgets a session's controls when its socket closes, so a
            // new session starts with none and every registration is replayed.
            CustomControls.ReRegisterAll();

            if (options.RefreshRegistryOnConnect)
            {
                Forget(ViewerProperties.RefreshRegistryAsync(), "viewer-property registry refresh");
            }
        }

        /// <summary>
        /// Handles the socket ending, from either side. Schedules a retry when a
        /// connection is still wanted.
        /// </summary>
        private void HandleTransportEnded(string reason)
        {
            if (ConnectionStatus == ConnectionStatus.Disconnected
                || ConnectionStatus == ConnectionStatus.Reconnecting)
            {
                // Already down: a close notice following a fault, or a stale
                // notice from a socket we replaced.
                return;
            }

            TentacleLog.Info("Tentacle: disconnected (" + reason + ")");
            CloseSession();

            if (!wantConnection)
            {
                SetConnectionStatus(ConnectionStatus.Disconnected);
                return;
            }
            ScheduleRetry();
        }

        /// <summary>Starts an attempt, checks one in flight, or waits out the backoff.</summary>
        private void AdvanceConnection()
        {
            if (!wantConnection) return;

            if (connectAttempt != null)
            {
                CheckConnectAttempt();

                // The attempt itself is bounded. ClientWebSocket applies no
                // timeout to the upgrade response, so a peer that accepts the
                // TCP connection and then says nothing would otherwise hold the
                // client in Connecting for the life of the process - and there
                // is a real way to reach one, because Tentacle never deletes its
                // discovery file, so a stale file can name a port something else
                // has taken. Expiry is treated as any other dropped connection.
                if (connectAttempt != null
                    && connectDeadlineSeconds > 0.0
                    && options.Clock.NowSeconds >= connectDeadlineSeconds)
                {
                    TentacleLog.Warn("Tentacle: the connection attempt was not answered in time");
                    HandleTransportEnded("the connection attempt timed out");
                }
                return;
            }

            if (ConnectionStatus == ConnectionStatus.Connecting)
            {
                // The socket is up and the hello has gone out; the only thing
                // left is Tentacle's reply, which is bounded.
                if (handshakeDeadlineSeconds > 0.0 && options.Clock.NowSeconds >= handshakeDeadlineSeconds)
                {
                    TentacleLog.Warn("Tentacle: the handshake was not answered in time");
                    HandleTransportEnded("the handshake timed out");
                }
                return;
            }

            if (ConnectionStatus == ConnectionStatus.Connected) return;
            if (options.Clock.NowSeconds < retryAtSeconds) return;

            BeginConnectAttempt();
        }

        /// <summary>Resolves the endpoints and starts opening the socket.</summary>
        private void BeginConnectAttempt()
        {
            Endpoints = options.Endpoints ?? TentacleEndpoints.Resolve(options.DataDirectory);
            http.BaseUrl = Endpoints.HttpBaseUrl;

            SetConnectionStatus(ConnectionStatus.Connecting);

            // The deadline is armed here rather than once the socket is open,
            // because the opening itself is the unbounded part.
            connectCancellation = new CancellationTokenSource();
            connectDeadlineSeconds = options.Clock.NowSeconds + options.ConnectTimeoutSeconds;
            connectAttempt = socket.ConnectAsync(Endpoints.EngineSocketUrl, connectCancellation.Token);
        }

        /// <summary>Picks up a finished connect attempt and sends the hello, or retries.</summary>
        private void CheckConnectAttempt()
        {
            var attempt = connectAttempt;
            if (attempt == null || !attempt.IsCompleted) return;

            connectAttempt = null;
            connectDeadlineSeconds = 0.0;
            var cancellation = connectCancellation;
            connectCancellation = null;
            // Safe to release here and nowhere else: the attempt has finished, so
            // nothing still holds a registration on the token.
            if (cancellation != null) cancellation.Dispose();

            // ConnectAsync answers false rather than throwing when the sidecar is
            // not there, so a faulted task is something else entirely and is
            // still not allowed to escape into the game loop.
            var opened = attempt.Status == TaskStatus.RanToCompletion && attempt.Result;
            if (!opened)
            {
                if (attempt.Exception != null)
                {
                    TentacleLog.Warn(
                        "Tentacle: the connection attempt failed: " + attempt.Exception.GetBaseException().Message);
                }
                ScheduleRetry();
                return;
            }

            handshakeDeadlineSeconds = options.Clock.NowSeconds + options.HandshakeTimeoutSeconds;
            Forget(socket.SendAsync(SessionHelloType, options.Identity.ToHelloPayload()), "handshake");
        }

        /// <summary>
        /// Cancels an in-flight connect attempt and forgets it.
        ///
        /// Cancelling is the point. Dropping the reference alone leaves the
        /// attempt running, and a transport that finishes afterwards would hand
        /// a socket and a background receive thread to a client that has been
        /// closed or disposed - an orphan session the peer only reaps on its own
        /// hello timeout, which is long enough to span an editor domain reload.
        /// </summary>
        private void AbandonConnectAttempt()
        {
            var attempt = connectAttempt;
            var cancellation = connectCancellation;
            connectAttempt = null;
            connectCancellation = null;
            connectDeadlineSeconds = 0.0;
            if (cancellation == null) return;

            cancellation.Cancel();

            // Whatever it ends as is nobody's news now, but an exception still
            // has to be observed rather than left for a finalizer.
            Forget(attempt, "the abandoned connection attempt");

            if (attempt == null || attempt.IsCompleted)
            {
                cancellation.Dispose();
                return;
            }

            // The transport still holds a registration on the token, so the
            // source is released only once the attempt has actually finished.
            attempt.ContinueWith(
                completed => cancellation.Dispose(),
                CancellationToken.None,
                TaskContinuationOptions.None,
                TaskScheduler.Default);
        }

        /// <summary>Moves to Reconnecting and sets when the next attempt may start.</summary>
        private void ScheduleRetry()
        {
            consecutiveFailures++;
            var delay = options.ReconnectPolicy.DelayForAttempt(consecutiveFailures, jitter);
            retryAtSeconds = options.Clock.NowSeconds + delay;
            SetConnectionStatus(ConnectionStatus.Reconnecting);
        }

        /// <summary>Tears the socket down and forgets everything session-scoped.</summary>
        private void CloseSession()
        {
            SessionId = "";
            handshakeDeadlineSeconds = 0.0;
            AbandonConnectAttempt();
            inbound.Clear();
            Forget(socket.DisconnectAsync(), "disconnect");
        }

        /// <summary>Records the status and notifies, ignoring a no-op change.</summary>
        private void SetConnectionStatus(ConnectionStatus status)
        {
            if (ConnectionStatus == status) return;
            ConnectionStatus = status;
            TentacleHandlers.Raise(OnConnectionStatusChanged, status, "connection-status");
        }

        /// <summary>
        /// Sends a message on the session socket. Returns false when there is no
        /// session.
        ///
        /// <paramref name="required"/> says whether that is worth a warning: a
        /// chat message the game asked to send is, while a control registration
        /// is not - the registry replays it as soon as a session opens.
        /// </summary>
        internal bool SendSocketMessage(string messageType, JsonValue data, bool required = true)
        {
            if (ConnectionStatus != ConnectionStatus.Connected)
            {
                if (required)
                {
                    TentacleLog.Warn(
                        "Tentacle: dropping " + messageType + "; there is no connection to Tentacle");
                }
                return false;
            }

            Forget(socket.SendAsync(messageType, data), messageType);
            return true;
        }

        /// <summary>
        /// Runs one tRPC call and unwraps it. Null means the call failed, which
        /// includes Tentacle not running - callers degrade rather than throw.
        /// </summary>
        internal async Task<JsonValue> CallAsync(
            Func<TentacleHttpClient, CancellationToken, Task<TentacleHttpResult>> call,
            string procedure,
            CancellationToken cancellationToken)
        {
            if (disposed) return null;
            try
            {
                var result = await call(http, cancellationToken).ConfigureAwait(false);
                return TentacleTrpc.Unwrap(result, procedure);
            }
            catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
            {
                throw;
            }
            catch (Exception exception)
            {
                // The generated client maps its own failures to results, so
                // reaching here means something outside it went wrong. It still
                // must not fault a task a game is awaiting in a coroutine.
                TentacleLog.Warn("Tentacle: " + procedure + " failed: " + exception.Message);
                return null;
            }
        }

        /// <summary>Runs a tRPC call and reports only whether it succeeded.</summary>
        internal async Task<bool> CallForSuccessAsync(
            Func<TentacleHttpClient, CancellationToken, Task<TentacleHttpResult>> call,
            string procedure,
            CancellationToken cancellationToken)
        {
            return await CallAsync(call, procedure, cancellationToken).ConfigureAwait(false) != null;
        }

        /// <summary>
        /// Starts a task whose outcome nobody waits for, logging a failure rather
        /// than leaving an unobserved exception to surface at a finalizer.
        /// </summary>
        internal static void Forget(Task task, string what)
        {
            if (task == null) return;
            task.ContinueWith(
                completed =>
                {
                    if (completed.Exception == null) return;
                    TentacleLog.Warn(
                        "Tentacle: " + what + " failed: " + completed.Exception.GetBaseException().Message);
                },
                CancellationToken.None,
                TaskContinuationOptions.ExecuteSynchronously,
                TaskScheduler.Default);
        }

        /// <summary>Closes the connection and releases the transport.</summary>
        public void Dispose()
        {
            lock (pumpWaiters)
            {
                if (disposed) return;
                disposed = true;
            }
            wantConnection = false;

            // Before the transport goes: an attempt still opening would otherwise
            // finish afterwards and hand this client a socket it can no longer
            // own. Disposing the transport alone does not cover it - the socket
            // it would close has not been published yet.
            AbandonConnectAttempt();

            CustomControls.Clear();
            inbound.Clear();
            ClearDeferred();
            ReleasePumpWaiters();
            socket.Dispose();
            http.Dispose();

            ConnectionStatus = ConnectionStatus.Disconnected;
            SessionId = "";
        }

        /// <summary>Drops anything queued for the pumping thread; nothing will pump again.</summary>
        private void ClearDeferred()
        {
            Action discarded;
            while (deferred.TryDequeue(out discarded))
            {
                // Draining is the point; the work itself is no longer wanted.
            }
        }
    }
}
