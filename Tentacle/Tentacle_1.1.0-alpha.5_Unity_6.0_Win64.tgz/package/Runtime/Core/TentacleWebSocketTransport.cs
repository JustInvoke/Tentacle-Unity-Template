// Copyright Tentacle. All Rights Reserved.
using System;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // All this does is turn one event per message type back into one event
    // carrying the type, so the client has a single inbound path. The
    // handshake's own frames have no typed event - they are defined outside the
    // type surface the client was generated from - and arrive through the
    // generated client's unhandled-message hook instead.
    /// <summary>
    /// The session socket a <see cref="TentacleClient"/> uses unless it is
    /// given another: <see cref="TentacleWebSocketClient"/>, presented as
    /// <see cref="ITentacleSocket"/>.
    ///
    /// Features:
    /// - No connection logic of its own: framing, reassembly, size bounds and
    ///   send serialization all stay in <see cref="TentacleWebSocketClient"/>
    /// - A message type this plugin version predates is reported once, here,
    ///   rather than reaching the client as an unroutable message
    /// </summary>
    public sealed class TentacleWebSocketTransport : ITentacleSocket
    {
        /// <summary>Message type Tentacle answers the handshake with.</summary>
        public const string SessionWelcomeType = "Session_Welcome";

        private readonly TentacleWebSocketClient socket = new TentacleWebSocketClient();

        /// <summary>Raised for every inbound message, with its type and payload.</summary>
        public event Action<string, JsonValue> MessageReceived;

        /// <summary>Raised when the connection ends.</summary>
        public event Action<string> Disconnected;

        /// <summary>Raised when the transport fails.</summary>
        public event Action<string> Faulted;

        /// <summary>Wires the generated client's events onto this one's.</summary>
        public TentacleWebSocketTransport()
        {
            socket.BotCommands += data => Raise("Bot_Commands", data);
            socket.CustomControlsInitialize += () => Raise("CustomControls_Initialize", null);
            socket.CustomControlsControlEvent += data => Raise("CustomControls_ControlEvent", data);
            socket.CustomEventsDefinitions += data => Raise("CustomEvents_Definitions", data);
            socket.CustomEventsEvent += data => Raise("CustomEvents_Event", data);
            socket.StreamChatJoin += data => Raise("Stream_ChatJoin", data);
            socket.StreamEvent += data => Raise("Stream_Event", data);

            // ViewerActionAction is deliberately not forwarded: viewer actions
            // are an experimental app feature that neither plugin exposes yet.

            socket.UnhandledMessage += (type, envelope) =>
            {
                if (type == SessionWelcomeType)
                {
                    Raise(type, envelope != null ? envelope["data"] : null);
                    return;
                }
                TentacleLog.Info(
                    "Tentacle: ignoring message type \"" + type + "\"; this plugin version does not handle it");
            };

            socket.Disconnected += reason =>
            {
                var handler = Disconnected;
                if (handler != null) handler(reason);
            };
            socket.Faulted += message =>
            {
                var handler = Faulted;
                if (handler != null) handler(message);
            };
        }

        /// <summary>Opens the connection, abandoning the attempt if the token fires.</summary>
        public Task<bool> ConnectAsync(string url, CancellationToken cancellationToken)
        {
            // The generated client hands the token straight to
            // ClientWebSocket.ConnectAsync, so cancelling it abandons the
            // upgrade rather than merely losing interest in the answer. Nothing
            // is passed for the token parameter: the engine socket trusts
            // loopback and requires no secret.
            return socket.ConnectAsync(url, null, cancellationToken);
        }

        /// <summary>Closes the connection.</summary>
        public Task DisconnectAsync()
        {
            return socket.DisconnectAsync();
        }

        /// <summary>Sends one message.</summary>
        public Task SendAsync(string messageType, JsonValue data)
        {
            return socket.SendMessageAsync(messageType, data);
        }

        /// <summary>Forwards one message to the subscriber.</summary>
        private void Raise(string type, JsonValue data)
        {
            var handler = MessageReceived;
            if (handler != null) handler(type, data);
        }

        /// <summary>Closes the connection and releases the transport.</summary>
        public void Dispose()
        {
            socket.Dispose();
        }
    }
}
