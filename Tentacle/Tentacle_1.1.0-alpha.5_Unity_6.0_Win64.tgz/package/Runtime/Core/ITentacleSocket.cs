// Copyright Tentacle. All Rights Reserved.
using System;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // The generated WebSocket client exposes one event per message type, which
    // is the right shape for someone consuming a known message. The client here
    // wants the opposite - every message, tagged - so that routing, ordering and
    // thread hand-off live in one place. This is that shape, and it is an
    // interface so the whole connection state machine can be tested without a
    // socket, a port, or a running Tentacle.
    /// <summary>
    /// The session socket a <see cref="TentacleClient"/> talks to Tentacle
    /// through. The package supplies one; implement this only to give a client
    /// a transport of your own, through <see cref="TentacleClientOptions.Socket"/>.
    ///
    /// Implementations raise their events on whatever thread the transport uses;
    /// marshalling is the client's job.
    /// </summary>
    public interface ITentacleSocket : IDisposable
    {
        /// <summary>
        /// Raised for every inbound message, with its <c>type</c> and its decoded
        /// <c>data</c> payload. The payload is null for a message that carries no
        /// data.
        /// </summary>
        event Action<string, JsonValue> MessageReceived;

        /// <summary>Raised when the connection ends, with the close reason when there was one.</summary>
        event Action<string> Disconnected;

        /// <summary>Raised when the transport fails. The connection is closed by then.</summary>
        event Action<string> Faulted;

        /// <summary>
        /// Opens a connection. Answers false rather than throwing when the peer
        /// is not there, which is the ordinary case when Tentacle is not running.
        ///
        /// <paramref name="cancellationToken"/> abandons the attempt, and an
        /// implementation must honour it: the client gives every attempt a
        /// deadline and cancels the token when it expires, when the session is
        /// closed, and when the client is disposed. Dropping the reference alone
        /// would let a late-landing attempt open a socket - and start a receive
        /// thread - onto a client that no longer exists.
        /// </summary>
        Task<bool> ConnectAsync(string url, CancellationToken cancellationToken);

        /// <summary>Closes the connection. Safe to call when already closed.</summary>
        Task DisconnectAsync();

        /// <summary>
        /// Sends one message. A null <paramref name="data"/> sends an envelope
        /// with no <c>data</c> key, which is what a payload-less message type
        /// looks like on the wire.
        /// </summary>
        Task SendAsync(string messageType, JsonValue data);
    }
}
