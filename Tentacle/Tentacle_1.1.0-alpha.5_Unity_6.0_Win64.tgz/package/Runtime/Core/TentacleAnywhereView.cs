// Copyright Tentacle. All Rights Reserved.
namespace Tcl
{
    /// <summary>
    /// Builds the cross-platform "Anywhere" view of a stream event.
    ///
    /// Twitch and Kick describe the same thing - a follow, a gift sub - with
    /// completely different payloads, so the app also writes a normalised set of
    /// `$`-prefixed fields onto every event it can. The generated types expose
    /// that as <c>GetAnywhereEvent()</c>, but only on the concrete classes that
    /// have one, and C# has no common interface across them. This is the one
    /// place that knows the mapping.
    ///
    /// Anything not listed has no cross-platform equivalent (a Twitch poll, a
    /// hype train) and correctly yields null: such an event still reaches the
    /// game through the platform-specific events.
    /// </summary>
    public static class TentacleAnywhereView
    {
        /// <summary>
        /// The Anywhere view of <paramref name="streamEvent"/>, or null when this
        /// event kind has none.
        /// </summary>
        public static StreamEventAnywhereBase For(StreamEventBase streamEvent)
        {
            if (streamEvent == null) return null;

            // Twitch
            var twitchChat = streamEvent as StreamEvent_Twitch_ChatMessage;
            if (twitchChat != null) return twitchChat.GetAnywhereEvent();

            var twitchBan = streamEvent as StreamEvent_Twitch_Ban;
            if (twitchBan != null) return twitchBan.GetAnywhereEvent();

            var twitchChannelUpdate = streamEvent as StreamEvent_Twitch_ChannelUpdate;
            if (twitchChannelUpdate != null) return twitchChannelUpdate.GetAnywhereEvent();

            var twitchCheer = streamEvent as StreamEvent_Twitch_Cheer;
            if (twitchCheer != null) return twitchCheer.GetAnywhereEvent();

            var twitchFollow = streamEvent as StreamEvent_Twitch_Follow;
            if (twitchFollow != null) return twitchFollow.GetAnywhereEvent();

            var twitchRedemptionAdd = streamEvent as StreamEvent_Twitch_RedemptionAdd;
            if (twitchRedemptionAdd != null) return twitchRedemptionAdd.GetAnywhereEvent();

            var twitchRedemptionUpdate = streamEvent as StreamEvent_Twitch_RedemptionUpdate;
            if (twitchRedemptionUpdate != null) return twitchRedemptionUpdate.GetAnywhereEvent();

            var twitchSubscription = streamEvent as StreamEvent_Twitch_Subscription;
            if (twitchSubscription != null) return twitchSubscription.GetAnywhereEvent();

            var twitchSubscriptionGift = streamEvent as StreamEvent_Twitch_SubscriptionGift;
            if (twitchSubscriptionGift != null) return twitchSubscriptionGift.GetAnywhereEvent();

            // A resubscription message is a renewal, not a new subscription - the
            // same split the Unreal plugin makes.
            var twitchSubscriptionMessage = streamEvent as StreamEvent_Twitch_SubscriptionMessage;
            if (twitchSubscriptionMessage != null) return twitchSubscriptionMessage.GetAnywhereEvent();

            // Kick
            var kickChat = streamEvent as StreamEvent_Kick_ChatMessage;
            if (kickChat != null) return kickChat.GetAnywhereEvent();

            var kickBanned = streamEvent as StreamEvent_Kick_ModerationBanned;
            if (kickBanned != null) return kickBanned.GetAnywhereEvent();

            var kickFollowed = streamEvent as StreamEvent_Kick_ChannelFollowed;
            if (kickFollowed != null) return kickFollowed.GetAnywhereEvent();

            var kickMetadata = streamEvent as StreamEvent_Kick_LivestreamMetadataUpdated;
            if (kickMetadata != null) return kickMetadata.GetAnywhereEvent();

            var kickRedemption = streamEvent as StreamEvent_Kick_ChannelRewardRedemptionUpdated;
            if (kickRedemption != null) return kickRedemption.GetAnywhereEvent();

            var kickSubscription = streamEvent as StreamEvent_Kick_ChannelSubscriptionNew;
            if (kickSubscription != null) return kickSubscription.GetAnywhereEvent();

            var kickSubscriptionGift = streamEvent as StreamEvent_Kick_ChannelSubscriptionGifts;
            if (kickSubscriptionGift != null) return kickSubscriptionGift.GetAnywhereEvent();

            var kickRenewal = streamEvent as StreamEvent_Kick_ChannelSubscriptionRenewal;
            if (kickRenewal != null) return kickRenewal.GetAnywhereEvent();

            return null;
        }
    }
}
