// Copyright Tentacle. All Rights Reserved.
using System.Diagnostics;

namespace Tcl
{
    // Injected so a test can drive reconnect backoff and handshake timeouts
    // without sleeping.
    /// <summary>
    /// The monotonic time source a <see cref="TentacleClient"/> measures its
    /// retry delays and deadlines against, set through
    /// <see cref="TentacleClientOptions.Clock"/>.
    /// </summary>
    public interface ITentacleClock
    {
        /// <summary>Seconds since an arbitrary fixed origin. Never goes backwards.</summary>
        double NowSeconds { get; }
    }

    /// <summary>
    /// The default clock: a process-wide <see cref="Stopwatch"/>.
    ///
    /// Deliberately not wall-clock time. A reconnect delay measured against
    /// DateTime would be skipped or stalled by an NTP correction or a daylight
    /// saving change, and a game left running overnight hits both.
    /// </summary>
    public sealed class TentacleStopwatchClock : ITentacleClock
    {
        /// <summary>The shared instance. The origin is arbitrary, so one is enough.</summary>
        public static readonly TentacleStopwatchClock Instance = new TentacleStopwatchClock();

        private readonly Stopwatch stopwatch = Stopwatch.StartNew();

        /// <summary>Seconds since this clock was created.</summary>
        public double NowSeconds
        {
            get { return stopwatch.Elapsed.TotalSeconds; }
        }
    }
}
