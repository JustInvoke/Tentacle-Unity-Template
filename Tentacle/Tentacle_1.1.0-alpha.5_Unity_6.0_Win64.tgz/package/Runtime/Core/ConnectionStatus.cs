// Copyright Tentacle. All Rights Reserved.
namespace Tcl
{
    // The Unreal plugin's ETclConnectionStatus carries only Disconnected and
    // Connected, because its connection either has a session id or does not.
    // The two states in between are a superset, not a divergence: this runtime
    // reports the same two at the same moments, and a game that only checks for
    // Connected behaves identically on both engines.
    /// <summary>
    /// Where the runtime's connection to Tentacle stands.
    ///
    /// A game that only needs to know whether it is connected checks for
    /// <see cref="Connected"/> alone. <see cref="Connecting"/> and
    /// <see cref="Reconnecting"/> exist so a game can put "connecting..." on
    /// screen instead of "not connected" while the socket is coming up.
    /// </summary>
    public enum ConnectionStatus
    {
        /// <summary>No connection, and none is being attempted.</summary>
        Disconnected,

        /// <summary>A connection attempt is in flight, or its handshake is outstanding.</summary>
        Connecting,

        /// <summary>The session is open: the handshake completed and Tentacle assigned a session id.</summary>
        Connected,

        /// <summary>Waiting out the reconnect backoff before the next attempt.</summary>
        Reconnecting,
    }
}
