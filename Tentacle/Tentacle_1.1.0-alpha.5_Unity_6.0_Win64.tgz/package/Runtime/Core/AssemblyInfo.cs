// Copyright Tentacle. All Rights Reserved.
using System.Runtime.CompilerServices;

// The edit-mode tests drive internals a game has no business touching - the
// viewer cache's merge path, the registry seam, the surfaces' inbound handlers -
// so they are internal rather than public and the test assembly is let in here.
[assembly: InternalsVisibleTo("Tentacle.Tests.Editor")]
