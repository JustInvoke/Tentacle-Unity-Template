// Copyright Tentacle. All Rights Reserved.
namespace Tcl
{
    // The Unreal plugin's ETclChatSendTarget. Deliberately separate from the
    // generated StreamPlatform, which mirrors the wire enum and so has no
    // "every platform" member.
    /// <summary>
    /// Which platform a chat message is sent to. <see cref="AllConnected"/>
    /// sends it on every platform Tentacle has a chat connection to.
    /// </summary>
    public enum ChatSendTarget
    {
        /// <summary>Every platform Tentacle currently has a chat connection to.</summary>
        AllConnected,

        /// <summary>Twitch only.</summary>
        Twitch,

        /// <summary>Kick only.</summary>
        Kick,
    }
}
