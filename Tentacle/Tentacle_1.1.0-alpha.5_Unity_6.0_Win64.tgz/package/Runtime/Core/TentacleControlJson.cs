// Copyright Tentacle. All Rights Reserved.
using System.Collections.Generic;
using Tcl.Json;
using UnityEngine;

namespace Tcl
{
    // The generated CustomControl hierarchy is parse-only - the generator emits
    // readers, not writers - so the write half lives here. It deliberately
    // reuses those generated classes instead of declaring a parallel set: a
    // control the game registers and a control Tentacle echoes back are then
    // the same type, and a field added upstream cannot be forgotten on the
    // outbound side without the compiler noticing.
    /// <summary>
    /// Turns a custom control into the JSON Tentacle expects, and folds an
    /// inbound control event's value back onto it.
    ///
    /// It works on the same <see cref="CustomControl"/> classes a game
    /// registers, so a control the game registers and a control Tentacle echoes
    /// back are the same type.
    ///
    /// Features:
    /// - The <c>type</c> discriminator comes from the C# type, so it cannot
    ///   disagree with the payload's own fields
    /// - Optional wire fields (group, placeholder) are omitted when empty, which
    ///   is what the app distinguishes from an empty string
    /// - Applying an inbound value is type-checked against the control, so a
    ///   malformed value leaves the control alone rather than corrupting it
    /// </summary>
    public static class TentacleControlJson
    {
        /// <summary>
        /// The wire <c>type</c> discriminator for a control, or null when the
        /// instance is a bare <see cref="CustomControl"/> or an unknown subclass.
        /// </summary>
        public static string DiscriminatorFor(CustomControl control)
        {
            if (control is CustomControl_Button) return "Button";
            if (control is CustomControl_Color) return "Color";
            if (control is CustomControl_Int) return "Int";
            if (control is CustomControl_Number) return "Number";
            if (control is CustomControl_Select) return "Select";
            if (control is CustomControl_Slider) return "Slider";
            if (control is CustomControl_Switch) return "Switch";
            if (control is CustomControl_Text) return "Text";
            if (control is CustomControl_Vector2) return "Vector2";
            if (control is CustomControl_Vector3) return "Vector3";
            if (control is CustomControl_Vector4) return "Vector4";
            return null;
        }

        /// <summary>
        /// Serializes a control to its wire object, or null when the instance is
        /// not one of the known control types. A null return is the caller's cue
        /// to refuse the registration rather than send a control the app would
        /// drop as undiscriminated.
        /// </summary>
        public static JsonValue ToJson(CustomControl control)
        {
            if (control == null) return null;

            var discriminator = DiscriminatorFor(control);
            if (discriminator == null)
            {
                TentacleLog.Error(
                    "Tentacle: cannot register a control of type " + control.GetType().Name
                    + "; use one of the CustomControl_* subclasses");
                return null;
            }

            var members = new List<KeyValuePair<string, JsonValue>>
            {
                JsonValue.Member("id", JsonValue.FromString(control.Id ?? "")),
                JsonValue.Member("type", JsonValue.FromString(discriminator)),
                JsonValue.Member("label", JsonValue.FromString(control.Label ?? "")),
                JsonValue.Member("sortIndex", JsonValue.FromNumber(control.SortIndex)),
            };

            // An absent group means "ungrouped"; an empty string would be a group
            // whose name is blank.
            if (!string.IsNullOrEmpty(control.Group))
            {
                members.Add(JsonValue.Member("group", JsonValue.FromString(control.Group)));
            }

            AppendValue(control, members);
            return JsonValue.FromObject(members);
        }

        /// <summary>Appends the per-type value fields for a control.</summary>
        private static void AppendValue(CustomControl control, List<KeyValuePair<string, JsonValue>> members)
        {
            var color = control as CustomControl_Color;
            if (color != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromString(color.Value ?? "")));
                return;
            }

            var integer = control as CustomControl_Int;
            if (integer != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromNumber(integer.Value)));
                return;
            }

            var slider = control as CustomControl_Slider;
            if (slider != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromNumber(slider.Value)));
                members.Add(JsonValue.Member("min", JsonValue.FromNumber(slider.Min)));
                members.Add(JsonValue.Member("max", JsonValue.FromNumber(slider.Max)));
                members.Add(JsonValue.Member("step", JsonValue.FromNumber(slider.Step)));
                return;
            }

            // Number carries the same range as Slider; Slider is checked above
            // precisely because the two are otherwise alike.
            var number = control as CustomControl_Number;
            if (number != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromNumber(number.Value)));
                members.Add(JsonValue.Member("min", JsonValue.FromNumber(number.Min)));
                members.Add(JsonValue.Member("max", JsonValue.FromNumber(number.Max)));
                members.Add(JsonValue.Member("step", JsonValue.FromNumber(number.Step)));
                return;
            }

            var select = control as CustomControl_Select;
            if (select != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromString(select.Value ?? "")));
                var options = new List<JsonValue>();
                if (select.Options != null)
                {
                    foreach (var option in select.Options) options.Add(JsonValue.FromString(option ?? ""));
                }
                members.Add(JsonValue.Member("options", JsonValue.FromArray(options)));
                if (!string.IsNullOrEmpty(select.Placeholder))
                {
                    members.Add(JsonValue.Member("placeholder", JsonValue.FromString(select.Placeholder)));
                }
                return;
            }

            var toggle = control as CustomControl_Switch;
            if (toggle != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromBool(toggle.Value)));
                return;
            }

            var text = control as CustomControl_Text;
            if (text != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromString(text.Value ?? "")));
                if (!string.IsNullOrEmpty(text.Placeholder))
                {
                    members.Add(JsonValue.Member("placeholder", JsonValue.FromString(text.Placeholder)));
                }
                return;
            }

            var vector2 = control as CustomControl_Vector2;
            if (vector2 != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromArray(new[]
                {
                    JsonValue.FromNumber(vector2.Value.x),
                    JsonValue.FromNumber(vector2.Value.y),
                })));
                return;
            }

            var vector3 = control as CustomControl_Vector3;
            if (vector3 != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromArray(new[]
                {
                    JsonValue.FromNumber(vector3.Value.x),
                    JsonValue.FromNumber(vector3.Value.y),
                    JsonValue.FromNumber(vector3.Value.z),
                })));
                return;
            }

            var vector4 = control as CustomControl_Vector4;
            if (vector4 != null)
            {
                members.Add(JsonValue.Member("value", JsonValue.FromArray(new[]
                {
                    JsonValue.FromNumber(vector4.Value.x),
                    JsonValue.FromNumber(vector4.Value.y),
                    JsonValue.FromNumber(vector4.Value.z),
                    JsonValue.FromNumber(vector4.Value.w),
                })));
            }

            // A Button carries no value, so falling through here is correct.
        }

        /// <summary>
        /// Writes an inbound event value onto the control it belongs to, and
        /// reports whether anything was applied.
        ///
        /// A value of the wrong shape is refused rather than coerced: the app and
        /// the game disagreeing about a control's type is a bug worth seeing in
        /// the log, and silently reading a string as zero would hide it.
        /// </summary>
        public static bool ApplyValue(CustomControl control, JsonValue value)
        {
            if (control == null || value == null) return false;

            var color = control as CustomControl_Color;
            if (color != null)
            {
                if (value.Kind != JsonKind.String) return RefuseValue(control, value, "a string");
                color.Value = value.AsString(color.Value);
                return true;
            }

            var integer = control as CustomControl_Int;
            if (integer != null)
            {
                if (value.Kind != JsonKind.Number) return RefuseValue(control, value, "a number");
                integer.Value = (int)value.AsNumber(integer.Value);
                return true;
            }

            var slider = control as CustomControl_Slider;
            if (slider != null)
            {
                if (value.Kind != JsonKind.Number) return RefuseValue(control, value, "a number");
                slider.Value = (float)value.AsNumber(slider.Value);
                return true;
            }

            var number = control as CustomControl_Number;
            if (number != null)
            {
                if (value.Kind != JsonKind.Number) return RefuseValue(control, value, "a number");
                number.Value = (float)value.AsNumber(number.Value);
                return true;
            }

            var select = control as CustomControl_Select;
            if (select != null)
            {
                if (value.Kind != JsonKind.String) return RefuseValue(control, value, "a string");
                select.Value = value.AsString(select.Value);
                return true;
            }

            var toggle = control as CustomControl_Switch;
            if (toggle != null)
            {
                if (value.Kind != JsonKind.Bool) return RefuseValue(control, value, "a boolean");
                toggle.Value = value.AsBool(toggle.Value);
                return true;
            }

            var text = control as CustomControl_Text;
            if (text != null)
            {
                if (value.Kind != JsonKind.String) return RefuseValue(control, value, "a string");
                text.Value = value.AsString(text.Value);
                return true;
            }

            var vector2 = control as CustomControl_Vector2;
            if (vector2 != null)
            {
                double[] components;
                if (!TryReadComponents(value, 2, out components)) return RefuseValue(control, value, "2 numbers");
                vector2.Value = new Vector2((float)components[0], (float)components[1]);
                return true;
            }

            var vector3 = control as CustomControl_Vector3;
            if (vector3 != null)
            {
                double[] components;
                if (!TryReadComponents(value, 3, out components)) return RefuseValue(control, value, "3 numbers");
                vector3.Value = new Vector3((float)components[0], (float)components[1], (float)components[2]);
                return true;
            }

            var vector4 = control as CustomControl_Vector4;
            if (vector4 != null)
            {
                double[] components;
                if (!TryReadComponents(value, 4, out components)) return RefuseValue(control, value, "4 numbers");
                vector4.Value = new Vector4(
                    (float)components[0], (float)components[1], (float)components[2], (float)components[3]);
                return true;
            }

            // A Button has nothing to apply; its events are click / mouse only.
            return false;
        }

        /// <summary>Logs a refused value and reports failure, so callers stay one-liners.</summary>
        private static bool RefuseValue(CustomControl control, JsonValue value, string expected)
        {
            TentacleLog.Warn(
                "Tentacle: ignoring a value for control \"" + (control.Id ?? "") + "\"; expected "
                + expected + " but got " + value.Kind);
            return false;
        }

        /// <summary>Reads a fixed-length numeric array, refusing anything else.</summary>
        private static bool TryReadComponents(JsonValue value, int count, out double[] components)
        {
            components = null;
            if (value.Kind != JsonKind.Array) return false;

            var items = value.Items;
            if (items == null || items.Count < count) return false;

            var result = new double[count];
            for (var i = 0; i < count; i++)
            {
                var item = items[i];
                if (item == null || item.Kind != JsonKind.Number) return false;
                result[i] = item.AsNumber(0.0);
            }
            components = result;
            return true;
        }
    }
}
