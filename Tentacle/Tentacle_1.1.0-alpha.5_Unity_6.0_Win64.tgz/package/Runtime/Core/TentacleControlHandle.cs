// Copyright Tentacle. All Rights Reserved.
using System;
using Tcl.Json;

namespace Tcl
{
    // No Unreal counterpart: Unreal registers the component itself. The event
    // names are the component's, which are Unreal's.
    /// <summary>
    /// A control this game registered with Tentacle, and the way the game hears
    /// about the streamer touching it.
    ///
    /// The handle owns the <see cref="CustomControl"/> instance: mutate the
    /// control's fields and call <see cref="PushState"/> to show the new value in
    /// Tentacle. Values arriving from Tentacle are written onto the same instance
    /// before the events below fire, so a handler can just read the control.
    ///
    /// This is the untyped layer. A control authored in the scene with one of the
    /// <c>Custom Control (Slider)</c> components has a typed value and typed
    /// events, and reaches its handle through CustomControlComponent.Handle.
    ///
    /// Features:
    /// - Per-control events, rather than one global stream the game has to filter
    /// - <see cref="OnValueChangedFromApp"/> and <see cref="OnValueCommittedFromApp"/>
    ///   mirror the app's own split: continuous while dragging, once on release
    ///   or commit
    /// - Pushing state does not raise the events; they are strictly app-to-game,
    ///   so a game cannot loop by reacting to its own write
    /// </summary>
    public sealed class TentacleControlHandle
    {
        private readonly Tentacle_CustomControls owner;

        /// <summary>The control instance, live: read its value inside a handler.</summary>
        public CustomControl Control { get; private set; }

        /// <summary>The control's id, as Tentacle knows it.</summary>
        public string Id
        {
            get { return Control != null ? Control.Id : ""; }
        }

        /// <summary>True until <see cref="Unregister"/> is called.</summary>
        public bool IsRegistered { get; internal set; }

        /// <summary>Raised when the streamer clicks the control.</summary>
        public event Action OnClick;

        /// <summary>Raised when a press begins on the control.</summary>
        public event Action OnMouseDown;

        /// <summary>Raised when a press ends on the control.</summary>
        public event Action OnMouseUp;

        /// <summary>
        /// Raised continuously while the streamer adjusts the value. The control
        /// already carries the new value. The raw JSON value is passed too, for a
        /// caller that wants it without downcasting the control.
        /// </summary>
        public event Action<JsonValue> OnValueChangedFromApp;

        /// <summary>Raised once the streamer settles on a value.</summary>
        public event Action<JsonValue> OnValueCommittedFromApp;

        /// <summary>Creates a handle. Only the custom-controls surface does this.</summary>
        internal TentacleControlHandle(Tentacle_CustomControls owner, CustomControl control)
        {
            this.owner = owner;
            Control = control;
            IsRegistered = true;
        }

        /// <summary>
        /// Sends the control's current state to Tentacle. Call this after changing
        /// a field on <see cref="Control"/> from game code.
        /// </summary>
        public void PushState()
        {
            owner.PushState(this);
        }

        /// <summary>Removes the control from Tentacle. Safe to call more than once.</summary>
        public void Unregister()
        {
            owner.UnregisterCustomControl(this);
        }

        /// <summary>Applies an inbound control event and raises the matching handler.</summary>
        internal void Deliver(CustomControlEvent controlEvent)
        {
            if (controlEvent == null) return;

            var valueChange = controlEvent as CustomControlEvent_ValueChange;
            if (valueChange != null)
            {
                TentacleControlJson.ApplyValue(Control, valueChange.Value);
                Raise(OnValueChangedFromApp, valueChange.Value);
                return;
            }

            var valueCommit = controlEvent as CustomControlEvent_ValueCommit;
            if (valueCommit != null)
            {
                TentacleControlJson.ApplyValue(Control, valueCommit.Value);
                Raise(OnValueCommittedFromApp, valueCommit.Value);
                return;
            }

            if (controlEvent is CustomControlEvent_Click) { Raise(OnClick); return; }
            if (controlEvent is CustomControlEvent_MouseDown) { Raise(OnMouseDown); return; }
            if (controlEvent is CustomControlEvent_MouseUp) { Raise(OnMouseUp); return; }

            // A control event kind this plugin version predates. The app is
            // forward-compatible by design, so this is a notice, not a failure.
            TentacleLog.Warn(
                "Tentacle: ignoring an unrecognised control event for \"" + Id + "\"");
        }

        /// <summary>Raises a handler, each subscriber on its own.</summary>
        private static void Raise(Action handler)
        {
            TentacleHandlers.Raise(handler, "control");
        }

        /// <summary>Raises a value handler, each subscriber on its own.</summary>
        private static void Raise(Action<JsonValue> handler, JsonValue value)
        {
            TentacleHandlers.Raise(handler, value, "control");
        }
    }
}
