// Copyright Tentacle. All Rights Reserved.
using System.Collections.Generic;
using Tcl.Json;

namespace Tcl
{
    /// <summary>
    /// OBS requests, relayed through Tentacle's own OBS connection.
    ///
    /// The game never talks to OBS directly: Tentacle already holds the
    /// obs-websocket connection the streamer configured, so the game hands it a
    /// request and Tentacle forwards it. That also means the game needs no OBS
    /// credentials and keeps working when the streamer moves OBS to another
    /// machine.
    ///
    /// Fire-and-forget by construction. The protocol carries no response for an
    /// OBS call, so there is nothing to await and nothing to report - a request
    /// sent while OBS is not connected is dropped by the app.
    /// </summary>
    public sealed class Tentacle_Obs
    {
        private readonly TentacleClient client;

        /// <summary>Creates the OBS surface for a client.</summary>
        internal Tentacle_Obs(TentacleClient client)
        {
            this.client = client;
        }

        /// <summary>
        /// Sends an obs-websocket request by name, with an optional request body.
        /// See the obs-websocket protocol for the request types and their fields.
        /// </summary>
        public void Call(string requestType, JsonValue requestData = null)
        {
            if (string.IsNullOrEmpty(requestType))
            {
                TentacleLog.Warn("Tentacle: not sending an OBS call with no request type");
                return;
            }

            var members = new List<KeyValuePair<string, JsonValue>>
            {
                JsonValue.Member("requestType", JsonValue.FromString(requestType)),
            };
            // Omitted rather than sent as an empty object: the app's schema makes
            // requestData optional, and OBS requests differ on whether they
            // tolerate an empty body.
            if (requestData != null && requestData.Kind == JsonKind.Object)
            {
                members.Add(JsonValue.Member("requestData", requestData));
            }

            client.SendSocketMessage("Obs_Call", JsonValue.FromObject(members));
        }

        /// <summary>Turns a filter on a source on or off.</summary>
        public void SetSourceFilterEnabled(string sourceName, string filterName, bool enabled)
        {
            Call("SetSourceFilterEnabled", JsonValue.Object(
                JsonValue.Member("sourceName", JsonValue.FromString(sourceName ?? "")),
                JsonValue.Member("filterName", JsonValue.FromString(filterName ?? "")),
                JsonValue.Member("filterEnabled", JsonValue.FromBool(enabled))));
        }

        /// <summary>Switches OBS to a scene by name.</summary>
        public void SetCurrentProgramScene(string sceneName)
        {
            Call("SetCurrentProgramScene", JsonValue.Object(
                JsonValue.Member("sceneName", JsonValue.FromString(sceneName ?? ""))));
        }
    }
}
