// Copyright Tentacle. All Rights Reserved.
using System.Collections.Generic;
using Tcl.Json;
using UnityEngine;

namespace Tcl
{
    // The Unreal plugin's ETclFindPropertyResult, with the same three outcomes.
    // A registry that has not loaded yet is deliberately not a member: it is a
    // transient state the plugin recovers from on its own, so a game has
    // nothing to do about it that waiting would not also do.
    /// <summary>
    /// How a property read on a viewer ended.
    ///
    /// A read made before the viewer-property registry has loaded answers
    /// <see cref="CollectionNotFound"/> and says why in the log. The registry is
    /// fetched on connect, retried on failure, and re-fetched on demand, so
    /// waiting resolves it.
    /// </summary>
    public enum FindPropertyResult
    {
        /// <summary>The value was found.</summary>
        Found,

        /// <summary>No collection of that name exists in the registry.</summary>
        CollectionNotFound,

        /// <summary>The collection exists but has no definition of that name.</summary>
        PropertyNotFound,
    }

    // The Unreal plugin's ETclSetPropertyResult: its own enum there too, so a
    // write answers Success where a read answers Found.
    /// <summary>
    /// How a property write on a viewer ended: a set, an add, or a toggle.
    ///
    /// The property must already exist; a write never creates one. A write made
    /// before the viewer-property registry has loaded answers
    /// <see cref="CollectionNotFound"/> and says why in the log, as a read does.
    /// </summary>
    public enum SetPropertyResult
    {
        /// <summary>The value was written.</summary>
        Success,

        /// <summary>No collection of that name exists in the registry.</summary>
        CollectionNotFound,

        /// <summary>The collection exists but has no definition of that name.</summary>
        PropertyNotFound,
    }

    /// <summary>One property value held on a viewer, plus how it got there.</summary>
    public sealed class TentacleViewerPropertyEntry
    {
        /// <summary>Id of the collection the definition belongs to.</summary>
        public string CollectionId = "";

        /// <summary>Id of the definition this value is for.</summary>
        public string DefinitionId = "";

        /// <summary>The effective value.</summary>
        public JsonValue Value = JsonValue.Null;

        /// <summary>True when this is the definition's default rather than an explicit override.</summary>
        public bool IsDefault;

        /// <summary>
        /// True when the game wrote this value and Tentacle has not echoed it
        /// back yet. A viewer snapshot taken before the write must not revert it.
        /// </summary>
        public bool LocallyModified;
    }

    // The name, display name, and colour precedence mirrors the Unreal plugin's
    // UTclViewer.
    /// <summary>
    /// A viewer as the game sees them: their identity on each platform, and the
    /// viewer-property values Tentacle has sent for them.
    ///
    /// Instances are owned by <see cref="Tentacle_Viewers"/> and are stable for
    /// as long as the cache holds them, so a game can keep a reference on a
    /// spawned actor and watch it stay current.
    ///
    /// Features:
    /// - Cross-platform name, display name, and colour with a defined precedence
    /// - Property reads that resolve names through the registry, so a game never
    ///   handles collection or definition ids
    /// - Optimistic local writes that survive a stale server snapshot, and give
    ///   the value back to the server when the write turns out not to have
    ///   landed
    /// </summary>
    public sealed class Viewer
    {
        private readonly Dictionary<string, TentacleViewerPropertyEntry> properties =
            new Dictionary<string, TentacleViewerPropertyEntry>();

        /// <summary>The most recent full payload Tentacle sent for this viewer.</summary>
        public ViewerData Data { get; private set; }

        // The Unreal plugin's GetViewerId().
        /// <summary>Tentacle's own id for this viewer, stable across platforms.</summary>
        public string ViewerId
        {
            get { return Data != null ? Data.Id : ""; }
        }

        /// <summary>The viewer's Twitch profile, or null when they have none.</summary>
        public ViewerTwitch Twitch
        {
            get { return Data != null ? Data.Twitch : null; }
        }

        /// <summary>The viewer's Kick profile, or null when they have none.</summary>
        public ViewerKick Kick
        {
            get { return Data != null ? Data.Kick : null; }
        }

        /// <summary>True when Tentacle marked this viewer as a mock, e.g. a test event.</summary>
        public bool IsMock
        {
            get { return Data != null && Data.IsMock.HasValue && Data.IsMock.Value; }
        }

        // Matches the Unreal plugin's bIsHost.
        /// <summary>
        /// The game's own flag for "this viewer is the streamer". Nothing on the
        /// wire sets it; it is here so a game has one agreed place to put it.
        /// </summary>
        public bool IsHost { get; set; }

        /// <summary>When Tentacle first saw this viewer, as an ISO-8601 string.</summary>
        public string CreatedAt
        {
            get { return Data != null ? Data.CreatedAt : ""; }
        }

        /// <summary>When Tentacle last updated this viewer, as an ISO-8601 string.</summary>
        public string UpdatedAt
        {
            get { return Data != null ? Data.UpdatedAt : ""; }
        }

        // Matches the Unreal plugin's precedence.
        /// <summary>
        /// The viewer's login name: Twitch first, then Kick, then a readable
        /// stand-in built from the id.
        /// </summary>
        public string UserName
        {
            get
            {
                var twitch = Twitch;
                if (twitch != null && !string.IsNullOrEmpty(twitch.Name)) return twitch.Name;
                var kick = Kick;
                if (kick != null && !string.IsNullOrEmpty(kick.Username)) return kick.Username;
                return "Viewer " + ViewerId;
            }
        }

        /// <summary>The viewer's display name, falling back to <see cref="UserName"/>.</summary>
        public string DisplayName
        {
            get
            {
                var twitch = Twitch;
                if (twitch != null && !string.IsNullOrEmpty(twitch.DisplayName)) return twitch.DisplayName;
                return UserName;
            }
        }

        /// <summary>
        /// The viewer's chat colour as an "#RRGGBB" string: Twitch first, then
        /// Kick, then white. <see cref="Color"/> gives the same colour ready to
        /// assign to a material.
        /// </summary>
        public string ColorHex
        {
            get
            {
                var twitch = Twitch;
                if (twitch != null && !string.IsNullOrEmpty(twitch.Color)) return twitch.Color;
                var kick = Kick;
                if (kick != null && !string.IsNullOrEmpty(kick.Color)) return kick.Color;
                return "#FFFFFF";
            }
        }

        /// <summary>
        /// The viewer's chat colour, ready to assign to a material. Falls back
        /// to white for a viewer with no colour on either platform, or one whose
        /// colour the platform sent in a form Unity cannot parse - the colour
        /// comes from a streaming platform, and one of them sending something
        /// unexpected must not take a game down.
        /// </summary>
        public Color Color
        {
            get
            {
                Color parsed;
                return ColorUtility.TryParseHtmlString(ColorHex, out parsed) ? parsed : Color.white;
            }
        }

        /// <summary>
        /// Replaces the viewer's payload and merges the property values it
        /// carries. Called by the cache; not part of the game-facing surface.
        /// </summary>
        internal void ApplyData(ViewerData data, Tentacle_ViewerProperties registry)
        {
            if (data == null) return;
            Data = data;
            MergeProperties(data, registry);
        }

        // Both rules carry over from the Unreal plugin.
        /// <summary>
        /// Folds the property values on a viewer payload into the local map.
        ///
        /// Two rules matter: a value the game wrote and Tentacle has not echoed back is kept, so a
        /// snapshot taken before the write cannot revert it; and a change is only
        /// reported when an already-known value actually changed, so the initial
        /// load does not fire a storm of "changed" callbacks.
        /// </summary>
        private void MergeProperties(ViewerData data, Tentacle_ViewerProperties registry)
        {
            if (data.Properties == null) return;

            foreach (var collection in data.Properties)
            {
                if (collection.Value == null) continue;
                foreach (var definition in collection.Value)
                {
                    if (definition.Value == null) continue;

                    // A definition id the registry has never heard of means the
                    // streamer created the property after the registry loaded.
                    // Asking here rather than on a change covers the first
                    // payload that carries it, which is where it usually appears.
                    if (registry != null) registry.RequestRegistryRefresh(definition.Key);

                    var key = MakeKey(collection.Key, definition.Key);
                    TentacleViewerPropertyEntry existing;
                    var known = properties.TryGetValue(key, out existing);

                    if (known && existing.LocallyModified && !ValuesEqual(existing.Value, definition.Value.Value))
                    {
                        // Our write is still in flight; the server is describing
                        // the world before it.
                        continue;
                    }

                    var changed = known && !ValuesEqual(existing.Value, definition.Value.Value);

                    var entry = known ? existing : new TentacleViewerPropertyEntry();
                    entry.CollectionId = collection.Key;
                    entry.DefinitionId = definition.Key;
                    entry.Value = definition.Value.Value ?? JsonValue.Null;
                    entry.IsDefault = definition.Value.IsDefault;
                    entry.LocallyModified = false;
                    properties[key] = entry;

                    if (changed && registry != null)
                    {
                        registry.NotifyValueChanged(this, entry);
                    }
                }
            }
        }

        /// <summary>Every property value currently held for this viewer.</summary>
        public IEnumerable<TentacleViewerPropertyEntry> Properties
        {
            get { return properties.Values; }
        }

        // Used by the property surface and by tests.
        /// <summary>
        /// Looks a property up by collection and definition id, without going
        /// through the registry.
        /// </summary>
        public bool TryGetEntry(string collectionId, string definitionId, out TentacleViewerPropertyEntry entry)
        {
            return properties.TryGetValue(MakeKey(collectionId, definitionId), out entry);
        }

        /// <summary>
        /// Records a value the game just wrote, so reads see it immediately and a
        /// stale server snapshot cannot undo it. Returns the stored entry.
        /// </summary>
        internal TentacleViewerPropertyEntry ApplyLocalWrite(string collectionId, string definitionId, JsonValue value)
        {
            var key = MakeKey(collectionId, definitionId);
            TentacleViewerPropertyEntry entry;
            if (!properties.TryGetValue(key, out entry))
            {
                entry = new TentacleViewerPropertyEntry();
                properties[key] = entry;
            }
            entry.CollectionId = collectionId;
            entry.DefinitionId = definitionId;
            entry.Value = value ?? JsonValue.Null;
            entry.IsDefault = false;
            entry.LocallyModified = true;
            return entry;
        }

        /// <summary>
        /// Gives up the optimistic hold on a value the game wrote, while the
        /// entry still holds exactly what that write sent.
        ///
        /// The flag exists so a viewer snapshot taken before the write cannot
        /// revert it, and it is normally cleared by Tentacle echoing the value
        /// back. A write that never landed gets no echo, so without this the
        /// entry would stay flagged for the rest of the session: the game would
        /// read its own value forever while Tentacle held a different one, and
        /// every later update for that property would be discarded on the way
        /// in. The value itself is left alone - the next payload Tentacle sends
        /// carries the truth and is no longer thrown away.
        ///
        /// The comparison is what makes this safe: a newer write, or an echo
        /// that already reconciled this one, must not lose its own protection
        /// because an older write reported failure.
        /// </summary>
        internal bool ClearLocalWriteIf(string collectionId, string definitionId, JsonValue written)
        {
            TentacleViewerPropertyEntry entry;
            if (!properties.TryGetValue(MakeKey(collectionId, definitionId), out entry)) return false;
            if (!entry.LocallyModified) return false;
            if (!ValuesEqual(entry.Value, written ?? JsonValue.Null)) return false;

            entry.LocallyModified = false;
            return true;
        }

        /// <summary>
        /// Puts a definition's value back to <paramref name="defaultValue"/>,
        /// which is what a collection- or definition-wide reset does locally
        /// once the server has confirmed it. Clears the local-write flag: the
        /// reset supersedes whatever the game had written.
        /// </summary>
        internal bool ResetToDefault(string collectionId, string definitionId, JsonValue defaultValue)
        {
            TentacleViewerPropertyEntry entry;
            if (!properties.TryGetValue(MakeKey(collectionId, definitionId), out entry)) return false;
            entry.Value = defaultValue ?? JsonValue.Null;
            entry.IsDefault = true;
            entry.LocallyModified = false;
            return true;
        }

        /// <summary>The map key a (collection, definition) pair is stored under.</summary>
        private static string MakeKey(string collectionId, string definitionId)
        {
            return (collectionId ?? "") + "/" + (definitionId ?? "");
        }

        /// <summary>
        /// Whether two property values are the same for reconciliation purposes.
        /// Numbers compare at float precision on purpose: the value made a round
        /// trip through JSON, and demanding bit equality would leave every
        /// locally-written float permanently unreconciled.
        /// </summary>
        internal static bool ValuesEqual(JsonValue left, JsonValue right)
        {
            if (left == null || right == null) return left == right;
            if (left.Kind != right.Kind) return false;
            switch (left.Kind)
            {
                case JsonKind.Null: return true;
                case JsonKind.Bool: return left.AsBool(false) == right.AsBool(false);
                case JsonKind.Number: return (float)left.AsNumber(0.0) == (float)right.AsNumber(0.0);
                case JsonKind.String: return left.AsString("") == right.AsString("");
                default: return left.ToJson() == right.ToJson();
            }
        }
    }
}
