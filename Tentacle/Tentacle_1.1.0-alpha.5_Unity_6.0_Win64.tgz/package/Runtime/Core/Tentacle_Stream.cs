// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_Stream, by name and by event: the owner chose
    // Unreal's strictness for every engine, so there is one event per Twitch and
    // Kick event kind, handed that kind's own type, beside the catch-alls. This
    // class is split in two. The generated half
    // (Runtime/Generated/Stream/Tentacle_Stream.PlatformEvents.cs) declares the
    // per-kind events and RaisePlatformEvent, held to Unreal's Tentacle_Stream.h
    // by a generator test; this half keeps what Unreal writes by hand too - the
    // chat message and chat join events, one message raising several, and the
    // raid window - and the order everything fires in, which is
    // UTentacle_Stream::HandleMsg_Event's.
    /// <summary>
    /// Everything that happens on the stream: chat, follows, subs, bans, and the
    /// game's own chat messages going back out.
    ///
    /// Every Twitch and Kick event kind has an event of its own that hands over
    /// that kind already typed, such as <c>OnCheer_Twitch</c> with a
    /// <see cref="StreamEvent_Twitch_Cheer"/> or <c>OnChannelFollowed_Kick</c>
    /// with a <see cref="StreamEvent_Kick_ChannelFollowed"/>. The kinds both
    /// platforms share also have a cross-platform event, such as
    /// <see cref="OnFollow_Anywhere"/>, and three catch-alls carry every event:
    /// <see cref="OnEvent_Anywhere"/>, <see cref="OnEvent_Twitch"/> and
    /// <see cref="OnEvent_Kick"/>, where a game tells kinds apart by type.
    ///
    /// For one stream event the events fire from the most general to the most
    /// specific: <see cref="OnEvent_Anywhere"/>, then <see cref="OnEvent_Twitch"/>
    /// or <see cref="OnEvent_Kick"/>, then the kind's own event, then its
    /// cross-platform event. A chat message raises the platform's chat events
    /// before the cross-platform ones, and one carrying an emoji or an emote
    /// raises the matching event <em>as well as</em> the message or command event,
    /// after it.
    ///
    /// Features:
    /// - De-duplication by event id, so a reconnect's replay does not re-fire
    ///   handlers the game already ran
    /// - Every event about a viewer carries the cached viewer, so a game never
    ///   resolves ids
    /// - One event per Twitch and Kick event kind, typed as that kind
    /// - Cross-platform "Anywhere" events for the kinds both platforms share,
    ///   with chat split into message and command exactly as the app normalises it
    /// - Handlers run on the thread that pumps the client, never on the socket's
    /// </summary>
    public sealed partial class Tentacle_Stream
    {
        /// <summary>Longest chat message either platform accepts.</summary>
        public const int ChatMessageMaxLength = 500;

        private readonly TentacleClient client;
        private readonly TentacleDeduplicator dedup;

        /// <summary>
        /// Raised for every stream event, whatever its platform or kind, including
        /// kinds this version of the package has no event of its own for. It fires
        /// first, before every other event for the same stream event. The viewer is
        /// the one the event is about, or null for an event about the channel itself.
        /// </summary>
        public event Action<StreamEventBase, Viewer> OnEvent_Anywhere;

        /// <summary>
        /// Raised for every Twitch event, whatever its kind, right after
        /// <see cref="OnEvent_Anywhere"/> and before the kind's own event.
        /// </summary>
        public event Action<StreamEvent_Twitch_Base, Viewer> OnEvent_Twitch;

        /// <summary>
        /// Raised for every Kick event, whatever its kind, right after
        /// <see cref="OnEvent_Anywhere"/> and before the kind's own event.
        /// </summary>
        public event Action<StreamEvent_Kick_Base, Viewer> OnEvent_Kick;

        /// <summary>
        /// Raised when a viewer joins chat, on either platform, right after
        /// <see cref="OnChatJoin_Twitch"/> or <see cref="OnChatJoin_Kick"/>.
        /// </summary>
        public event Action<Viewer> OnChatJoin_Anywhere;

        /// <summary>Raised for a chat message that is not a command, from either platform.</summary>
        public event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessage_Anywhere;

        /// <summary>
        /// Raised for a chat message the app recognised as a command. A command
        /// does NOT also raise <see cref="OnChatMessage_Anywhere"/>, matching how
        /// the app classifies it.
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatCommand_Anywhere;

        /// <summary>
        /// Raised for a chat message carrying at least one emoji, in addition to
        /// <see cref="OnChatMessage_Anywhere"/> or <see cref="OnChatCommand_Anywhere"/>.
        /// Count them with <see cref="ChatMessageUtils.GetEmojiCount"/>.
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmojis_Anywhere;

        /// <summary>
        /// Raised for a chat message carrying at least one emote, in addition to
        /// <see cref="OnChatMessage_Anywhere"/> or <see cref="OnChatCommand_Anywhere"/>.
        /// Count them with <see cref="ChatMessageUtils.GetEmoteCount"/>.
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmotes_Anywhere;

        /// <summary>Raised when a viewer is banned or timed out, from either platform.</summary>
        public event Action<StreamEvent_Anywhere_Ban, Viewer> OnBan_Anywhere;

        /// <summary>
        /// Raised when the channel's title, category, or similar changes. Carries
        /// no viewer: the event describes the channel, not a person.
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChannelUpdate> OnChannelUpdate_Anywhere;

        /// <summary>
        /// Raised when a viewer cheers bits on Twitch. Kick has no donation event,
        /// so this is never raised for Kick.
        /// </summary>
        public event Action<StreamEvent_Anywhere_Donation, Viewer> OnDonation_Anywhere;

        /// <summary>Raised on a new follow, from either platform.</summary>
        public event Action<StreamEvent_Anywhere_Follow, Viewer> OnFollow_Anywhere;

        /// <summary>Raised on a channel-points or reward redemption.</summary>
        public event Action<StreamEvent_Anywhere_Redemption, Viewer> OnRedemption_Anywhere;

        /// <summary>Raised on a first-time subscription.</summary>
        public event Action<StreamEvent_Anywhere_Subscription, Viewer> OnSubscription_Anywhere;

        /// <summary>Raised on gifted subscriptions.</summary>
        public event Action<StreamEvent_Anywhere_SubscriptionGift, Viewer> OnSubscriptionGift_Anywhere;

        /// <summary>Raised when an existing subscription is renewed or resubscribed.</summary>
        public event Action<StreamEvent_Anywhere_SubscriptionRenewal, Viewer> OnSubscriptionRenewal_Anywhere;

        /// <summary>
        /// Raised when a viewer joins your Twitch chat, just before
        /// <see cref="OnChatJoin_Anywhere"/>.
        /// </summary>
        public event Action<Viewer> OnChatJoin_Twitch;

        /// <summary>
        /// Raised for a Twitch chat message that is not a command, before the
        /// cross-platform chat events.
        /// </summary>
        public event Action<StreamEvent_Twitch_ChatMessage, Viewer> OnChatMessage_Twitch;

        /// <summary>
        /// Raised for a Twitch chat message the app recognised as a command. A
        /// command does not also raise <see cref="OnChatMessage_Twitch"/>.
        /// </summary>
        public event Action<StreamEvent_Twitch_ChatMessage, Viewer> OnChatCommand_Twitch;

        /// <summary>
        /// Raised for a Twitch chat message or command carrying at least one
        /// emoji, in addition to <see cref="OnChatMessage_Twitch"/> or
        /// <see cref="OnChatCommand_Twitch"/>.
        /// </summary>
        public event Action<StreamEvent_Twitch_ChatMessage, Viewer> OnChatMessageWithEmojis_Twitch;

        /// <summary>
        /// Raised for a Twitch chat message or command carrying at least one
        /// emote, in addition to <see cref="OnChatMessage_Twitch"/> or
        /// <see cref="OnChatCommand_Twitch"/>.
        /// </summary>
        public event Action<StreamEvent_Twitch_ChatMessage, Viewer> OnChatMessageWithEmotes_Twitch;

        /// <summary>
        /// Raised when a viewer joins your Kick chat, just before
        /// <see cref="OnChatJoin_Anywhere"/>.
        /// </summary>
        public event Action<Viewer> OnChatJoin_Kick;

        /// <summary>
        /// Raised for a Kick chat message that is not a command, before the
        /// cross-platform chat events.
        /// </summary>
        public event Action<StreamEvent_Kick_ChatMessage, Viewer> OnChatMessage_Kick;

        /// <summary>
        /// Raised for a Kick chat message the app recognised as a command. A
        /// command does not also raise <see cref="OnChatMessage_Kick"/>.
        /// </summary>
        public event Action<StreamEvent_Kick_ChatMessage, Viewer> OnChatCommand_Kick;

        /// <summary>
        /// Raised for a Kick chat message or command carrying at least one
        /// emoji, in addition to <see cref="OnChatMessage_Kick"/> or
        /// <see cref="OnChatCommand_Kick"/>.
        /// </summary>
        public event Action<StreamEvent_Kick_ChatMessage, Viewer> OnChatMessageWithEmojis_Kick;

        /// <summary>
        /// Raised for a Kick chat message or command carrying at least one
        /// emote, in addition to <see cref="OnChatMessage_Kick"/> or
        /// <see cref="OnChatCommand_Kick"/>.
        /// </summary>
        public event Action<StreamEvent_Kick_ChatMessage, Viewer> OnChatMessageWithEmotes_Kick;

        /// <summary>
        /// Raised when the game calls <see cref="EndRaid_Twitch"/>. Twitch sends no
        /// "raid over" event, so the game decides when its raid sequence is done
        /// and this is how the rest of the game hears about it.
        /// </summary>
        public event Action OnRaidEnded_Twitch;

        // The Unreal plugin's bIsTwitchRaidOngoing.
        /// <summary>
        /// True from a Twitch raid arriving until <see cref="EndRaid_Twitch"/> is
        /// called.
        /// </summary>
        public bool IsTwitchRaidOngoing { get; private set; }

        /// <summary>Creates the stream surface for a client.</summary>
        internal Tentacle_Stream(TentacleClient client, int deduplicationWindow)
        {
            this.client = client;
            dedup = new TentacleDeduplicator(deduplicationWindow);
        }

        /// <summary>
        /// Declares the current Twitch raid over: clears
        /// <see cref="IsTwitchRaidOngoing"/> and raises
        /// <see cref="OnRaidEnded_Twitch"/>. Safe to call when no raid is running.
        /// </summary>
        public void EndRaid_Twitch()
        {
            IsTwitchRaidOngoing = false;
            Raise(OnRaidEnded_Twitch);
        }

        /// <summary>
        /// Sends a chat message. Fire-and-forget: Tentacle acknowledges nothing,
        /// so there is no completion to await.
        ///
        /// Validation happens here rather than on the far side of the socket,
        /// because a warning in the Unity console is visible to whoever wrote the
        /// call and a rejection inside Tentacle is not.
        /// </summary>
        public void SendChatMessage(
            string message,
            ChatSendTarget target = ChatSendTarget.AllConnected,
            bool isBot = false)
        {
            SendChatMessageInternal(message, target, isBot, null);
        }

        /// <summary>Sends a chat message addressed to one viewer.</summary>
        public void SendChatMessageToViewer(
            Viewer viewer,
            string message,
            ChatSendTarget target = ChatSendTarget.AllConnected,
            bool isBot = false)
        {
            if (viewer == null || string.IsNullOrEmpty(viewer.ViewerId))
            {
                TentacleLog.Warn("Tentacle: not sending a chat message to a null viewer");
                return;
            }
            SendChatMessageInternal(message, target, isBot, viewer.ViewerId);
        }

        /// <summary>
        /// Builds and sends the message. The viewer id is an internal parameter
        /// rather than a public overload, so there is one public way to address a
        /// viewer and it is the one that checks the viewer.
        /// </summary>
        private void SendChatMessageInternal(
            string message,
            ChatSendTarget target,
            bool isBot,
            string viewerId)
        {
            if (string.IsNullOrEmpty(message))
            {
                TentacleLog.Warn("Tentacle: not sending an empty chat message");
                return;
            }
            if (message.Length > ChatMessageMaxLength)
            {
                TentacleLog.Warn(
                    "Tentacle: not sending a chat message of " + message.Length
                    + " characters; both platforms cap it at " + ChatMessageMaxLength);
                return;
            }

            var members = new List<KeyValuePair<string, JsonValue>>
            {
                JsonValue.Member("message", JsonValue.FromString(message)),
                JsonValue.Member("isBot", JsonValue.FromBool(isBot)),
            };

            // Absent fields carry meaning: no platform means every connected one,
            // and no viewerId means the message is addressed to nobody.
            var platform = WirePlatform(target);
            if (platform != null)
            {
                members.Add(JsonValue.Member("platform", JsonValue.FromString(platform)));
            }
            if (!string.IsNullOrEmpty(viewerId))
            {
                members.Add(JsonValue.Member("viewerId", JsonValue.FromString(viewerId)));
            }

            client.SendSocketMessage("Stream_SendChatMessage", JsonValue.FromObject(members));
        }

        // Twitch only, like the Unreal plugin's Fetch Subathon Subscriptions.
        // Unreal reports the count, goal, and progress through a completion
        // delegate; the task here hands back the whole generated type.
        /// <summary>
        /// The subathon subscription counter, or null when the request failed.
        /// Twitch only.
        /// </summary>
        public Task<SubathonStats_Subscriptions> FetchTwitchSubathonSubscriptionsAsync(
            CancellationToken cancellationToken = default)
        {
            return FetchSubathonAsync(
                (http, token) => http.SubsAsync(null, token),
                "subathonStats.subs",
                SubathonStats_Subscriptions.Parse,
                cancellationToken);
        }

        /// <summary>
        /// The subathon gifted-subscription counter, or null when the request
        /// failed. Twitch only.
        /// </summary>
        public Task<SubathonStats_GiftedSubscriptions> FetchTwitchSubathonGiftedSubscriptionsAsync(
            CancellationToken cancellationToken = default)
        {
            return FetchSubathonAsync(
                (http, token) => http.GiftedSubsAsync(null, token),
                "subathonStats.giftedSubs",
                SubathonStats_GiftedSubscriptions.Parse,
                cancellationToken);
        }

        /// <summary>
        /// The subathon donation counter in dollars, or null when the request
        /// failed. Twitch only.
        /// </summary>
        public Task<SubathonStats_Donations> FetchTwitchSubathonDonationsAsync(
            CancellationToken cancellationToken = default)
        {
            return FetchSubathonAsync(
                (http, token) => http.DonationsAsync(null, token),
                "subathonStats.donations",
                SubathonStats_Donations.Parse,
                cancellationToken);
        }

        /// <summary>
        /// Runs one subathon query and parses its payload into the counter's
        /// generated type. The three counters differ only in the procedure and
        /// the type, so they share this rather than each unwrapping the envelope.
        /// </summary>
        private async Task<T> FetchSubathonAsync<T>(
            Func<TentacleHttpClient, CancellationToken, Task<TentacleHttpResult>> call,
            string procedure,
            Func<JsonValue, T> parse,
            CancellationToken cancellationToken)
            where T : class
        {
            var payload = await client.CallAsync(call, procedure, cancellationToken).ConfigureAwait(false);
            return payload == null ? null : parse(payload);
        }

        /// <summary>The wire value for a chat target, or null for "every platform".</summary>
        private static string WirePlatform(ChatSendTarget target)
        {
            switch (target)
            {
                case ChatSendTarget.Twitch: return "twitch";
                case ChatSendTarget.Kick: return "kick";
                default: return null;
            }
        }

        // The Unreal plugin's HandleMsg_ChatJoin: the join carries no platform of
        // its own, so the joining viewer's profiles decide it, Twitch first, and
        // a join that names no viewer raises nothing.
        /// <summary>Handles the payload of an inbound <c>Stream_ChatJoin</c>.</summary>
        internal void HandleChatJoin(JsonValue payload)
        {
            if (payload == null) return;

            var viewerJson = payload["viewer"];
            if (viewerJson == null || viewerJson.Kind != JsonKind.Object) return;

            var data = ViewerData.Parse(viewerJson);
            if (data == null) return;
            var viewer = client.Viewers.UpsertViewer(data);

            if (data.Twitch != null) Raise(OnChatJoin_Twitch, viewer);
            else if (data.Kick != null) Raise(OnChatJoin_Kick, viewer);

            Raise(OnChatJoin_Anywhere, viewer);
        }

        /// <summary>
        /// Handles the payload of an inbound <c>Stream_Event</c>: de-duplicate,
        /// refresh the viewer, then fan out from the most general event to the
        /// most specific.
        /// </summary>
        internal void HandleEvent(JsonValue payload)
        {
            if (payload == null) return;

            var streamEvent = StreamEventBase.Parse(payload["event"]);
            if (streamEvent == null) return;

            if (!dedup.TryAdd(streamEvent.Id)) return;

            // The viewer is only merged once the event survived de-duplication:
            // a replayed event carries a viewer snapshot from when it happened,
            // which is older than what the cache already holds.
            var viewer = client.Viewers.UpsertViewer(payload["viewer"]);

            // A raid opens a window the game closes itself, the same way the
            // Unreal plugin tracks it. Opened before any handler runs, so every
            // one of them - OnRaid_Twitch's included - sees the raid as ongoing.
            if (streamEvent is StreamEvent_Twitch_Raid) IsTwitchRaidOngoing = true;

            // The Unreal plugin's order: the two catch-alls first, then the
            // kind's own event, then the cross-platform event for the kind.
            Raise(OnEvent_Anywhere, streamEvent, viewer);

            var twitch = streamEvent as StreamEvent_Twitch_Base;
            var kick = streamEvent as StreamEvent_Kick_Base;
            if (twitch != null) Raise(OnEvent_Twitch, twitch, viewer);
            else if (kick != null) Raise(OnEvent_Kick, kick, viewer);

            // Chat is the one kind the generated half leaves alone: one message
            // can raise several events on each side.
            var twitchChat = streamEvent as StreamEvent_Twitch_ChatMessage;
            if (twitchChat != null)
            {
                DispatchChatMessage_Twitch(twitchChat, viewer);
                return;
            }
            var kickChat = streamEvent as StreamEvent_Kick_ChatMessage;
            if (kickChat != null)
            {
                DispatchChatMessage_Kick(kickChat, viewer);
                return;
            }

            // A kind with no event of its own is one this version predates, and
            // it has no cross-platform view here either: the catch-alls above
            // were its whole delivery, as on Unreal.
            if (!RaisePlatformEvent(streamEvent, viewer)) return;

            DispatchAnywhere(TentacleAnywhereView.For(streamEvent), viewer);
        }

        // The Unreal plugin's DispatchChatMessage_Twitch, event for event: the
        // command, emoji and emote decisions are read off the cross-platform
        // view, so the two sides always agree, and a message whose view could
        // not be built still reaches OnChatMessage_Twitch.
        /// <summary>Raises the Twitch chat events for one message, then the cross-platform ones.</summary>
        private void DispatchChatMessage_Twitch(StreamEvent_Twitch_ChatMessage chat, Viewer viewer)
        {
            var anywhere = chat.GetAnywhereEvent();

            if (anywhere != null && !string.IsNullOrEmpty(anywhere.Command)) Raise(OnChatCommand_Twitch, chat, viewer);
            else Raise(OnChatMessage_Twitch, chat, viewer);

            if (anywhere.HasEmojis()) Raise(OnChatMessageWithEmojis_Twitch, chat, viewer);
            if (anywhere.HasEmotes()) Raise(OnChatMessageWithEmotes_Twitch, chat, viewer);

            if (anywhere != null) DispatchChatMessage_Anywhere(anywhere, viewer);
        }

        // The Unreal plugin's DispatchChatMessage_Kick; see DispatchChatMessage_Twitch.
        /// <summary>Raises the Kick chat events for one message, then the cross-platform ones.</summary>
        private void DispatchChatMessage_Kick(StreamEvent_Kick_ChatMessage chat, Viewer viewer)
        {
            var anywhere = chat.GetAnywhereEvent();

            if (anywhere != null && !string.IsNullOrEmpty(anywhere.Command)) Raise(OnChatCommand_Kick, chat, viewer);
            else Raise(OnChatMessage_Kick, chat, viewer);

            if (anywhere.HasEmojis()) Raise(OnChatMessageWithEmojis_Kick, chat, viewer);
            if (anywhere.HasEmotes()) Raise(OnChatMessageWithEmotes_Kick, chat, viewer);

            if (anywhere != null) DispatchChatMessage_Anywhere(anywhere, viewer);
        }

        /// <summary>
        /// Raises the cross-platform event matching this Anywhere view. Chat never
        /// arrives here: it goes through the platform's own chat dispatch first.
        /// </summary>
        private void DispatchAnywhere(StreamEventAnywhereBase anywhere, Viewer viewer)
        {
            if (anywhere == null) return;

            var ban = anywhere as StreamEvent_Anywhere_Ban;
            if (ban != null) { Raise(OnBan_Anywhere, ban, viewer); return; }

            var channelUpdate = anywhere as StreamEvent_Anywhere_ChannelUpdate;
            if (channelUpdate != null) { Raise(OnChannelUpdate_Anywhere, channelUpdate); return; }

            var donation = anywhere as StreamEvent_Anywhere_Donation;
            if (donation != null) { Raise(OnDonation_Anywhere, donation, viewer); return; }

            var follow = anywhere as StreamEvent_Anywhere_Follow;
            if (follow != null) { Raise(OnFollow_Anywhere, follow, viewer); return; }

            var redemption = anywhere as StreamEvent_Anywhere_Redemption;
            if (redemption != null) { Raise(OnRedemption_Anywhere, redemption, viewer); return; }

            var renewal = anywhere as StreamEvent_Anywhere_SubscriptionRenewal;
            if (renewal != null) { Raise(OnSubscriptionRenewal_Anywhere, renewal, viewer); return; }

            var gift = anywhere as StreamEvent_Anywhere_SubscriptionGift;
            if (gift != null) { Raise(OnSubscriptionGift_Anywhere, gift, viewer); return; }

            var subscription = anywhere as StreamEvent_Anywhere_Subscription;
            if (subscription != null) Raise(OnSubscription_Anywhere, subscription, viewer);
        }

        // The Unreal plugin's DispatchChatMessage_Anywhere, in its order.
        /// <summary>
        /// Splits one chat message across the cross-platform chat events: command
        /// or message first, then the emoji and emote events for whichever the
        /// message carries.
        /// </summary>
        private void DispatchChatMessage_Anywhere(StreamEvent_Anywhere_ChatMessage chat, Viewer viewer)
        {
            // The app decides what is a command by normalising the message; a
            // command is not also delivered as an ordinary chat message.
            if (!string.IsNullOrEmpty(chat.Command)) Raise(OnChatCommand_Anywhere, chat, viewer);
            else Raise(OnChatMessage_Anywhere, chat, viewer);

            if (chat.HasEmojis()) Raise(OnChatMessageWithEmojis_Anywhere, chat, viewer);
            if (chat.HasEmotes()) Raise(OnChatMessageWithEmotes_Anywhere, chat, viewer);
        }

        /// <summary>Raises a no-argument event, each subscriber on its own.</summary>
        private static void Raise(Action handler)
        {
            TentacleHandlers.Raise(handler, "stream");
        }

        /// <summary>Raises a one-argument event, each subscriber on its own.</summary>
        private static void Raise<T>(Action<T> handler, T argument)
        {
            TentacleHandlers.Raise(handler, argument, "stream");
        }

        /// <summary>Raises a two-argument event, each subscriber on its own.</summary>
        private static void Raise<T>(Action<T, Viewer> handler, T argument, Viewer viewer)
        {
            TentacleHandlers.Raise(handler, argument, viewer, "stream");
        }
    }
}
