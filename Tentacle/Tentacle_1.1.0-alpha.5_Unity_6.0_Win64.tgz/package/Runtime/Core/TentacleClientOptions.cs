// Copyright Tentacle. All Rights Reserved.
using System.Net.Http;

namespace Tcl
{
    /// <summary>
    /// How a <see cref="TentacleClient"/> should behave.
    ///
    /// Every field has a working default, so a game that just wants to connect
    /// only sets <see cref="Identity"/>. <c>Tentacle</c> fills the rest
    /// from the settings asset.
    /// </summary>
    public sealed class TentacleClientOptions
    {
        /// <summary>Who this process says it is in the handshake.</summary>
        public TentacleEngineIdentity Identity = new TentacleEngineIdentity();

        /// <summary>
        /// Where Tentacle is. Null means read it from the file the Tentacle app
        /// publishes its ports in, each time a connection is attempted, which is
        /// what lets a game find an app that started after the game did, or on a
        /// different port.
        /// </summary>
        public TentacleEndpoints Endpoints;

        /// <summary>
        /// Tentacle's data folder, used when <see cref="Endpoints"/> is null.
        /// Null means the platform default.
        /// </summary>
        public string DataDirectory;

        /// <summary>How the delay before each retry grows.</summary>
        public TentacleReconnectPolicy ReconnectPolicy = new TentacleReconnectPolicy();

        /// <summary>Time source for retry delays and the handshake deadline.</summary>
        public ITentacleClock Clock = TentacleStopwatchClock.Instance;

        // The seam exists so the connection state machine can be driven by tests
        // without a port.
        /// <summary>
        /// The session socket. Null means a real WebSocket to Tentacle, which is
        /// what a game always wants.
        /// </summary>
        public ITentacleSocket Socket;

        // A test can supply one over a handler that answers without a network.
        /// <summary>
        /// The HttpClient tRPC requests go through. Null means one of its own,
        /// which is what a game wants. A host that already pools connections can
        /// supply theirs.
        /// </summary>
        public HttpClient HttpClient;

        // The case in between is real: Tentacle never deletes its discovery file
        // on shutdown, so after a fallback-port run the stale file can name a port
        // some other process has since taken, and ClientWebSocket applies no
        // timeout of its own to the upgrade response - without this the client
        // would sit in Connecting for the life of the process.
        /// <summary>
        /// How long one attempt at opening the socket may take before it is
        /// abandoned and retried.
        ///
        /// The peer is on loopback, so a healthy Tentacle answers in milliseconds
        /// and a closed one refuses the connection just as fast. This covers the
        /// case in between: something that accepts the connection and then never
        /// answers, which would otherwise leave the client in
        /// <see cref="ConnectionStatus.Connecting"/> for good.
        /// </summary>
        public double ConnectTimeoutSeconds = 10.0;

        /// <summary>
        /// How long to wait for <c>Session_Welcome</c> after sending the hello.
        /// The server gives a client 10 seconds to say hello and answers at once,
        /// so anything approaching this means the connection is not usable.
        /// </summary>
        public double HandshakeTimeoutSeconds = 10.0;

        /// <summary>
        /// Most inbound items held while the game is not pumping. Roughly a
        /// minute of a very busy chat; past that the oldest are dropped.
        /// </summary>
        public int InboundQueueCapacity = 4096;

        /// <summary>How many recent stream-event ids are remembered for de-duplication.</summary>
        public int StreamDeduplicationWindow = TentacleDeduplicator.DefaultCapacity;

        /// <summary>
        /// Whether to fetch the viewer-property registry as soon as a session
        /// opens. Reads and writes by property name need it, so leaving this on
        /// is what makes them work without the game asking first.
        /// </summary>
        public bool RefreshRegistryOnConnect = true;
    }
}
