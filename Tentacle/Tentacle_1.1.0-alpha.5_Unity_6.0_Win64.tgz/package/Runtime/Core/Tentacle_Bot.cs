// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_Bot, by name and by member: its bIsEnabled
    // and bAreCommandsLoaded lose their b here, as every Unreal boolean does.
    /// <summary>
    /// Tentacle's chat bot, as the streamer configured it: whether it is on, and
    /// every command it answers, kept current.
    ///
    /// Tentacle sends the whole command list as the session opens, and again
    /// whenever the streamer creates, changes, or removes a command or switches
    /// the bot on or off, so what this holds is never more than a moment old.
    /// That is what a game needs to talk about the commands in chat - listing the
    /// ones a viewer can use, say - without keeping a copy of the streamer's
    /// settings.
    ///
    /// Features:
    /// - <see cref="Commands"/> holds every command and phrase, enabled or not,
    ///   with everything the streamer configured on it: who may use it, on which
    ///   platforms, how often, what it replies and what it does
    /// - <see cref="IsEnabled"/> and <see cref="CommandPrefix"/> are the rest of
    ///   what deciding whether a command answers takes
    /// - <see cref="OnCommandsChanged"/> is raised whenever the list changes, and
    ///   not when Tentacle sends the same list again as the session reopens
    /// - The list stays as it was while the session is closed
    /// </summary>
    public sealed class Tentacle_Bot
    {
        private readonly List<BotCommand> commands = new List<BotCommand>();

        /// <summary>The last command list as received, so a list sent again unchanged raises nothing.</summary>
        private string commandsKey;

        /// <summary>
        /// Raised whenever the command list changes, including when the first
        /// list arrives. <see cref="Commands"/> and the rest already hold the new
        /// list when it is raised.
        /// </summary>
        public event Action OnCommandsChanged;

        /// <summary>Every command and phrase the streamer configured, enabled or not, ordered by name.</summary>
        public IReadOnlyList<BotCommand> Commands
        {
            get { return commands; }
        }

        /// <summary>Whether the bot answers in chat at all. When false, no command answers. False until a list arrives.</summary>
        public bool IsEnabled { get; private set; }

        /// <summary>What a chat message starts with to be read as a command, such as "!". Empty until a list arrives.</summary>
        public string CommandPrefix { get; private set; }

        /// <summary>The bot-wide cooldown that spaces out every command, in seconds.</summary>
        public int GlobalCooldownSeconds { get; private set; }

        /// <summary>Whether Tentacle has sent a command list yet. Until it has, <see cref="Commands"/> is empty.</summary>
        public bool AreCommandsLoaded { get; private set; }

        /// <summary>Creates the bot surface.</summary>
        internal Tentacle_Bot()
        {
            CommandPrefix = "";
        }

        // The same trailing option, named the same, as every name lookup.
        /// <summary>
        /// The command or phrase with this name, without the command prefix, or
        /// null. Case-insensitive by default.
        /// </summary>
        public BotCommand FindCommandByName(string name, bool caseSensitive = false)
        {
            if (string.IsNullOrEmpty(name)) return null;
            var comparison = caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            foreach (var command in commands)
            {
                if (string.Equals(command.Name, name, comparison)) return command;
            }
            return null;
        }

        /// <summary>Handles the payload of an inbound <c>Bot_Commands</c>.</summary>
        internal void HandleCommands(JsonValue payload)
        {
            if (payload == null || payload.Kind != JsonKind.Object) return;

            // Tentacle sends the current list every time a session opens, so a
            // list identical to the one held is not a change.
            var key = JsonWriter.Write(payload);
            if (AreCommandsLoaded && key == commandsKey) return;

            var received = BotCommands.Parse(payload);
            if (received == null) return;

            commands.Clear();
            foreach (var command in received.Commands)
            {
                if (command != null) commands.Add(command);
            }
            IsEnabled = received.BotEnabled;
            CommandPrefix = received.CommandPrefix ?? "";
            GlobalCooldownSeconds = received.GlobalCooldownSeconds;
            AreCommandsLoaded = true;
            commandsKey = key;

            TentacleHandlers.Raise(OnCommandsChanged, "bot");
        }
    }
}
