// Copyright Tentacle. All Rights Reserved.
using Tcl.Json;

namespace Tcl
{
    // Unwrapping belongs in one place rather than at each call site, the way
    // the Unreal plugin does it.
    /// <summary>
    /// Unwraps a tRPC response.
    ///
    /// <see cref="TentacleHttpClient"/> hands back the raw body, because what a
    /// procedure returns is the caller's business. Every procedure shares the
    /// same envelope, though, and this takes it off.
    /// </summary>
    public static class TentacleTrpc
    {
        /// <summary>
        /// Pulls <c>result.data</c> out of a response, or returns null when the
        /// request failed or the body was not a tRPC envelope.
        ///
        /// A procedure that legitimately returns nothing yields
        /// <see cref="JsonValue.Null"/>, which is NOT null - that is what lets a
        /// caller tell "the call worked and returned nothing" from "the call
        /// failed".
        /// </summary>
        public static JsonValue Unwrap(TentacleHttpResult result, string procedure)
        {
            if (result == null)
            {
                TentacleLog.Warn("Tentacle: " + procedure + " returned no result");
                return null;
            }

            if (!result.IsSuccess)
            {
                TentacleLog.Warn(
                    "Tentacle: " + procedure + " failed: " + (result.ErrorMessage ?? "unknown error"));
                return null;
            }

            var body = JsonValue.ParseOrNull(result.Body);
            if (body == null || body.Kind != JsonKind.Object)
            {
                TentacleLog.Warn("Tentacle: " + procedure + " answered with something that is not a JSON object");
                return null;
            }

            // An error envelope can arrive with a 200 when the procedure itself
            // reported the failure rather than the transport.
            var error = body["error"];
            if (error != null && error.Kind == JsonKind.Object)
            {
                var message = error["message"];
                TentacleLog.Warn(
                    "Tentacle: " + procedure + " was rejected: "
                    + (message != null ? message.AsString("(no message)") : "(no message)"));
                return null;
            }

            var envelope = body["result"];
            if (envelope == null || envelope.Kind != JsonKind.Object)
            {
                TentacleLog.Warn("Tentacle: " + procedure + " answered without a result envelope");
                return null;
            }

            var data = envelope["data"];
            return data ?? JsonValue.Null;
        }
    }
}
