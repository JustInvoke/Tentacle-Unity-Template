// Copyright Tentacle. All Rights Reserved.
using System;
using Tcl.Json;

namespace Tcl
{
    /// <summary>Severity of a message reported through <see cref="TentacleLog"/>.</summary>
    public enum TentacleLogLevel
    {
        /// <summary>Routine lifecycle information: connected, reconnecting, session opened.</summary>
        Info,

        /// <summary>Something unexpected that the runtime recovered from.</summary>
        Warning,

        /// <summary>A contract violation or a failure the caller's feature depends on.</summary>
        Error,
    }

    // No UnityEngine dependency, so the core stays engine-neutral and testable.
    /// <summary>
    /// Where the package reports diagnostics.
    ///
    /// Features:
    /// - Silent by default; <c>Tentacle</c> installs <see cref="Sink"/>
    ///   once, pointing it at the Unity Console unless the settings asset turns
    ///   that off
    /// - Installing the sink also routes <see cref="Log"/>, the logger of the
    ///   generated types, through it, so a consumer configures one place rather
    ///   than two
    /// - A throwing sink can never take down the caller
    /// </summary>
    public static class TentacleLog
    {
        // Null by default is what keeps the core usable from a plain test host
        // with no engine attached.
        /// <summary>
        /// Where diagnostics go. Null (the default) discards them.
        /// </summary>
        public static Action<TentacleLogLevel, string> Sink;

        /// <summary>Reports routine lifecycle information.</summary>
        public static void Info(string message)
        {
            Emit(TentacleLogLevel.Info, message);
        }

        /// <summary>Reports something unexpected that the runtime recovered from.</summary>
        public static void Warn(string message)
        {
            Emit(TentacleLogLevel.Warning, message);
        }

        /// <summary>Reports a failure the caller's feature depends on.</summary>
        public static void Error(string message)
        {
            Emit(TentacleLogLevel.Error, message);
        }

        /// <summary>
        /// Installs <paramref name="sink"/> for this logger and, translated, for
        /// <see cref="Log"/>. Passing null silences both.
        /// </summary>
        public static void InstallSink(Action<TentacleLogLevel, string> sink)
        {
            Sink = sink;
            if (sink == null)
            {
                Log.Sink = null;
                return;
            }
            Log.Sink = (level, message) =>
            {
                Emit(level == LogLevel.Error ? TentacleLogLevel.Error : TentacleLogLevel.Warning, message);
            };
        }

        /// <summary>Delivers to the sink, swallowing anything the sink throws.</summary>
        private static void Emit(TentacleLogLevel level, string message)
        {
            var sink = Sink;
            if (sink == null) return;
            try
            {
                sink(level, message);
            }
            catch (Exception)
            {
                // A logging sink must never be able to break the code it reports on.
            }
        }
    }
}
