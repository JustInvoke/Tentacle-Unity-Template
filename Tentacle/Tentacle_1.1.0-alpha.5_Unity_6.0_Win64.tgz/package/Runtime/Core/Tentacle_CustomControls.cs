// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_CustomControls, by name and by member.
    /// <summary>
    /// Controls this game puts in Tentacle's custom-controls panel: sliders,
    /// switches, colour pickers, and buttons the streamer drives live.
    ///
    /// This is the code-driven half. Most projects author controls in the scene
    /// instead, with the <c>Custom Control (Slider)</c> family of components,
    /// which register through here and hand the game typed values and events.
    ///
    /// Ownership of a control belongs to the session that registered it, and a
    /// session ends at every disconnect - Tentacle forgets the whole set. So the
    /// registry here is the authority and it is replayed twice: when a new
    /// session opens, and whenever the app asks for it with
    /// <c>CustomControls_Initialize</c> (which is what it sends after its own UI
    /// reconnects). Registering an id the server already has is free, so the
    /// overlap costs nothing.
    ///
    /// Features:
    /// - Registration survives reconnects without the game re-registering
    /// - Duplicate ids are refused, because the app keys events on the id and two
    ///   controls sharing one would both receive every event
    /// - Events are routed to the owning control's handle, never broadcast
    /// </summary>
    public sealed class Tentacle_CustomControls
    {
        private readonly TentacleClient client;

        // The Unreal plugin's equivalent is an array, which keeps registration
        // order the same way.
        /// <summary>
        /// Registration order, which is what <see cref="CustomControls"/> and the
        /// session replay both walk. Kept beside the id index rather than
        /// derived from it, because a dictionary has no order: two controls
        /// sharing a sort index should land in Tentacle in the order the game
        /// registered them, run after run.
        /// </summary>
        private readonly List<TentacleControlHandle> order = new List<TentacleControlHandle>();

        private readonly Dictionary<string, TentacleControlHandle> handles =
            new Dictionary<string, TentacleControlHandle>();

        /// <summary>
        /// Raised for every inbound control event, after it has been applied to
        /// its control and its handle's own event has fired. Useful for logging
        /// or for a game that prefers one handler over per-control ones.
        /// </summary>
        public event Action<TentacleControlHandle, CustomControlEvent> OnControlEvent;

        /// <summary>Creates the custom-controls surface for a client.</summary>
        internal Tentacle_CustomControls(TentacleClient client)
        {
            this.client = client;
        }

        /// <summary>Every control currently registered, in registration order.</summary>
        public IReadOnlyList<TentacleControlHandle> CustomControls
        {
            get { return order; }
        }

        /// <summary>The handle for a control id, or null.</summary>
        public TentacleControlHandle FindCustomControlById(string controlId)
        {
            if (string.IsNullOrEmpty(controlId)) return null;
            TentacleControlHandle handle;
            return handles.TryGetValue(controlId, out handle) ? handle : null;
        }

        /// <summary>
        /// Registers a control and returns its handle, or null when the control
        /// cannot be registered (no id, an unknown control type, or an id that is
        /// already taken). Registering works whether or not Tentacle is currently
        /// connected: the control is sent as soon as a session opens.
        /// </summary>
        public TentacleControlHandle RegisterCustomControl(CustomControl control)
        {
            if (control == null)
            {
                TentacleLog.Warn("Tentacle: cannot register a null control");
                return null;
            }
            if (string.IsNullOrEmpty(control.Id))
            {
                TentacleLog.Warn("Tentacle: cannot register a control with no id");
                return null;
            }
            if (TentacleControlJson.DiscriminatorFor(control) == null)
            {
                // ToJson would log the same thing, but refusing here keeps the
                // registry free of controls that could never be sent.
                TentacleLog.Error(
                    "Tentacle: cannot register control \"" + control.Id + "\" of type "
                    + control.GetType().Name + "; use one of the CustomControl_* subclasses");
                return null;
            }
            if (handles.ContainsKey(control.Id))
            {
                TentacleLog.Warn(
                    "Tentacle: control \"" + control.Id + "\" is already registered; "
                    + "ids must be unique within a session");
                return null;
            }

            var handle = new TentacleControlHandle(this, control);
            handles[control.Id] = handle;
            order.Add(handle);
            Send("CustomControls_RegisterControl", control);
            return handle;
        }

        /// <summary>Removes a control by id. False when nothing was registered under it.</summary>
        public bool UnregisterCustomControl(string controlId)
        {
            var handle = FindCustomControlById(controlId);
            if (handle == null) return false;
            UnregisterCustomControl(handle);
            return true;
        }

        /// <summary>Removes a control. Safe to call for an already-removed handle.</summary>
        internal void UnregisterCustomControl(TentacleControlHandle handle)
        {
            if (handle == null || !handle.IsRegistered) return;
            handle.IsRegistered = false;
            handles.Remove(handle.Id);
            order.Remove(handle);
            Send("CustomControls_UnregisterControl", handle.Control);
        }

        /// <summary>Sends a control's current state. Ignored for an unregistered handle.</summary>
        internal void PushState(TentacleControlHandle handle)
        {
            if (handle == null) return;
            if (!handle.IsRegistered)
            {
                TentacleLog.Warn(
                    "Tentacle: not sending state for control \"" + handle.Id + "\"; it is not registered");
                return;
            }
            Send("CustomControls_ControlState", handle.Control);
        }

        /// <summary>Removes every control, without telling Tentacle. Used on shutdown.</summary>
        internal void Clear()
        {
            foreach (var handle in order) handle.IsRegistered = false;
            handles.Clear();
            order.Clear();
        }

        /// <summary>
        /// Re-sends every registered control. Runs when a session opens and when
        /// the app asks for it, because Tentacle drops a session's controls the
        /// moment the socket closes.
        /// </summary>
        internal void ReRegisterAll()
        {
            foreach (var handle in order)
            {
                Send("CustomControls_RegisterControl", handle.Control);
            }
        }

        /// <summary>Routes the payload of an inbound control event to the control it addresses.</summary>
        internal void HandleControlEvent(JsonValue payload)
        {
            if (payload == null) return;

            var controlEvent = CustomControlEvent.Parse(payload["event"]);
            if (controlEvent == null) return;

            var handle = FindCustomControlById(controlEvent.ControlId);
            if (handle == null)
            {
                // Tentacle only sends events for controls this session owns, so
                // this means a control was unregistered while a click was in
                // flight - a race, not a bug.
                TentacleLog.Warn(
                    "Tentacle: a control event arrived for \"" + controlEvent.ControlId
                    + "\", which this session does not have registered");
                return;
            }

            handle.Deliver(controlEvent);
            TentacleHandlers.Raise(OnControlEvent, handle, controlEvent, "control-event");
        }

        /// <summary>
        /// Serializes a control and sends it under the given message type.
        ///
        /// Sent as optional: a game registers its controls at start-up, usually
        /// before the first connection has completed, and warning about each one
        /// would be noise for something the session replay handles.
        /// </summary>
        private void Send(string messageType, CustomControl control)
        {
            var json = TentacleControlJson.ToJson(control);
            if (json == null) return;
            client.SendSocketMessage(
                messageType,
                JsonValue.Object(JsonValue.Member("control", json)),
                false);
        }
    }
}
