// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_Viewers, by name and by member. Unbounded
    // matches the Unreal plugin.
    /// <summary>
    /// Every viewer Tentacle has told this session about, keyed by viewer id.
    ///
    /// This exists so a viewer is one object rather than one per message. Stream
    /// events, chat joins, and custom events all carry a full
    /// viewer payload, and without a cache a game that spawns an actor per
    /// chatter would get a fresh, unrelated viewer object on that chatter's next
    /// message - property writes would land on an orphan and nothing would
    /// accumulate.
    ///
    /// Deliberately unbounded. An eviction policy
    /// would break exactly the guarantee the cache exists for: a game holding a
    /// viewer would silently stop seeing its updates once a later viewer pushed
    /// it out, and there is no way from here to know which viewers the game still
    /// cares about. Entries are small, the cache lives only as long as the play
    /// session, and <see cref="DestroyViewer"/> / <see cref="DestroyAllViewers"/>
    /// are public for a game that runs long enough to want to prune.
    ///
    /// Features:
    /// - Stable identity: the same viewer id always yields the same instance
    /// - <see cref="OnViewerAdded"/> fires once per viewer, never on a refresh
    /// - Touched only on the thread that pumps the client, so no locking
    /// </summary>
    public sealed class Tentacle_Viewers
    {
        private readonly Dictionary<string, Viewer> viewers = new Dictionary<string, Viewer>();
        private readonly Tentacle_ViewerProperties registry;

        /// <summary>Raised the first time a viewer is seen. Not raised on later updates.</summary>
        public event Action<Viewer> OnViewerAdded;

        /// <summary>Creates a cache that reports property changes through <paramref name="registry"/>.</summary>
        internal Tentacle_Viewers(Tentacle_ViewerProperties registry)
        {
            this.registry = registry;
        }

        /// <summary>How many viewers are cached.</summary>
        public int ViewerCount
        {
            get { return viewers.Count; }
        }

        /// <summary>Every cached viewer.</summary>
        public IEnumerable<Viewer> AllViewers
        {
            get { return viewers.Values; }
        }

        /// <summary>
        /// Merges a viewer payload into the cache and returns the viewer.
        /// Null for a null payload or one with no id, which is what a malformed
        /// frame produces - the caller carries on without a viewer rather than
        /// dropping the event.
        /// </summary>
        public Viewer UpsertViewer(ViewerData data)
        {
            if (data == null || string.IsNullOrEmpty(data.Id)) return null;

            Viewer viewer;
            var isNew = !viewers.TryGetValue(data.Id, out viewer);
            if (isNew)
            {
                viewer = new Viewer();
                viewers[data.Id] = viewer;
            }

            viewer.ApplyData(data, registry);

            // Each subscriber on its own: this runs inside the dispatch of the
            // event that brought the viewer, and a throw here must not cost
            // that event its own handlers.
            if (isNew) TentacleHandlers.Raise(OnViewerAdded, viewer, "viewer-added");
            return viewer;
        }

        /// <summary>
        /// Merges a viewer payload that arrived as raw JSON. Null when the value
        /// is absent or is not an object, which is the ordinary case: a
        /// channel-scoped event (a stream going live, a poll ending) has no
        /// viewer, so this must stay quiet rather than warn on every one.
        /// </summary>
        public Viewer UpsertViewer(JsonValue viewerJson)
        {
            if (viewerJson == null || viewerJson.Kind != JsonKind.Object) return null;
            return UpsertViewer(ViewerData.Parse(viewerJson));
        }

        /// <summary>The cached viewer with this id, or null.</summary>
        public Viewer FindViewerById(string viewerId)
        {
            if (string.IsNullOrEmpty(viewerId)) return null;
            Viewer viewer;
            return viewers.TryGetValue(viewerId, out viewer) ? viewer : null;
        }

        /// <summary>
        /// Forgets one viewer, and reports whether it was cached. Anything already
        /// holding it keeps working.
        /// </summary>
        public bool DestroyViewer(string viewerId)
        {
            return !string.IsNullOrEmpty(viewerId) && viewers.Remove(viewerId);
        }

        /// <summary>Forgets every viewer.</summary>
        public void DestroyAllViewers()
        {
            viewers.Clear();
        }
    }
}
