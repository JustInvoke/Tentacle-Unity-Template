// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_ViewerProperties, by name and by member. The
    // per-viewer reads and writes are also reachable on the viewer itself, as
    // Unreal has them on UTclViewer (see TentacleViewerPropertyExtensions).
    /// <summary>
    /// The per-viewer values the streamer defined in Tentacle: scores, levels,
    /// currencies, flags - anything the game reads and writes per viewer.
    ///
    /// Values travel on the viewer payload of every message, keyed by collection
    /// and definition id; names live only in the registry, which this fetches
    /// over tRPC. So the registry has to be loaded before a name-based read can
    /// resolve, and <see cref="RefreshRegistryAsync"/> is called once when a
    /// session opens.
    ///
    /// Features:
    /// - Reads and writes by collection and property NAME, never by id
    /// - Writes are optimistic: the local value changes immediately and survives
    ///   a viewer snapshot that predates the write - and gives way again if the
    ///   write turns out never to have reached Tentacle
    /// - Definitions are never created from here; a name the streamer has not
    ///   defined is an error the caller sees, not a silent new property
    /// - Every remote call degrades into a false / null result, never an
    ///   exception into a game loop
    /// </summary>
    public sealed class Tentacle_ViewerProperties
    {
        private readonly TentacleClient client;
        private readonly List<ViewerPropertyCollection> collections = new List<ViewerPropertyCollection>();
        private readonly List<ViewerPropertyDefinition> definitions = new List<ViewerPropertyDefinition>();
        private readonly Dictionary<string, ViewerPropertyCollection> collectionsById =
            new Dictionary<string, ViewerPropertyCollection>();
        private readonly Dictionary<string, ViewerPropertyDefinition> definitionsById =
            new Dictionary<string, ViewerPropertyDefinition>();

        /// <summary>
        /// Definition ids a refresh has already been requested for, so a property
        /// the streamer created at runtime costs one refresh and never more.
        /// </summary>
        private readonly HashSet<string> requestedDefinitionRefreshIds = new HashSet<string>();

        /// <summary>True while a recovery refresh is in flight; coalesces the rest.</summary>
        private bool registryRefreshPending;

        // The Unreal plugin's bIsInitialLoadComplete.
        /// <summary>
        /// True once the registry has been fetched at least once.
        /// </summary>
        public bool IsInitialLoadComplete { get; private set; }

        /// <summary>Every collection the streamer defined.</summary>
        public IReadOnlyList<ViewerPropertyCollection> Collections
        {
            get { return collections; }
        }

        /// <summary>Every property definition the streamer defined, across all collections.</summary>
        public IReadOnlyList<ViewerPropertyDefinition> Definitions
        {
            get { return definitions; }
        }

        /// <summary>
        /// Raised once, the first time the registry loads. A game that only needs
        /// to know when reads start working subscribes here rather than counting
        /// loads.
        /// </summary>
        public event Action OnInitialLoadComplete;

        /// <summary>
        /// Raised every time the registry is loaded or reloaded, the initial load
        /// included.
        /// </summary>
        public event Action OnCollectionsRefreshed;

        // The Unreal plugin's OnViewerPropertyUpdated, in its parameter order:
        // collection, viewer, then what changed. Unreal passes the property's
        // name and type; the definition carries both.
        /// <summary>
        /// Raised when a viewer's property value changes to something new, with
        /// the collection, the viewer, and the definition of the property that
        /// changed. Not raised the first time a value is seen: an initial load is
        /// not a change, and treating it as one would fire this for every property
        /// of every viewer the moment a stream gets busy.
        /// </summary>
        public event Action<ViewerPropertyCollection, Viewer, ViewerPropertyDefinition> OnViewerPropertyUpdated;

        /// <summary>Creates the viewer-property surface for a client.</summary>
        internal Tentacle_ViewerProperties(TentacleClient client)
        {
            this.client = client;
        }

        /// <summary>
        /// Fetches the registry of collections and definitions. Returns false
        /// when the request failed, in which case the registry already loaded
        /// (if any) is kept rather than being cleared.
        ///
        /// The new registry is applied, and <see cref="OnInitialLoadComplete"/>
        /// and <see cref="OnCollectionsRefreshed"/> raised, in the next Pump, like
        /// every other thing a game sees; the task completes once that has
        /// happened. Await it rather than blocking the pumping thread on it.
        /// </summary>
        public async Task<bool> RefreshRegistryAsync(CancellationToken cancellationToken = default)
        {
            var payload = await client
                .CallAsync((http, token) => http.GetRegistryAsync(null, token), "viewerProperty.getRegistry", cancellationToken)
                .ConfigureAwait(false);
            if (payload == null) return false;

            var registry = ViewerPropertyRegistry.Parse(payload);
            if (registry == null) return false;

            // The answer arrives on whichever thread the HTTP client completed
            // on. Applying it there would change the registry under a game that
            // is reading it, and raise the registry events off the main thread,
            // where a Unity handler touching the scene throws.
            return await client.RunOnPumpAsync(() => ApplyRegistry(registry)).ConfigureAwait(false);
        }

        // Split out from the fetch so a test can exercise name resolution and the
        // read/write paths without a server.
        /// <summary>
        /// Replaces the registry wholesale.
        /// </summary>
        internal void ApplyRegistry(ViewerPropertyRegistry registry)
        {
            if (registry == null) return;

            collections.Clear();
            definitions.Clear();
            collectionsById.Clear();
            definitionsById.Clear();

            foreach (var collection in registry.Collections)
            {
                if (collection == null) continue;
                collections.Add(collection);
                collectionsById[collection.Id] = collection;
            }
            foreach (var definition in registry.Definitions)
            {
                if (definition == null) continue;
                definitions.Add(definition);
                definitionsById[definition.Id] = definition;
            }

            registryRefreshPending = false;

            var wasFirst = !IsInitialLoadComplete;
            IsInitialLoadComplete = true;
            if (wasFirst) Raise(OnInitialLoadComplete);
            Raise(OnCollectionsRefreshed);
        }

        // The counterpart of the Unreal plugin's RequestRegistryRefresh, and it
        // exists for the same reason.
        /// <summary>
        /// Asks for one registry refresh because a viewer payload carried a
        /// definition id the registry does not know.
        ///
        /// The streamer can add a property while the
        /// game is running, and without this every read of that property would
        /// answer PropertyNotFound for the rest of the session. Each distinct id
        /// triggers at most one refresh, and only one refresh is ever in flight,
        /// so a busy stream full of unknown ids cannot spin the backend.
        /// </summary>
        internal void RequestRegistryRefresh(string definitionId)
        {
            if (string.IsNullOrEmpty(definitionId)) return;
            if (definitionsById.ContainsKey(definitionId)) return;
            if (!requestedDefinitionRefreshIds.Add(definitionId)) return;

            ScheduleRegistryRefresh();
        }

        /// <summary>
        /// Says in the log that a name could not resolve because the registry is
        /// still in flight, makes sure a load is on its way, and answers
        /// CollectionNotFound.
        ///
        /// Not its own result member: the state resolves itself, so a game would
        /// have nothing to do with it that waiting would not also do. What a
        /// game needs is to know why the read came back empty, and that belongs
        /// in the log rather than in every call site's branching.
        /// </summary>
        private FindPropertyResult ReportRegistryNotLoaded(
            string collectionName, string propertyName, string verb)
        {
            TentacleLog.Warn(
                "Tentacle: viewer property \"" + collectionName + "/" + propertyName + "\" was " + verb
                + " before the property registry loaded; a load has been requested and it will resolve"
                + " once that arrives");

            // A read this early usually means the game got ahead of the first
            // connect, where the registry is already on its way. Asking again is
            // single-flight, so the case where it is not - a failed first fetch -
            // recovers instead of staying broken for the session.
            ScheduleRegistryRefresh();
            return FindPropertyResult.CollectionNotFound;
        }

        /// <summary>
        /// Starts one registry fetch unless one is already in flight. Shared by
        /// the unknown-definition recovery and the not-yet-loaded path, so a busy
        /// frame asking repeatedly still costs one request.
        /// </summary>
        private void ScheduleRegistryRefresh()
        {
            if (registryRefreshPending) return;

            registryRefreshPending = true;
            TentacleClient.Forget(
                RefreshRegistryAsync().ContinueWith(
                    completed => client.Post(() => registryRefreshPending = false),
                    CancellationToken.None,
                    TaskContinuationOptions.ExecuteSynchronously,
                    TaskScheduler.Default),
                "viewer-property registry recovery refresh");
        }

        /// <summary>The collection with this name, or null. Case-insensitive by default.</summary>
        public ViewerPropertyCollection FindCollectionByName(string name, bool caseSensitive = false)
        {
            if (string.IsNullOrEmpty(name)) return null;
            var comparison = caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            foreach (var collection in collections)
            {
                if (string.Equals(collection.Name, name, comparison)) return collection;
            }
            return null;
        }

        /// <summary>The collection with this id, or null.</summary>
        public ViewerPropertyCollection FindCollectionById(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            ViewerPropertyCollection collection;
            return collectionsById.TryGetValue(id, out collection) ? collection : null;
        }

        /// <summary>The definition with this name inside this collection, or null.</summary>
        public ViewerPropertyDefinition FindDefinitionByName(
            string collectionName, string propertyName, bool caseSensitive = false)
        {
            var collection = FindCollectionByName(collectionName, caseSensitive);
            if (collection == null) return null;
            return FindDefinitionIn(collection, propertyName, caseSensitive);
        }

        /// <summary>The definition with this name inside a known collection, or null.</summary>
        private ViewerPropertyDefinition FindDefinitionIn(
            ViewerPropertyCollection collection,
            string propertyName,
            bool caseSensitive)
        {
            if (collection == null || string.IsNullOrEmpty(propertyName)) return null;
            var comparison = caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            foreach (var definition in definitions)
            {
                if (definition.CollectionId == collection.Id
                    && string.Equals(definition.Name, propertyName, comparison))
                {
                    return definition;
                }
            }
            return null;
        }

        /// <summary>
        /// Reads a viewer's raw property value. The out value is
        /// <see cref="JsonValue.Null"/> unless the result is
        /// <see cref="FindPropertyResult.Found"/>.
        /// </summary>
        public FindPropertyResult GetPropertyValue(
            Viewer viewer,
            string collectionName,
            string propertyName,
            out JsonValue value,
            bool caseSensitive = false)
        {
            value = JsonValue.Null;
            if (viewer == null)
            {
                // Reported rather than folded silently into PropertyNotFound: the
                // property may well exist, and sending whoever is debugging to
                // look at the registry would waste their time.
                TentacleLog.Warn(
                    "Tentacle: cannot read viewer property \"" + propertyName + "\" without a viewer");
                return FindPropertyResult.PropertyNotFound;
            }
            if (!IsInitialLoadComplete) return ReportRegistryNotLoaded(collectionName, propertyName, "read");

            var collection = FindCollectionByName(collectionName, caseSensitive);
            if (collection == null) return FindPropertyResult.CollectionNotFound;

            var definition = FindDefinitionIn(collection, propertyName, caseSensitive);
            if (definition == null) return FindPropertyResult.PropertyNotFound;

            TentacleViewerPropertyEntry entry;
            if (!viewer.TryGetEntry(collection.Id, definition.Id, out entry))
            {
                // The definition exists but this viewer's payload did not carry
                // it, which happens for a viewer fetched before the definition
                // was created. The definition's own default is the right answer.
                value = definition.Value ?? JsonValue.Null;
                return FindPropertyResult.Found;
            }

            value = entry.Value ?? JsonValue.Null;
            return FindPropertyResult.Found;
        }

        // Matches the Unreal plugin's GetPropertyType, which answers String for
        // an unknown property rather than failing.
        /// <summary>
        /// The declared type of a named property, or
        /// <see cref="ViewerPropertyType.String"/> when the registry does not
        /// know it.
        /// </summary>
        public ViewerPropertyType GetPropertyType(
            string collectionName, string propertyName, bool caseSensitive = false)
        {
            var definition = FindDefinitionByName(collectionName, propertyName, caseSensitive);
            return definition != null ? definition.Type : ViewerPropertyType.String;
        }

        /// <summary>Reads a viewer's property as a string.</summary>
        public FindPropertyResult GetProperty_String(
            Viewer viewer, string collectionName, string propertyName, out string value, bool caseSensitive = false)
        {
            JsonValue raw;
            var result = GetPropertyValue(viewer, collectionName, propertyName, out raw, caseSensitive);
            value = result == FindPropertyResult.Found ? raw.AsString("") : "";
            return result;
        }

        /// <summary>Reads a viewer's property as a floating-point number.</summary>
        public FindPropertyResult GetProperty_Float(
            Viewer viewer, string collectionName, string propertyName, out double value, bool caseSensitive = false)
        {
            JsonValue raw;
            var result = GetPropertyValue(viewer, collectionName, propertyName, out raw, caseSensitive);
            value = result == FindPropertyResult.Found ? raw.AsNumber(0.0) : 0.0;
            return result;
        }

        /// <summary>
        /// Reads a viewer's property as a whole number. Values cross the wire as
        /// JSON numbers, so this is bounded by the same 2^53 safe-integer range
        /// the app documents, not by long.
        /// </summary>
        public FindPropertyResult GetProperty_Int(
            Viewer viewer, string collectionName, string propertyName, out long value, bool caseSensitive = false)
        {
            JsonValue raw;
            var result = GetPropertyValue(viewer, collectionName, propertyName, out raw, caseSensitive);
            value = result == FindPropertyResult.Found ? (long)raw.AsNumber(0.0) : 0L;
            return result;
        }

        /// <summary>Reads a viewer's property as a boolean.</summary>
        public FindPropertyResult GetProperty_Bool(
            Viewer viewer, string collectionName, string propertyName, out bool value, bool caseSensitive = false)
        {
            JsonValue raw;
            var result = GetPropertyValue(viewer, collectionName, propertyName, out raw, caseSensitive);
            value = result == FindPropertyResult.Found && raw.AsBool(false);
            return result;
        }

        /// <summary>Writes a string property for one viewer.</summary>
        public SetPropertyResult SetProperty_String(
            Viewer viewer, string collectionName, string propertyName, string value, bool caseSensitive = false)
        {
            return Set(viewer, collectionName, propertyName, JsonValue.FromString(value ?? ""), caseSensitive);
        }

        /// <summary>Writes a floating-point property for one viewer.</summary>
        public SetPropertyResult SetProperty_Float(
            Viewer viewer, string collectionName, string propertyName, double value, bool caseSensitive = false)
        {
            return Set(viewer, collectionName, propertyName, JsonValue.FromNumber(value), caseSensitive);
        }

        /// <summary>Writes a whole-number property for one viewer.</summary>
        public SetPropertyResult SetProperty_Int(
            Viewer viewer, string collectionName, string propertyName, long value, bool caseSensitive = false)
        {
            return Set(viewer, collectionName, propertyName, JsonValue.FromNumber(value), caseSensitive);
        }

        /// <summary>Writes a boolean property for one viewer.</summary>
        public SetPropertyResult SetProperty_Bool(
            Viewer viewer, string collectionName, string propertyName, bool value, bool caseSensitive = false)
        {
            return Set(viewer, collectionName, propertyName, JsonValue.FromBool(value), caseSensitive);
        }

        // Unreal returns the resulting value and reports the outcome through an
        // out parameter; C#'s TryGet shape turns that round, the same as the reads.
        /// <summary>
        /// Adds <paramref name="amount"/> (positive, negative, or zero) to a
        /// floating-point property, and hands back the value it wrote in
        /// <paramref name="newValue"/>, or 0 when the write did not happen. The
        /// current value is read back through <see cref="GetProperty_Float"/>,
        /// so it reflects an earlier write that is still on its way to Tentacle.
        /// </summary>
        public SetPropertyResult AddToProperty_Float(
            Viewer viewer,
            string collectionName,
            string propertyName,
            double amount,
            out double newValue,
            bool caseSensitive = false)
        {
            newValue = 0.0;
            double current;
            var read = GetProperty_Float(viewer, collectionName, propertyName, out current, caseSensitive);
            if (read != FindPropertyResult.Found) return ToSetResult(read);

            var result = SetProperty_Float(viewer, collectionName, propertyName, current + amount, caseSensitive);
            if (result == SetPropertyResult.Success) newValue = current + amount;
            return result;
        }

        /// <summary>
        /// Adds <paramref name="amount"/> (positive, negative, or zero) to a
        /// whole-number property, and hands back the value it wrote in
        /// <paramref name="newValue"/>, or 0 when the write did not happen.
        /// </summary>
        public SetPropertyResult AddToProperty_Int(
            Viewer viewer,
            string collectionName,
            string propertyName,
            long amount,
            out long newValue,
            bool caseSensitive = false)
        {
            newValue = 0L;
            long current;
            var read = GetProperty_Int(viewer, collectionName, propertyName, out current, caseSensitive);
            if (read != FindPropertyResult.Found) return ToSetResult(read);

            var result = SetProperty_Int(viewer, collectionName, propertyName, current + amount, caseSensitive);
            if (result == SetPropertyResult.Success) newValue = current + amount;
            return result;
        }

        /// <summary>
        /// Flips a boolean property to its opposite, and hands back the value it
        /// wrote in <paramref name="newValue"/>, or false when the write did not
        /// happen.
        /// </summary>
        public SetPropertyResult ToggleProperty_Bool(
            Viewer viewer,
            string collectionName,
            string propertyName,
            out bool newValue,
            bool caseSensitive = false)
        {
            newValue = false;
            bool current;
            var read = GetProperty_Bool(viewer, collectionName, propertyName, out current, caseSensitive);
            if (read != FindPropertyResult.Found) return ToSetResult(read);

            var result = SetProperty_Bool(viewer, collectionName, propertyName, !current, caseSensitive);
            if (result == SetPropertyResult.Success) newValue = !current;
            return result;
        }

        /// <summary>The write outcome matching a lookup outcome, so the two enums cannot drift.</summary>
        private static SetPropertyResult ToSetResult(FindPropertyResult result)
        {
            switch (result)
            {
                case FindPropertyResult.CollectionNotFound: return SetPropertyResult.CollectionNotFound;
                case FindPropertyResult.PropertyNotFound: return SetPropertyResult.PropertyNotFound;
                default: return SetPropertyResult.Success;
            }
        }

        /// <summary>
        /// Applies a write locally and sends it to Tentacle.
        ///
        /// The local value changes first, so the next read sees it even though
        /// the request is still in flight, and it is flagged so a viewer snapshot
        /// that predates the write cannot revert it. A mock viewer (one Tentacle
        /// synthesised for a test event) is updated locally and never sent: it
        /// has no row to write to.
        /// </summary>
        private SetPropertyResult Set(
            Viewer viewer,
            string collectionName,
            string propertyName,
            JsonValue value,
            bool caseSensitive)
        {
            if (viewer == null)
            {
                TentacleLog.Warn(
                    "Tentacle: cannot write viewer property \"" + propertyName + "\" without a viewer");
                return SetPropertyResult.PropertyNotFound;
            }
            if (!IsInitialLoadComplete)
            {
                return ToSetResult(ReportRegistryNotLoaded(collectionName, propertyName, "written"));
            }

            var collection = FindCollectionByName(collectionName, caseSensitive);
            if (collection == null) return SetPropertyResult.CollectionNotFound;

            var definition = FindDefinitionIn(collection, propertyName, caseSensitive);
            if (definition == null) return SetPropertyResult.PropertyNotFound;

            viewer.ApplyLocalWrite(collection.Id, definition.Id, value);
            RaiseViewerPropertyUpdated(collection, viewer, definition);

            if (viewer.IsMock) return SetPropertyResult.Success;

            // setForViewer takes an array of entries; this sends one, addressed
            // by definition id so a rename between the registry load and the
            // write cannot send it to the wrong property.
            var entry = JsonValue.Object(
                JsonValue.Member("definitionId", JsonValue.FromString(definition.Id)),
                JsonValue.Member("viewerId", JsonValue.FromString(viewer.ViewerId)),
                JsonValue.Member("value", value));
            var input = JsonValue.FromArray(new[] { entry }).ToJson();

            // Fire-and-forget: the local value already changed, and a game
            // writing a score per kill must not have to await a round trip. The
            // outcome is still not ignored - see below.
            var write = client.CallForSuccessAsync(
                (http, token) => http.SetForViewerAsync(input, token),
                "viewerProperty.setForViewer",
                CancellationToken.None);
            TentacleClient.Forget(write, "viewerProperty.setForViewer");
            ReleaseTheLocalHoldIfTheWriteFails(write, viewer, collection.Id, definition.Id, value);

            return SetPropertyResult.Success;
        }

        /// <summary>
        /// Hands a value back to the server when its write did not reach
        /// Tentacle.
        ///
        /// The write is not awaited, but its result is the only thing that can
        /// tell an in-flight write from one that will never land. Until Tentacle
        /// echoes the value back, every payload carrying a different one for
        /// that property is discarded so a stale snapshot cannot revert the
        /// write; if the write failed - Tentacle closed, the request rejected -
        /// that echo never comes, so without this the game would read its own
        /// value for the rest of the session while Tentacle held the real one,
        /// and nothing would ever reconcile them.
        ///
        /// Only the optimistic flag is released, on the pumping thread, and only
        /// while the entry still holds what this write sent. The value stays as
        /// the game last saw it until Tentacle sends the real one, which is the
        /// same shape as any other value waiting on an update.
        /// </summary>
        private void ReleaseTheLocalHoldIfTheWriteFails(
            Task<bool> write,
            Viewer viewer,
            string collectionId,
            string definitionId,
            JsonValue written)
        {
            write.ContinueWith(
                completed =>
                {
                    if (completed.Status == TaskStatus.RanToCompletion && completed.Result) return;

                    // Back onto the thread that pumps: the viewer cache and the
                    // values a game reads are only ever touched there.
                    client.Post(() =>
                    {
                        if (!viewer.ClearLocalWriteIf(collectionId, definitionId, written)) return;
                        TentacleLog.Warn(
                            "Tentacle: a viewer-property write did not reach Tentacle; the local value "
                            + "stands until Tentacle sends its own");
                    });
                },
                CancellationToken.None,
                TaskContinuationOptions.ExecuteSynchronously,
                TaskScheduler.Default);
        }

        /// <summary>
        /// Puts every value in a collection back to its definition's default, for
        /// every viewer. Returns false when the request failed, in which case
        /// nothing is changed locally either.
        ///
        /// Once Tentacle confirms the reset, the viewers' values are put back, and
        /// <see cref="OnViewerPropertyUpdated"/> raised for each one that changed,
        /// in the next Pump, like every other thing a game sees; the task
        /// completes once that has happened. Await it rather than blocking the
        /// pumping thread on it.
        /// </summary>
        public async Task<bool> ResetCollectionValuesAsync(string collectionName, CancellationToken cancellationToken = default)
        {
            var collection = FindCollectionByName(collectionName);
            if (collection == null)
            {
                TentacleLog.Warn("Tentacle: no viewer-property collection named \"" + collectionName + "\"");
                return false;
            }

            var input = JsonValue
                .Object(JsonValue.Member("collectionId", JsonValue.FromString(collection.Id)))
                .ToJson();
            var ok = await client
                .CallForSuccessAsync(
                    (http, token) => http.ResetCollectionValuesAsync(input, token),
                    "viewerProperty.resetCollectionValues",
                    cancellationToken)
                .ConfigureAwait(false);
            if (!ok) return false;

            // Only after the server confirms: a local reset on a failed request
            // would show every viewer at a default the app never applied. And on
            // the pumping thread, since the confirmation arrives on whichever
            // thread the HTTP client completed on: resetting there would change
            // the viewer cache under a game that is reading it, and raise
            // OnViewerPropertyUpdated off the main thread, where a Unity handler
            // touching the scene throws.
            return await client.RunOnPumpAsync(() =>
            {
                foreach (var definition in definitions)
                {
                    if (definition.CollectionId != collection.Id) continue;
                    ResetLocally(collection, definition);
                }
            }).ConfigureAwait(false);
        }

        /// <summary>
        /// Puts one property back to its default for every viewer. Returns false
        /// when the request failed, in which case nothing is changed locally
        /// either.
        ///
        /// Once Tentacle confirms the reset, the viewers' values are put back, and
        /// <see cref="OnViewerPropertyUpdated"/> raised for each one that changed,
        /// in the next Pump; the task completes once that has happened. Await it
        /// rather than blocking the pumping thread on it.
        /// </summary>
        public async Task<bool> ResetPropertyValuesAsync(
            string collectionName,
            string propertyName,
            CancellationToken cancellationToken = default)
        {
            var collection = FindCollectionByName(collectionName);
            var definition = FindDefinitionIn(collection, propertyName, false);
            if (definition == null)
            {
                TentacleLog.Warn(
                    "Tentacle: no viewer property \"" + propertyName + "\" in collection \"" + collectionName + "\"");
                return false;
            }

            var input = JsonValue
                .Object(JsonValue.Member("definitionId", JsonValue.FromString(definition.Id)))
                .ToJson();
            var ok = await client
                .CallForSuccessAsync(
                    (http, token) => http.ResetPropertyValuesAsync(input, token),
                    "viewerProperty.resetPropertyValues",
                    cancellationToken)
                .ConfigureAwait(false);
            if (!ok) return false;

            // On the pumping thread, for the reason ResetCollectionValuesAsync
            // gives.
            return await client.RunOnPumpAsync(() => ResetLocally(collection, definition)).ConfigureAwait(false);
        }

        // The Unreal plugin's FetchViewersByDefinition, in its parameter order.
        // Unreal only echoes the property type back through its completion
        // delegate; here, where the task hands back the viewers, it checks the
        // caller's expectation against the registry instead.
        /// <summary>
        /// Fetches the viewers ranked by one property definition, e.g. for a
        /// leaderboard. Returns an empty list when the request failed - a
        /// leaderboard that cannot be fetched shows nothing, it does not throw
        /// into the game loop.
        ///
        /// <paramref name="propertyType"/> is the type the caller reads the
        /// ranked values as. Tentacle ranks by the definition's own type, so a
        /// mismatch still returns the viewers and is reported in the log.
        ///
        /// The ranked viewers are merged into <see cref="TentacleClient.Viewers"/>,
        /// raising its OnViewerAdded event for a viewer seen for the first time
        /// and <see cref="OnViewerPropertyUpdated"/> for a value that changed, in
        /// the next Pump; the task completes once that has happened. Await it
        /// rather than blocking the pumping thread on it.
        /// </summary>
        public async Task<IReadOnlyList<Viewer>> FetchViewersByDefinitionAsync(
            string collectionName,
            string propertyName,
            ViewerPropertyType propertyType,
            OrderDirection orderDirection = OrderDirection.Desc,
            int take = 10,
            CancellationToken cancellationToken = default)
        {
            var empty = new List<Viewer>();

            var collection = FindCollectionByName(collectionName);
            var definition = FindDefinitionIn(collection, propertyName, false);
            if (definition == null)
            {
                TentacleLog.Warn(
                    "Tentacle: no viewer property \"" + propertyName + "\" in collection \"" + collectionName + "\"");
                return empty;
            }
            if (definition.Type != propertyType)
            {
                TentacleLog.Warn(
                    "Tentacle: viewer property \"" + collectionName + "/" + propertyName + "\" is declared as "
                    + definition.Type + ", not " + propertyType + "; ranking it by its declared type");
            }

            var input = JsonValue.Object(
                    JsonValue.Member("definitionId", JsonValue.FromString(definition.Id)),
                    JsonValue.Member(
                        "orderDirection",
                        JsonValue.FromString(orderDirection == OrderDirection.Asc ? "asc" : "desc")),
                    JsonValue.Member("take", JsonValue.FromNumber(take)))
                .ToJson();

            var payload = await client
                .CallAsync(
                    (http, token) => http.GetViewersByDefinitionAsync(input, token),
                    "viewerProperty.getViewersByDefinition",
                    cancellationToken)
                .ConfigureAwait(false);
            if (payload == null) return empty;

            var array = payload["viewers"];
            if (array.Kind != JsonKind.Array) return empty;

            // Parsing touches nothing a game reads, so it happens here; merging
            // into the viewer cache does not, and waits for the pumping thread,
            // for the reason ResetCollectionValuesAsync gives.
            var ranked = new List<ViewerData>();
            foreach (var item in array.Items) ranked.Add(ViewerData.Parse(item));

            var result = new List<Viewer>();
            var merged = await client.RunOnPumpAsync(() =>
            {
                foreach (var data in ranked)
                {
                    var viewer = client.Viewers.UpsertViewer(data);
                    if (viewer != null) result.Add(viewer);
                }
            }).ConfigureAwait(false);
            return merged ? result : empty;
        }

        /// <summary>Puts one definition back to its default across every cached viewer.</summary>
        private void ResetLocally(ViewerPropertyCollection collection, ViewerPropertyDefinition definition)
        {
            if (collection == null || definition == null) return;
            foreach (var viewer in client.Viewers.AllViewers)
            {
                if (viewer.ResetToDefault(collection.Id, definition.Id, definition.Value))
                {
                    RaiseViewerPropertyUpdated(collection, viewer, definition);
                }
            }
        }

        /// <summary>
        /// Reports a value that changed while merging a viewer payload. Called by
        /// the viewer itself, which knows the ids but not their definitions.
        /// </summary>
        internal void NotifyValueChanged(Viewer viewer, TentacleViewerPropertyEntry entry)
        {
            if (viewer == null || entry == null) return;

            ViewerPropertyCollection collection;
            ViewerPropertyDefinition definition;
            collectionsById.TryGetValue(entry.CollectionId ?? "", out collection);
            definitionsById.TryGetValue(entry.DefinitionId ?? "", out definition);

            // A value for a definition the registry does not know is normal right
            // after the streamer adds one: the merge that produced this entry has
            // already asked for the refresh that resolves it, and reporting a
            // change with a null definition would be useless.
            if (collection == null || definition == null) return;

            RaiseViewerPropertyUpdated(collection, viewer, definition);
        }

        /// <summary>Raises OnViewerPropertyUpdated, each subscriber on its own.</summary>
        private void RaiseViewerPropertyUpdated(
            ViewerPropertyCollection collection,
            Viewer viewer,
            ViewerPropertyDefinition definition)
        {
            TentacleHandlers.Raise(OnViewerPropertyUpdated, collection, viewer, definition, "viewer-property");
        }

        /// <summary>Raises a no-argument event, each subscriber on its own.</summary>
        private static void Raise(Action handler)
        {
            TentacleHandlers.Raise(handler, "viewer-property");
        }
    }
}
