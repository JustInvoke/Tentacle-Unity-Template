// Copyright Tentacle. All Rights Reserved.
using System.Collections.Concurrent;
using System.Threading;
using Tcl.Json;

namespace Tcl
{
    /// <summary>What arrived from the transport thread.</summary>
    internal enum TentacleInboundKind
    {
        /// <summary>A decoded message. <c>Type</c> names it and <c>Payload</c> is its data.</summary>
        Message,

        /// <summary>The socket closed. <c>Text</c> is the close reason, when the server gave one.</summary>
        Closed,

        /// <summary>The transport failed. <c>Text</c> is the failure message.</summary>
        Faulted,
    }

    /// <summary>One thing the transport thread handed over, waiting to be processed.</summary>
    internal struct TentacleInbound
    {
        /// <summary>What kind of event this is.</summary>
        public TentacleInboundKind Kind;

        /// <summary>The message type, for <see cref="TentacleInboundKind.Message"/>.</summary>
        public string Type;

        /// <summary>The message's decoded <c>data</c> payload.</summary>
        public JsonValue Payload;

        /// <summary>The close reason or the failure message.</summary>
        public string Text;
    }

    /// <summary>
    /// The hand-off between the WebSocket receive loop and the engine's main
    /// thread.
    ///
    /// The generated client raises its events on the receive loop's own thread,
    /// and almost everything a game does in response - touching a GameObject,
    /// raising a UnityEvent - is main-thread only. Decoding JSON is thread-safe
    /// and already happens there, so the payload crosses as a JsonValue; every
    /// interpretation of it (viewer cache, de-duplication, game callbacks) waits
    /// for the thread that calls <c>Pump</c>.
    ///
    /// Features:
    /// - Lock-free enqueue, so the receive loop never blocks on a slow frame
    /// - Safe for several producers: messages come from the receive loop, but a
    ///   transport fault is raised from the connect task, and the pumping thread
    ///   drains and clears
    /// - Bounded: a game that stops pumping (a long load, a paused editor) must
    ///   not let a chatty stream grow the queue until the process dies
    /// - Counts what it dropped, so an overflow is reported rather than silent
    /// </summary>
    internal sealed class TentacleInboundQueue
    {
        private readonly ConcurrentQueue<TentacleInbound> items = new ConcurrentQueue<TentacleInbound>();
        private readonly int capacity;
        private int droppedSinceLastDrain;

        /// <summary>Creates a queue holding at most <paramref name="capacity"/> items.</summary>
        public TentacleInboundQueue(int capacity)
        {
            this.capacity = capacity > 0 ? capacity : 1;
        }

        /// <summary>
        /// Adds an item, dropping the OLDEST first when the queue is full: a
        /// backlog that big means the game stopped consuming, and the newest
        /// stream events are the ones still worth delivering.
        /// </summary>
        public void Enqueue(TentacleInbound item)
        {
            // Trim before adding rather than after, so the queue is not left
            // over the cap while a drain is not running. The cap is approximate:
            // producers other than the receive loop exist (a fault raised from
            // the connect task), and the pumping thread drains and clears
            // concurrently, so this can trim one item too many or too few. That
            // is the whole cost, because ConcurrentQueue itself is safe for all
            // of them - the cap exists to bound memory, not to be exact.
            while (items.Count >= capacity)
            {
                TentacleInbound discarded;
                if (!items.TryDequeue(out discarded)) break;
                Interlocked.Increment(ref droppedSinceLastDrain);
            }

            items.Enqueue(item);
        }

        /// <summary>Adds a decoded message.</summary>
        public void EnqueueMessage(string type, JsonValue payload)
        {
            Enqueue(new TentacleInbound
            {
                Kind = TentacleInboundKind.Message,
                Type = type,
                Payload = payload,
            });
        }

        /// <summary>Adds a socket lifecycle notice.</summary>
        public void EnqueueNotice(TentacleInboundKind kind, string text)
        {
            Enqueue(new TentacleInbound { Kind = kind, Text = text });
        }

        /// <summary>Takes the next item, or false when the queue is empty.</summary>
        public bool TryDequeue(out TentacleInbound item)
        {
            return items.TryDequeue(out item);
        }

        /// <summary>
        /// How many items were dropped since this was last called, resetting the
        /// counter. The caller reports it once per drain instead of once per
        /// drop, which keeps an overflow from also flooding the log.
        /// </summary>
        public int TakeDroppedCount()
        {
            return Interlocked.Exchange(ref droppedSinceLastDrain, 0);
        }

        /// <summary>Discards everything queued, e.g. when the session is torn down.</summary>
        public void Clear()
        {
            TentacleInbound discarded;
            while (items.TryDequeue(out discarded))
            {
                // Draining is the point; the items themselves are not needed.
            }
        }
    }
}
