// Copyright Tentacle. All Rights Reserved.
using System;

namespace Tcl
{
    // The Unreal plugin dials in the same way and carries the same policy,
    // FTclReconnectPolicy, with the same defaults: a 1 s first retry, doubling
    // to a 30 s ceiling, with 25% jitter. One difference: its jitter lands on
    // either side of the delay and is clamped to the ceiling, where this one
    // only adds.
    //
    // Pure and allocation-free, so the connection state machine stays
    // testable, and the caller-supplied jitter sample keeps a test
    // deterministic.
    /// <summary>
    /// How long to wait before the next connection attempt.
    ///
    /// Tentacle is a desktop app the streamer starts and stops at will, so a game
    /// that is running while Tentacle is not must retry indefinitely without
    /// hammering the loopback port. The delay grows geometrically to a ceiling and
    /// carries jitter, so several engine instances that all lost the socket when
    /// Tentacle quit do not come back in lockstep.
    ///
    /// The defaults are fast enough that restarting Tentacle reconnects the game
    /// within a second or two, and slow enough that an hour with Tentacle closed
    /// costs about a hundred attempts.
    ///
    /// Features:
    /// - Pure and allocation-free
    /// - Jitter is drawn from a caller-supplied 0..1 sample, never from a hidden
    ///   static Random
    /// </summary>
    public sealed class TentacleReconnectPolicy
    {
        /// <summary>Delay before the first retry, in seconds.</summary>
        public double InitialDelaySeconds = 1.0;

        /// <summary>Ceiling the delay grows to, in seconds.</summary>
        public double MaxDelaySeconds = 30.0;

        /// <summary>Growth factor applied per consecutive failure.</summary>
        public double Multiplier = 2.0;

        /// <summary>
        /// Fraction of the computed delay that jitter may add, 0..1. At the
        /// default 0.25 a 4 s delay becomes 4-5 s.
        /// </summary>
        public double JitterFraction = 0.25;

        /// <summary>
        /// The delay before attempt number <paramref name="consecutiveFailures"/>
        /// (1 for the first retry after a failure).
        ///
        /// <paramref name="jitterSample"/> is a 0..1 value, normally
        /// <c>random.NextDouble()</c>; it is clamped, so a caller that supplies
        /// something out of range gets a sane delay rather than a negative one.
        /// </summary>
        public double DelayForAttempt(int consecutiveFailures, double jitterSample)
        {
            if (consecutiveFailures < 1) consecutiveFailures = 1;

            var initial = InitialDelaySeconds > 0.0 ? InitialDelaySeconds : 0.0;
            var ceiling = MaxDelaySeconds > initial ? MaxDelaySeconds : initial;
            var growth = Multiplier >= 1.0 ? Multiplier : 1.0;

            var delay = initial;
            for (var i = 1; i < consecutiveFailures; i++)
            {
                delay *= growth;
                // Stop multiplying once the ceiling is reached: with a large
                // failure count and a growth factor, the running product would
                // otherwise reach infinity and take the jitter with it.
                if (delay >= ceiling)
                {
                    delay = ceiling;
                    break;
                }
            }
            if (delay > ceiling) delay = ceiling;

            var jitterFraction = JitterFraction;
            if (jitterFraction <= 0.0) return delay;
            if (jitterFraction > 1.0) jitterFraction = 1.0;

            var sample = jitterSample;
            if (double.IsNaN(sample) || sample < 0.0) sample = 0.0;
            if (sample > 1.0) sample = 1.0;

            return delay + (delay * jitterFraction * sample);
        }

        /// <summary>
        /// The delay before attempt number <paramref name="consecutiveFailures"/>,
        /// drawing jitter from <paramref name="random"/>.
        /// </summary>
        public double DelayForAttempt(int consecutiveFailures, Random random)
        {
            return DelayForAttempt(consecutiveFailures, random == null ? 0.0 : random.NextDouble());
        }
    }
}
