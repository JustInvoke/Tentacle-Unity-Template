// Copyright Tentacle. All Rights Reserved.
using System;
using System.IO;
using Tcl.Json;

namespace Tcl
{
    /// <summary>
    /// Where the running Tentacle app can be reached.
    ///
    /// Both ports have well-known defaults, but Tentacle falls back to an
    /// OS-assigned port when one is taken and publishes what it actually bound in
    /// a small discovery file. A plugin that hardcodes the defaults silently stops
    /// working after such a fallback, so discovery is the primary source and the
    /// defaults are only the last resort.
    ///
    /// Features:
    /// - Reads `sidecar.json` from Tentacle's data folder, with per-field fallback
    /// - Never throws: a missing, unreadable, or malformed file resolves to the
    ///   defaults, because Tentacle simply not running is the ordinary case
    /// </summary>
    public sealed class TentacleEndpoints
    {
        /// <summary>Default port of Tentacle's HTTP/tRPC API.</summary>
        public const int DefaultHttpPort = 47821;

        /// <summary>Default port of Tentacle's engine WebSocket listener.</summary>
        public const int DefaultEnginePort = 47822;

        /// <summary>Name of the discovery file Tentacle writes to its data folder.</summary>
        public const string DiscoveryFileName = "sidecar.json";

        /// <summary>Base URL of the tRPC API, e.g. "http://127.0.0.1:47821".</summary>
        public string HttpBaseUrl = "http://127.0.0.1:" + DefaultHttpPort;

        /// <summary>WebSocket URL of the engine listener, e.g. "ws://127.0.0.1:47822".</summary>
        public string EngineSocketUrl = "ws://127.0.0.1:" + DefaultEnginePort;

        /// <summary>
        /// True when these came out of the discovery file rather than the
        /// compiled-in defaults. Surfaced so the runtime can say which it used.
        /// </summary>
        public bool FromDiscoveryFile;

        /// <summary>
        /// Tentacle's data folder, where the discovery file and the SQLite
        /// database live. On Windows that is %APPDATA%\Tentacle.
        /// </summary>
        public static string DefaultDataDirectory()
        {
            try
            {
                var appData = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
                if (string.IsNullOrEmpty(appData)) return null;
                return Path.Combine(appData, "Tentacle");
            }
            catch (Exception exception)
            {
                // A sandboxed player can refuse to resolve a special folder.
                TentacleLog.Warn("Tentacle: could not resolve the data folder: " + exception.Message);
                return null;
            }
        }

        /// <summary>
        /// Resolves the endpoints, preferring what Tentacle published in
        /// <paramref name="dataDirectory"/> (null means the default folder).
        /// Always returns usable endpoints.
        /// </summary>
        public static TentacleEndpoints Resolve(string dataDirectory = null)
        {
            var endpoints = new TentacleEndpoints();

            var directory = string.IsNullOrEmpty(dataDirectory) ? DefaultDataDirectory() : dataDirectory;
            if (string.IsNullOrEmpty(directory)) return endpoints;

            var text = ReadDiscoveryFile(Path.Combine(directory, DiscoveryFileName));
            if (text == null) return endpoints;

            var json = JsonValue.ParseOrNull(text);
            if (json == null || json.Kind != JsonKind.Object)
            {
                TentacleLog.Warn("Tentacle: " + DiscoveryFileName + " is not a JSON object; using the default ports");
                return endpoints;
            }

            // Each field falls back independently: the sidecar omits the engine
            // keys entirely when its listener could not start, and the HTTP half
            // is still usable in that state.
            var httpBaseUrl = JsonRead.ReadOptionalString(json, "baseUrl");
            var httpPort = JsonRead.ReadNullableInt32(json, "port");
            if (!string.IsNullOrEmpty(httpBaseUrl))
            {
                endpoints.HttpBaseUrl = httpBaseUrl;
                endpoints.FromDiscoveryFile = true;
            }
            else if (httpPort.HasValue && httpPort.Value > 0)
            {
                endpoints.HttpBaseUrl = "http://127.0.0.1:" + httpPort.Value;
                endpoints.FromDiscoveryFile = true;
            }

            var engineUrl = JsonRead.ReadOptionalString(json, "engineUrl");
            var enginePort = JsonRead.ReadNullableInt32(json, "enginePort");
            if (!string.IsNullOrEmpty(engineUrl))
            {
                endpoints.EngineSocketUrl = engineUrl;
                endpoints.FromDiscoveryFile = true;
            }
            else if (enginePort.HasValue && enginePort.Value > 0)
            {
                endpoints.EngineSocketUrl = "ws://127.0.0.1:" + enginePort.Value;
                endpoints.FromDiscoveryFile = true;
            }

            return endpoints;
        }

        /// <summary>
        /// Reads the discovery file, or null when it is absent or unreadable.
        /// Tentacle rewrites this file while it starts, so a sharing violation
        /// or a half-written file is a normal race, not an error.
        /// </summary>
        private static string ReadDiscoveryFile(string path)
        {
            try
            {
                if (!File.Exists(path)) return null;
                using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
            catch (Exception exception)
            {
                TentacleLog.Warn("Tentacle: could not read " + path + ": " + exception.Message);
                return null;
            }
        }
    }
}
