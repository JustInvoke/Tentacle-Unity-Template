// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_CustomEvents. No de-duplication matches the
    // Unreal plugin, and so does matching names whatever their case: that is
    // what Unreal's shipped listener component has always done.
    /// <summary>
    /// Named events the streamer configured in Tentacle, fired at the game.
    ///
    /// A custom event is Tentacle's way of turning any trigger the streamer can
    /// describe - a bits threshold, a chat command, a redemption - into one name
    /// the game reacts to, so the game does not have to encode the trigger rules.
    ///
    /// Features:
    /// - <see cref="OnCustomEvent"/> for every custom event, or
    ///   <see cref="Subscribe"/> for one name, which is the common case and saves
    ///   every game writing the same name comparison
    /// - Names are matched case-insensitively by default, with an option for
    ///   exact matching
    /// - No de-duplication: a custom event is a command to act, and the
    ///   streamer firing the same one twice means twice
    /// - <see cref="Definitions"/> holds every custom event the streamer
    ///   configured, each with the chat commands that fire it, kept current as
    ///   the streamer creates, changes, and removes them
    /// </summary>
    public sealed class Tentacle_CustomEvents
    {
        /// <summary>One handler waiting for one name.</summary>
        private sealed class Subscription
        {
            public string EventName;
            public Action<CustomEvent, Viewer> Handler;
            public bool CaseSensitive;

            /// <summary>Whether this subscription is for <paramref name="name"/>, under its own case rule.</summary>
            public bool Matches(string name)
            {
                return string.Equals(
                    EventName,
                    name,
                    CaseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase);
            }
        }

        private readonly TentacleClient client;

        /// <summary>Every subscription, in the order they were made, which is the order they run in.</summary>
        private readonly List<Subscription> subscriptions = new List<Subscription>();

        private readonly List<CustomEventDefinition> definitions = new List<CustomEventDefinition>();

        /// <summary>The last definitions as received, so ones sent again unchanged raise nothing.</summary>
        private string definitionsKey;

        /// <summary>Raised for every custom event, whatever its name.</summary>
        public event Action<CustomEvent, Viewer> OnCustomEvent;

        /// <summary>
        /// Raised whenever the custom event definitions change, including when the
        /// first ones arrive. <see cref="Definitions"/> already holds the new ones
        /// when it is raised.
        /// </summary>
        public event Action OnDefinitionsChanged;

        /// <summary>
        /// Every custom event the streamer configured, enabled or not, ordered by
        /// name. <c>ChatCommands</c> on each lists the chat commands that fire it,
        /// without the command prefix: the commands a trigger requires exactly.
        /// </summary>
        public IReadOnlyList<CustomEventDefinition> Definitions
        {
            get { return definitions; }
        }

        /// <summary>Whether Tentacle has sent the definitions yet. Until it has, <see cref="Definitions"/> is empty.</summary>
        public bool AreDefinitionsLoaded { get; private set; }

        /// <summary>Creates the custom-events surface for a client.</summary>
        internal Tentacle_CustomEvents(TentacleClient client)
        {
            this.client = client;
        }

        // The same trailing option, named the same, as the viewer-property
        // lookups (GetProperty_*, FindCollectionByName).
        /// <summary>
        /// Runs <paramref name="handler"/> for custom events with this name.
        /// Names are matched case-insensitively by default; pass
        /// <c>caseSensitive: true</c> if you need exact matching. Call
        /// <see cref="Unsubscribe"/> with the same name and handler to stop.
        /// </summary>
        public void Subscribe(
            string eventName,
            Action<CustomEvent, Viewer> handler,
            bool caseSensitive = false)
        {
            if (string.IsNullOrEmpty(eventName) || handler == null) return;
            subscriptions.Add(new Subscription
            {
                EventName = eventName,
                Handler = handler,
                CaseSensitive = caseSensitive,
            });
        }

        /// <summary>
        /// Stops running <paramref name="handler"/> for this name. The name is
        /// compared the way that subscription compares names: any case for a
        /// case-insensitive subscription, exactly for a case-sensitive one.
        /// </summary>
        public void Unsubscribe(string eventName, Action<CustomEvent, Viewer> handler)
        {
            if (string.IsNullOrEmpty(eventName) || handler == null) return;

            // The most recent match goes, as removing a handler from a C# event
            // takes the last one added.
            for (var index = subscriptions.Count - 1; index >= 0; index--)
            {
                var subscription = subscriptions[index];
                if (subscription.Handler != handler || !subscription.Matches(eventName)) continue;
                subscriptions.RemoveAt(index);
                return;
            }
        }

        /// <summary>
        /// The definition with this name, or null. Case-insensitive by default,
        /// the same rule <see cref="Subscribe"/> uses. When two definitions share
        /// a name, the first in <see cref="Definitions"/> is the one found.
        /// </summary>
        public CustomEventDefinition FindDefinitionByName(string name, bool caseSensitive = false)
        {
            if (string.IsNullOrEmpty(name)) return null;
            var comparison = caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            foreach (var definition in definitions)
            {
                if (string.Equals(definition.Name, name, comparison)) return definition;
            }
            return null;
        }

        /// <summary>Handles the payload of an inbound <c>CustomEvents_Definitions</c>.</summary>
        internal void HandleDefinitions(JsonValue payload)
        {
            if (payload == null || payload.Kind != JsonKind.Object) return;

            // Tentacle sends the current definitions every time a session opens,
            // so ones identical to those held are not a change.
            var key = JsonWriter.Write(payload);
            if (AreDefinitionsLoaded && key == definitionsKey) return;

            var parsed = JsonRead.ReadList(payload, "definitions", CustomEventDefinition.Parse, true, "CustomEvents_Definitions");
            if (parsed == null) return;

            definitions.Clear();
            foreach (var definition in parsed)
            {
                if (definition != null) definitions.Add(definition);
            }
            AreDefinitionsLoaded = true;
            definitionsKey = key;

            TentacleHandlers.Raise(OnDefinitionsChanged, "custom-event-definitions");
        }

        /// <summary>Handles the payload of an inbound <c>CustomEvents_Event</c>.</summary>
        internal void HandleEvent(JsonValue payload)
        {
            if (payload == null || payload.Kind != JsonKind.Object) return;

            var customEvent = CustomEvent.Parse(payload);
            if (customEvent == null) return;

            var viewer = client.Viewers.UpsertViewer(payload["viewer"]);

            TentacleHandlers.Raise(OnCustomEvent, customEvent, viewer, "custom-event");

            if (string.IsNullOrEmpty(customEvent.Name)) return;

            // A snapshot, so a handler that subscribes or unsubscribes while it
            // runs changes the next event rather than this one.
            foreach (var subscription in subscriptions.ToArray())
            {
                if (!subscription.Matches(customEvent.Name)) continue;
                TentacleHandlers.Raise(subscription.Handler, customEvent, viewer, "custom-event");
            }
        }
    }
}
