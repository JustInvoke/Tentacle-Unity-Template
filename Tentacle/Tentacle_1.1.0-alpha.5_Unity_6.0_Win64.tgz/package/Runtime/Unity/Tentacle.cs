// Copyright Tentacle. All Rights Reserved.
using System;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Tcl
{
    /// <summary>
    /// The Tentacle singleton: one connection per game, reachable from anywhere.
    ///
    /// A game touches <see cref="Client"/> (or the shortcuts beside it) and never
    /// creates or owns anything. The client is built from
    /// <see cref="TentacleSettings"/> before the first scene loads, along with
    /// the hidden component that pumps it, so a handler subscribed in
    /// <c>Awake</c> cannot miss anything.
    ///
    /// Surviving the editor is the awkward part, and it is handled explicitly. A
    /// domain reload destroys all managed state while the OS socket and its
    /// receive thread would otherwise carry on, so the runtime is shut down
    /// before a reload and before leaving play mode, and rebuilt afterwards. The
    /// effect for a game is that entering and leaving play mode repeatedly leaves
    /// no orphaned sockets and no duplicated sessions in Tentacle.
    /// </summary>
    public static class Tentacle
    {
        private static TentacleClient client;
        private static TentacleHost host;
        private static bool editorHooksInstalled;

        /// <summary>
        /// The connection and everything reachable through it. Built on first
        /// use; never null.
        /// </summary>
        public static TentacleClient Client
        {
            get
            {
                EnsureCreated();
                return client;
            }
        }

        /// <summary>Stream events, chat, and the game's own chat messages.</summary>
        public static Tentacle_Stream Stream
        {
            get { return Client.Stream; }
        }

        /// <summary>Controls this game puts in Tentacle's custom-controls panel.</summary>
        public static Tentacle_CustomControls CustomControls
        {
            get { return Client.CustomControls; }
        }

        /// <summary>Named events the streamer configured.</summary>
        public static Tentacle_CustomEvents CustomEvents
        {
            get { return Client.CustomEvents; }
        }

        /// <summary>OBS requests relayed through Tentacle.</summary>
        public static Tentacle_Obs Obs
        {
            get { return Client.Obs; }
        }

        /// <summary>Per-viewer values the streamer defined.</summary>
        public static Tentacle_ViewerProperties ViewerProperties
        {
            get { return Client.ViewerProperties; }
        }

        /// <summary>Every viewer this session has been told about.</summary>
        public static Tentacle_Viewers Viewers
        {
            get { return Client.Viewers; }
        }

        /// <summary>Tentacle's chat bot as the streamer configured it, with every command it answers, kept current.</summary>
        public static Tentacle_Bot Bot
        {
            get { return Client.Bot; }
        }

        // The Unreal plugin's ATentacle::OnConnectionStatusChanged. It lives on
        // the actor there, which outlives any one connection; here the client
        // is rebuilt on every domain reload and when play mode ends, so the
        // runtime carries the event and forwards whichever client it holds.
        /// <summary>
        /// Raised when <see cref="ConnectionStatus"/> changes, on the main thread.
        ///
        /// Subscribe once: the subscription carries over when the runtime
        /// replaces its client, which a subscription to
        /// <see cref="TentacleClient.OnConnectionStatusChanged"/> on
        /// <see cref="Client"/> does not.
        /// </summary>
        public static event Action<ConnectionStatus> OnConnectionStatusChanged;

        /// <summary>
        /// Where the connection stands. Reads as Disconnected before the runtime
        /// exists rather than building it, so a status readout in OnDestroy
        /// cannot resurrect it.
        /// </summary>
        public static ConnectionStatus ConnectionStatus
        {
            get
            {
                return client != null ? client.ConnectionStatus : ConnectionStatus.Disconnected;
            }
        }

        /// <summary>True while a session is open.</summary>
        public static bool IsConnected
        {
            get { return ConnectionStatus == ConnectionStatus.Connected; }
        }

        /// <summary>
        /// The id Tentacle assigned the open session, or empty while not
        /// connected. A new one is issued on every reconnect. Reads as empty
        /// before the runtime exists rather than building it.
        /// </summary>
        public static string SessionId
        {
            get { return client != null ? client.SessionId : ""; }
        }

        /// <summary>Starts connecting, and keeps retrying until <see cref="Disconnect"/>.</summary>
        public static void Connect()
        {
            Client.Connect();
        }

        /// <summary>Closes the session and stops retrying.</summary>
        public static void Disconnect()
        {
            if (client == null) return;
            client.Disconnect();
        }

        /// <summary>
        /// Runs before the first scene loads, so a game object subscribing in
        /// Awake is already too late to miss anything.
        /// </summary>
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Bootstrap()
        {
            // Resolved once and handed on, rather than loaded again inside
            // EnsureCreated.
            var settings = TentacleSettings.LoadOrDefault();
            EnsureCreated(settings);
            if (settings.AutoConnect) client.Connect();
        }

        /// <summary>Builds the client and its pump host if they do not exist yet.</summary>
        private static void EnsureCreated()
        {
            EnsureCreated(null);
        }

        /// <summary>
        /// Builds the client and its pump host if they do not exist yet, using
        /// <paramref name="settings"/> when the caller has already resolved them.
        /// </summary>
        private static void EnsureCreated(TentacleSettings settings)
        {
            InstallEditorHooks();

            if (client == null)
            {
                var resolved = settings != null ? settings : TentacleSettings.LoadOrDefault();
                InstallLogSink(resolved);
                Adopt(new TentacleClient(BuildOptions(resolved)));
            }

            if (host == null) host = TentacleHost.Spawn();
        }

        /// <summary>Makes <paramref name="created"/> the runtime's client and forwards its status changes.</summary>
        private static void Adopt(TentacleClient created)
        {
            client = created;
            client.OnConnectionStatusChanged += RaiseConnectionStatusChanged;
        }

        /// <summary>Raises <see cref="OnConnectionStatusChanged"/>, each subscriber on its own.</summary>
        private static void RaiseConnectionStatusChanged(ConnectionStatus status)
        {
            TentacleHandlers.Raise(OnConnectionStatusChanged, status, "connection-status");
        }

        // The same seam as CustomControlComponent.RegistryOverride: it lets
        // the edit-mode tests drive the runtime's own events against a client of
        // their own, without a real socket or the object that pumps it.
        /// <summary>
        /// Shuts the runtime down and makes <paramref name="replacement"/> its
        /// client, without spawning the pump host.
        /// </summary>
        internal static void UseClient(TentacleClient replacement)
        {
            Shutdown();
            if (replacement != null) Adopt(replacement);
        }

        /// <summary>Turns the settings asset into client options.</summary>
        private static TentacleClientOptions BuildOptions(TentacleSettings settings)
        {
            var label = string.IsNullOrEmpty(settings.SessionLabel)
                ? Application.productName + (Application.isEditor ? " (Editor)" : "")
                : settings.SessionLabel;

            return new TentacleClientOptions
            {
                Identity = new TentacleEngineIdentity
                {
                    Engine = "unity",
                    EngineVersion = Application.unityVersion,
                    PluginVersion = TentacleVersion.Plugin,
                    // Unique per process, which is what keeps a play-mode session
                    // and a packaged build of the same project apart in Tentacle.
                    InstanceId = Guid.NewGuid().ToString("N"),
                    Label = label,
                },
                DataDirectory = string.IsNullOrEmpty(settings.DataDirectoryOverride)
                    ? null
                    : settings.DataDirectoryOverride,
                ReconnectPolicy = new TentacleReconnectPolicy
                {
                    InitialDelaySeconds = settings.ReconnectInitialDelaySeconds,
                    MaxDelaySeconds = settings.ReconnectMaxDelaySeconds,
                },
                StreamDeduplicationWindow = settings.StreamDeduplicationWindow,
                RefreshRegistryOnConnect = settings.RefreshRegistryOnConnect,
            };
        }

        /// <summary>Points the package's diagnostics at the Unity console.</summary>
        private static void InstallLogSink(TentacleSettings settings)
        {
            if (!settings.LogToConsole)
            {
                TentacleLog.InstallSink(null);
                return;
            }

            var includeLifecycle = settings.LogLifecycle;
            TentacleLog.InstallSink((level, message) =>
            {
                switch (level)
                {
                    case TentacleLogLevel.Error:
                        Debug.LogError(message);
                        break;
                    case TentacleLogLevel.Warning:
                        Debug.LogWarning(message);
                        break;
                    default:
                        if (includeLifecycle) Debug.Log(message);
                        break;
                }
            });
        }

        /// <summary>Advances the client. Called once per frame by the host.</summary>
        internal static void Pump()
        {
            if (client != null) client.Pump();
        }

        /// <summary>
        /// The client if one exists, without building one. Used by anything
        /// running during teardown, where creating a client - and the GameObject
        /// that pumps it - would resurrect the runtime the editor is in the
        /// middle of destroying.
        /// </summary>
        public static TentacleClient CurrentClient
        {
            get { return client; }
        }

        /// <summary>
        /// Closes the connection and drops everything, so the next touch of
        /// <see cref="Client"/> builds a fresh one. Called when play mode ends,
        /// before a domain reload, and when the application quits.
        /// </summary>
        internal static void Shutdown()
        {
            if (client != null)
            {
                client.OnConnectionStatusChanged -= RaiseConnectionStatusChanged;
                client.Dispose();
                client = null;
            }

            // The host has to go with it. Leaving it behind would leave a hidden
            // GameObject ticking a client that no longer exists, and the next
            // EnsureCreated would spawn a second one beside it.
            if (host != null)
            {
                var carrier = host.gameObject;
                host = null;
                if (Application.isPlaying) UnityEngine.Object.Destroy(carrier);
                else UnityEngine.Object.DestroyImmediate(carrier);
            }
        }

#if UNITY_EDITOR
        /// <summary>
        /// Tears the runtime down before the editor destroys the managed world
        /// underneath it. Without this the receive thread and the OS socket would
        /// outlive the objects that own them: a script recompile or a second
        /// entry into play mode would leave Tentacle showing sessions for a game
        /// that is no longer running.
        /// </summary>
        private static void InstallEditorHooks()
        {
            if (editorHooksInstalled) return;
            editorHooksInstalled = true;

            AssemblyReloadEvents.beforeAssemblyReload += Shutdown;
            EditorApplication.playModeStateChanged += state =>
            {
                // Twice, deliberately. ExitingPlayMode is the shutdown that
                // matters, but MonoBehaviour.OnDestroy runs after it, and a game
                // unregistering a control there touches Tentacle and
                // builds a fresh client and pump object in the middle of
                // teardown. Shutting down again once the editor is back in edit
                // mode disposes anything that came back that way, instead of
                // leaving it parked in statics until the next domain reload.
                if (state == PlayModeStateChange.ExitingPlayMode
                    || state == PlayModeStateChange.EnteredEditMode)
                {
                    Shutdown();
                }
            };
            EditorApplication.quitting += Shutdown;
        }
#else
        /// <summary>Nothing to install outside the editor: the process is the lifetime.</summary>
        private static void InstallEditorHooks()
        {
        }
#endif
    }
}
