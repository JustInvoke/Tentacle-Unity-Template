// Copyright Tentacle. All Rights Reserved.
using System;
using Tcl.Json;
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unity counterpart of the Unreal plugin's UTclCustomControlComponent,
    // and deliberately the same shape, down to the generated id. The events are
    // serialized UnityEvents so they can be wired in the Inspector the way an
    // Unreal user wires them in the Details panel.
    /// <summary>
    /// Base of the custom-control components: a control the streamer drives from
    /// Tentacle's panel, authored as a component on a GameObject.
    ///
    /// Drop a <c>Custom Control (Slider)</c> on a GameObject, set its label and
    /// range in the inspector, and it appears in Tentacle when the scene runs and
    /// disappears when the object does. Nothing about ids, registration, or
    /// teardown reaches the game.
    ///
    /// Its events are UnityEvents: wire them in the Inspector, or from code with
    /// <c>AddListener</c>.
    ///
    /// Registering from code is available too - see
    /// <see cref="Tentacle_CustomControls.RegisterCustomControl"/> - and this
    /// sits on top of it rather than beside it: a component owns exactly one
    /// handle from that registry, reachable as <see cref="Handle"/>.
    ///
    /// Features:
    /// - Registers in OnEnable, unregisters in OnDisable, so a disabled or
    ///   destroyed object leaves nothing behind in Tentacle
    /// - The id is generated: a control is identified by the object that owns
    ///   it, never by a string the game has to keep unique
    /// - The group comes from the nearest <see cref="CustomControlGroupComponent"/>
    ///   above it in the hierarchy, so grouping is something you can see
    /// - Each typed component has a <c>ShouldReceiveValue_</c> hook that can
    ///   refuse or clamp an inbound value, and a refused value leaves both the
    ///   component and Tentacle's copy alone
    /// </summary>
    public abstract class CustomControlComponent : MonoBehaviour
    {
        [Tooltip("Name shown beside the control in Tentacle.")]
        [SerializeField]
        private string label = "";

        [Tooltip("Controls are listed low to high. Ties fall back to registration order.")]
        [SerializeField]
        private int sortIndex;

        [Tooltip("Raised once the control has registered with Tentacle and its id exists.")]
        [SerializeField]
        private UnityEvent onInitialize = new UnityEvent();

        [Tooltip("Raised when the streamer clicks the control.")]
        [SerializeField]
        private UnityEvent onClick = new UnityEvent();

        [Tooltip("Raised when a press begins on the control.")]
        [SerializeField]
        private UnityEvent onMouseDown = new UnityEvent();

        [Tooltip("Raised when a press ends on the control.")]
        [SerializeField]
        private UnityEvent onMouseUp = new UnityEvent();

        /// <summary>
        /// The registry this component registered with, remembered so OnDisable
        /// unregisters from the same one.
        ///
        /// Deliberately not reached through <see cref="Tentacle"/> during
        /// teardown: leaving play mode disposes the runtime before components are
        /// disabled, and touching that property here would build a fresh client -
        /// and the GameObject that pumps it - in the middle of it.
        /// </summary>
        private Tentacle_CustomControls registry;

        // The same seam as TentacleClientOptions.Socket, and for the same
        // reason: it lets the edit-mode tests drive a component against a client
        // of their own, rather than building the runtime singleton and the
        // GameObject that pumps it inside a test.
        /// <summary>
        /// The registry components register with, or null for the singleton's -
        /// which is what a game always gets.
        /// </summary>
        internal static Tentacle_CustomControls RegistryOverride;

        /// <summary>Name shown beside the control in Tentacle.</summary>
        public string Label
        {
            get { return label; }
        }

        /// <summary>Where the control sorts in Tentacle's panel, low to high.</summary>
        public int SortIndex
        {
            get { return sortIndex; }
        }

        /// <summary>
        /// The id Tentacle knows this control by. Assigned when the control
        /// registers and empty before that.
        /// </summary>
        public string ControlId { get; private set; }

        /// <summary>The group this control is filed under, or empty for none.</summary>
        public string Group { get; private set; }

        /// <summary>The registration handle, or null while the control is not registered.</summary>
        public TentacleControlHandle Handle { get; private set; }

        /// <summary>True while Tentacle has this control.</summary>
        public bool IsRegistered
        {
            get { return Handle != null && Handle.IsRegistered; }
        }

        /// <summary>The wire type discriminator, e.g. <c>"Slider"</c>.</summary>
        public abstract string ControlType { get; }

        /// <summary>
        /// Raised once the control has registered and its id exists: the place
        /// to seed the control from world state.
        /// </summary>
        public UnityEvent OnInitialize
        {
            get { return onInitialize; }
        }

        /// <summary>Raised when the streamer clicks the control.</summary>
        public UnityEvent OnClick
        {
            get { return onClick; }
        }

        /// <summary>Raised when a press begins on the control.</summary>
        public UnityEvent OnMouseDown
        {
            get { return onMouseDown; }
        }

        /// <summary>Raised when a press ends on the control.</summary>
        public UnityEvent OnMouseUp
        {
            get { return onMouseUp; }
        }

        /// <summary>Registers the control and starts listening for its events.</summary>
        protected virtual void OnEnable()
        {
            RegisterControl();
        }

        /// <summary>Unregisters the control and stops listening.</summary>
        protected virtual void OnDisable()
        {
            UnregisterControl();
        }

        // Split out of OnEnable so the edit-mode tests can drive it: Unity runs
        // the enable lifecycle only in play mode, and marking these components
        // ExecuteAlways to work around that would register a scene's controls
        // with Tentacle while the editor merely has the scene open.
        /// <summary>
        /// Registers the control and subscribes to its events. What OnEnable
        /// does.
        /// </summary>
        internal void RegisterControl()
        {
            if (Handle != null) return;

            ControlId = Guid.NewGuid().ToString("N");
            Group = ResolveGroup();

            var control = CreateControl();
            control.Id = ControlId;
            control.Label = label;
            control.SortIndex = sortIndex;
            control.Group = string.IsNullOrEmpty(Group) ? null : Group;
            WriteValue(control);

            registry = RegistryOverride ?? Tentacle.CustomControls;
            Handle = registry.RegisterCustomControl(control);
            if (Handle == null)
            {
                // Register already said why. Carrying on with a null handle would
                // turn every later call into a null reference.
                registry = null;
                return;
            }

            Handle.OnClick += RaiseClick;
            Handle.OnMouseDown += RaiseMouseDown;
            Handle.OnMouseUp += RaiseMouseUp;
            Handle.OnValueChangedFromApp += HandleValueChanged;
            Handle.OnValueCommittedFromApp += HandleValueCommitted;

            InvokeListeners(onInitialize);
        }

        /// <summary>Unregisters the control and stops listening. What OnDisable does.</summary>
        internal void UnregisterControl()
        {
            if (Handle != null)
            {
                Handle.OnClick -= RaiseClick;
                Handle.OnMouseDown -= RaiseMouseDown;
                Handle.OnMouseUp -= RaiseMouseUp;
                Handle.OnValueChangedFromApp -= HandleValueChanged;
                Handle.OnValueCommittedFromApp -= HandleValueCommitted;
            }

            if (registry != null && Handle != null) registry.UnregisterCustomControl(Handle);

            Handle = null;
            registry = null;
            ControlId = "";
        }

        /// <summary>Renames the control in Tentacle.</summary>
        public void SetLabel(string newLabel)
        {
            label = newLabel ?? "";
            SendControlState();
        }

        /// <summary>Moves the control in Tentacle's ordering.</summary>
        public void SetSortIndex(int newSortIndex)
        {
            sortIndex = newSortIndex;
            SendControlState();
        }

        /// <summary>
        /// Files the control under a group name. Normally set by the enclosing
        /// <see cref="CustomControlGroupComponent"/> rather than called directly.
        /// </summary>
        public void SetGroup(string newGroup)
        {
            Group = newGroup ?? "";
            SendControlState();
        }

        /// <summary>
        /// Pushes the component's current label, ordering, group, and value to
        /// Tentacle. Every typed <c>SetValue</c> ends here.
        /// </summary>
        protected void SendControlState()
        {
            if (Handle == null || !Handle.IsRegistered) return;

            Handle.Control.Label = label;
            Handle.Control.SortIndex = sortIndex;
            Handle.Control.Group = string.IsNullOrEmpty(Group) ? null : Group;
            WriteValue(Handle.Control);
            Handle.PushState();
        }

        /// <summary>
        /// Builds the wire control this component stands for, with whatever
        /// defaults the type carries. The base fills in id, label, ordering and
        /// group afterwards.
        /// </summary>
        protected abstract CustomControl CreateControl();

        /// <summary>Copies this component's value onto the wire control.</summary>
        protected abstract void WriteValue(CustomControl control);

        // The Unreal plugin runs a raw-string ShouldReceiveValue ahead of its
        // typed hooks; here the typed hook is the only one, and it runs in
        // here, with the value already parsed into the component's own type.
        /// <summary>
        /// Takes the value Tentacle wrote onto the wire control: offers it to the
        /// component's typed <c>ShouldReceiveValue_</c> hook, and when the hook
        /// accepts it, copies it onto this component and raises the typed event
        /// for it. Returns false when the hook refused it.
        /// </summary>
        protected abstract bool ReadValue(CustomControl control, bool committed);

        /// <summary>Takes a value Tentacle changed, or puts our own back when the component refuses it.</summary>
        private void HandleValueChanged(JsonValue value)
        {
            Receive(false);
        }

        /// <summary>Takes a value the streamer settled on, subject to the same refusal.</summary>
        private void HandleValueCommitted(JsonValue value)
        {
            Receive(true);
        }

        /// <summary>
        /// Applies a value from Tentacle, or puts the component's own back on the
        /// wire control when the component refuses it.
        ///
        /// The handle writes the value onto the control before raising, so a
        /// refusal has to undo that: otherwise the component and the control it
        /// owns would disagree, and the next state push would send the value the
        /// component just rejected.
        /// </summary>
        private void Receive(bool committed)
        {
            if (Handle == null) return;
            if (!ReadValue(Handle.Control, committed)) WriteValue(Handle.Control);
        }

        /// <summary>The group name from the nearest group above this control, or empty.</summary>
        private string ResolveGroup()
        {
            var group = GetComponentInParent<CustomControlGroupComponent>();
            return group != null ? group.GroupName : "";
        }

        /// <summary>Raises the click event.</summary>
        private void RaiseClick()
        {
            InvokeListeners(onClick);
        }

        /// <summary>Raises the press-began event.</summary>
        private void RaiseMouseDown()
        {
            InvokeListeners(onMouseDown);
        }

        /// <summary>Raises the press-ended event.</summary>
        private void RaiseMouseUp()
        {
            InvokeListeners(onMouseUp);
        }

        // A UnityEvent calls its listeners in one pass and has no way to list the
        // ones added from code, so a listener that throws still stops the ones
        // after it on that event, as it would on any UnityEvent. Catching here
        // keeps the throw from reaching the handle and the pump behind it.
        /// <summary>Invokes a UnityEvent, reporting a listener that throws.</summary>
        internal static void InvokeListeners(UnityEvent unityEvent)
        {
            try
            {
                unityEvent.Invoke();
            }
            catch (Exception exception)
            {
                TentacleLog.Error("Tentacle: a custom-control listener threw: " + exception);
            }
        }

        /// <summary>Invokes a one-argument UnityEvent, reporting a listener that throws.</summary>
        internal static void InvokeListeners<T>(UnityEvent<T> unityEvent, T newValue)
        {
            try
            {
                unityEvent.Invoke(newValue);
            }
            catch (Exception exception)
            {
                TentacleLog.Error("Tentacle: a custom-control listener threw: " + exception);
            }
        }

        /// <summary>Invokes a two-argument UnityEvent, reporting a listener that throws.</summary>
        internal static void InvokeListeners<T>(UnityEvent<T, T> unityEvent, T newValue, T oldValue)
        {
            try
            {
                unityEvent.Invoke(newValue, oldValue);
            }
            catch (Exception exception)
            {
                TentacleLog.Error("Tentacle: a custom-control listener threw: " + exception);
            }
        }
    }
}
