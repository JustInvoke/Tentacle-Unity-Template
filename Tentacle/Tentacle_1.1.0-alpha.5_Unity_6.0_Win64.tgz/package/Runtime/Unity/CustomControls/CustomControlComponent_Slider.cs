// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Slider, with the same split.
    /// <summary>
    /// A slider in Tentacle's custom-control panel.
    ///
    /// <see cref="OnValueChangedFromApp"/> fires continuously while the streamer
    /// drags, <see cref="OnValueCommittedFromApp"/> once when they let go - the
    /// same split the app makes. Drive a live effect from the first; do
    /// expensive work on the second.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Slider)")]
    public class CustomControlComponent_Slider : CustomControlComponent
    {
        [Tooltip("Where the slider sits.")]
        [SerializeField]
        private float value;

        [Tooltip("Lowest value the slider allows.")]
        [SerializeField]
        private float minValue;

        [Tooltip("Highest value the slider allows.")]
        [SerializeField]
        private float maxValue = 100f;

        [Tooltip("Smallest change the slider makes.")]
        [SerializeField]
        private float step = 1f;

        [Tooltip("Raised continuously while the streamer drags, with the new value and the one it replaced.")]
        [SerializeField]
        private UnityEvent<float, float> onValueChangedFromApp = new UnityEvent<float, float>();

        [Tooltip("Raised once the streamer settles on a value.")]
        [SerializeField]
        private UnityEvent<float> onValueCommittedFromApp = new UnityEvent<float>();

        /// <summary>Where the slider sits.</summary>
        public float Value
        {
            get { return value; }
        }

        /// <summary>Lowest value the slider allows.</summary>
        public float MinValue
        {
            get { return minValue; }
        }

        /// <summary>Highest value the slider allows.</summary>
        public float MaxValue
        {
            get { return maxValue; }
        }

        /// <summary>Smallest change the slider makes.</summary>
        public float Step
        {
            get { return step; }
        }

        /// <summary>Raised continuously while the streamer drags, with the new value and the one it replaced.</summary>
        public UnityEvent<float, float> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on a value.</summary>
        public UnityEvent<float> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Slider"; }
        }

        /// <summary>Moves the slider and shows the new position in Tentacle.</summary>
        public void SetValue(float newValue)
        {
            value = newValue;
            SendControlState();
        }

        /// <summary>Changes the slider's range and shows it in Tentacle.</summary>
        public void SetRange(float newMinValue, float newMaxValue, float newStep)
        {
            minValue = newMinValue;
            maxValue = newMaxValue;
            step = newStep;
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_Float, the hook Number and
        // Slider share there.
        /// <summary>
        /// Whether to take a value the streamer set in Tentacle. Override to
        /// refuse it, or to clamp it: call <see cref="SetValue"/> with the value
        /// you want and return false. Returning false leaves the component and
        /// Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_Float(float newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Slider();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            var slider = (CustomControl_Slider)control;
            slider.Value = value;
            slider.Min = minValue;
            slider.Max = maxValue;
            slider.Step = step;
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Slider)control).Value;
            if (!ShouldReceiveValue_Float(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
