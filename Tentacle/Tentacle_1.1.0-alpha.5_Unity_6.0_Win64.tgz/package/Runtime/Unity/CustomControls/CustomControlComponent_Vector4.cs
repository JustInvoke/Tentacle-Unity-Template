// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Vector4.
    /// <summary>
    /// A four-component vector field in Tentacle's custom-control panel.
    ///
    /// The value is a Unity <see cref="Vector4"/>, so it can be assigned
    /// straight to a material property or used as a rect; the wire's own numeric
    /// tuple never reaches the game.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Vector4)")]
    public class CustomControlComponent_Vector4 : CustomControlComponent
    {
        [Tooltip("The vector shown in the field.")]
        [SerializeField]
        private Vector4 value = Vector4.zero;

        [Tooltip("Raised while the streamer edits the vector, with the new vector and the one it replaced.")]
        [SerializeField]
        private UnityEvent<Vector4, Vector4> onValueChangedFromApp = new UnityEvent<Vector4, Vector4>();

        [Tooltip("Raised once the streamer settles on a vector.")]
        [SerializeField]
        private UnityEvent<Vector4> onValueCommittedFromApp = new UnityEvent<Vector4>();

        /// <summary>The vector shown in the field.</summary>
        public Vector4 Value
        {
            get { return value; }
        }

        /// <summary>Raised while the streamer edits the vector, with the new vector and the one it replaced.</summary>
        public UnityEvent<Vector4, Vector4> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on a vector.</summary>
        public UnityEvent<Vector4> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Vector4"; }
        }

        /// <summary>Sets the vector and shows it in Tentacle.</summary>
        public void SetValue(Vector4 newValue)
        {
            value = newValue;
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_Vector4.
        /// <summary>
        /// Whether to take a vector the streamer set in Tentacle. Override to
        /// refuse it, or to clamp it: call <see cref="SetValue"/> with the vector
        /// you want and return false. Returning false leaves the component and
        /// Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_Vector4(Vector4 newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Vector4();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            ((CustomControl_Vector4)control).Value = value;
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Vector4)control).Value;
            if (!ShouldReceiveValue_Vector4(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
