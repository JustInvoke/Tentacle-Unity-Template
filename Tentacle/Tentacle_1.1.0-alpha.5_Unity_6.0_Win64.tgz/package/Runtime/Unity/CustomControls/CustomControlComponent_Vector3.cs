// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Vector3.
    /// <summary>
    /// A three-component vector field in Tentacle's custom-control panel.
    ///
    /// The value is a Unity <see cref="Vector3"/>, so it can be assigned
    /// straight to a transform or a material property; the wire's own numeric
    /// tuple never reaches the game.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Vector3)")]
    public class CustomControlComponent_Vector3 : CustomControlComponent
    {
        [Tooltip("The vector shown in the field.")]
        [SerializeField]
        private Vector3 value = Vector3.zero;

        [Tooltip("Raised while the streamer edits the vector, with the new vector and the one it replaced.")]
        [SerializeField]
        private UnityEvent<Vector3, Vector3> onValueChangedFromApp = new UnityEvent<Vector3, Vector3>();

        [Tooltip("Raised once the streamer settles on a vector.")]
        [SerializeField]
        private UnityEvent<Vector3> onValueCommittedFromApp = new UnityEvent<Vector3>();

        /// <summary>The vector shown in the field.</summary>
        public Vector3 Value
        {
            get { return value; }
        }

        /// <summary>Raised while the streamer edits the vector, with the new vector and the one it replaced.</summary>
        public UnityEvent<Vector3, Vector3> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on a vector.</summary>
        public UnityEvent<Vector3> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Vector3"; }
        }

        /// <summary>Sets the vector and shows it in Tentacle.</summary>
        public void SetValue(Vector3 newValue)
        {
            value = newValue;
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_Vector3.
        /// <summary>
        /// Whether to take a vector the streamer set in Tentacle. Override to
        /// refuse it, or to clamp it: call <see cref="SetValue"/> with the vector
        /// you want and return false. Returning false leaves the component and
        /// Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_Vector3(Vector3 newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Vector3();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            ((CustomControl_Vector3)control).Value = value;
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Vector3)control).Value;
            if (!ShouldReceiveValue_Vector3(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
