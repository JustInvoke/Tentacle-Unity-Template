// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Int.
    /// <summary>
    /// A whole-number field in Tentacle's custom-control panel.
    ///
    /// The same shape as <see cref="CustomControlComponent_Number"/> without
    /// the fractional part, for counts, indices, and anything a decimal would be
    /// wrong for.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Int)")]
    public class CustomControlComponent_Int : CustomControlComponent
    {
        [Tooltip("The whole number shown in the field.")]
        [SerializeField]
        private int value;

        [Tooltip("Raised while the streamer edits the number, with the new number and the one it replaced.")]
        [SerializeField]
        private UnityEvent<int, int> onValueChangedFromApp = new UnityEvent<int, int>();

        [Tooltip("Raised once the streamer settles on a number.")]
        [SerializeField]
        private UnityEvent<int> onValueCommittedFromApp = new UnityEvent<int>();

        /// <summary>The whole number shown in the field.</summary>
        public int Value
        {
            get { return value; }
        }

        /// <summary>Raised while the streamer edits the number, with the new number and the one it replaced.</summary>
        public UnityEvent<int, int> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on a number.</summary>
        public UnityEvent<int> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Int"; }
        }

        /// <summary>Sets the number and shows it in Tentacle.</summary>
        public void SetValue(int newValue)
        {
            value = newValue;
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_Int.
        /// <summary>
        /// Whether to take a number the streamer set in Tentacle. Override to
        /// refuse it, or to clamp it: call <see cref="SetValue"/> with the number
        /// you want and return false. Returning false leaves the component and
        /// Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_Int(int newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Int();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            ((CustomControl_Int)control).Value = value;
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Int)control).Value;
            if (!ShouldReceiveValue_Int(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
