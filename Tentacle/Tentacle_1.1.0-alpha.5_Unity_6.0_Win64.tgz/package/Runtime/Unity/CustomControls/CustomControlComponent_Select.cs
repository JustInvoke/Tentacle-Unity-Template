// Copyright Tentacle. All Rights Reserved.
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Select.
    /// <summary>
    /// A dropdown in Tentacle's custom-control panel.
    ///
    /// The options are the game's to define, and <see cref="SetOptions"/> can
    /// change them while the game runs - a level list that grows, a list of
    /// spawned actors. Tentacle only ever sends back one of the strings it was
    /// given.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Select)")]
    public class CustomControlComponent_Select : CustomControlComponent
    {
        [Tooltip("The option currently chosen.")]
        [SerializeField]
        private string value = "Option 1";

        [Tooltip("The options the streamer can choose from.")]
        [SerializeField]
        private List<string> options = new List<string> { "Option 1", "Option 2", "Option 3" };

        [Tooltip("Greyed-out hint shown while nothing is chosen.")]
        [SerializeField]
        private string placeholder = "Enter value...";

        [Tooltip("Raised when the streamer picks an option, with the new choice and the one it replaced.")]
        [SerializeField]
        private UnityEvent<string, string> onValueChangedFromApp = new UnityEvent<string, string>();

        [Tooltip("Raised once the streamer settles on an option.")]
        [SerializeField]
        private UnityEvent<string> onValueCommittedFromApp = new UnityEvent<string>();

        /// <summary>The option currently chosen.</summary>
        public string Value
        {
            get { return value; }
        }

        /// <summary>The options the streamer can choose from.</summary>
        public IReadOnlyList<string> Options
        {
            get { return options; }
        }

        /// <summary>Greyed-out hint shown while nothing is chosen.</summary>
        public string Placeholder
        {
            get { return placeholder; }
        }

        /// <summary>Raised when the streamer picks an option, with the new choice and the one it replaced.</summary>
        public UnityEvent<string, string> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on an option.</summary>
        public UnityEvent<string> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Select"; }
        }

        /// <summary>Chooses an option and shows it in Tentacle.</summary>
        public void SetValue(string newValue)
        {
            value = newValue ?? "";
            SendControlState();
        }

        /// <summary>Replaces the option list and shows it in Tentacle.</summary>
        public void SetOptions(IEnumerable<string> newOptions)
        {
            options = new List<string>();
            if (newOptions != null)
            {
                foreach (var option in newOptions) options.Add(option ?? "");
            }
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_String, the hook Select and
        // Text share there.
        /// <summary>
        /// Whether to take an option the streamer picked in Tentacle. Override to
        /// refuse it, or to substitute another: call <see cref="SetValue"/> with
        /// the option you want and return false. Returning false leaves the
        /// component and Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_String(string newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Select();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            var select = (CustomControl_Select)control;
            select.Value = value ?? "";
            select.Placeholder = placeholder ?? "";

            // A fresh list rather than the component's own: the control instance
            // outlives a single push, and handing it this list would let a later
            // SetOptions mutate what Tentacle was already told.
            select.Options = options != null ? new List<string>(options) : new List<string>();
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Select)control).Value;
            if (!ShouldReceiveValue_String(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
