// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Number.
    /// <summary>
    /// A number field in Tentacle's custom-control panel.
    ///
    /// Carries the same range as <see cref="CustomControlComponent_Slider"/>;
    /// the difference is how the streamer drives the value - a spinner field
    /// against a track - not what the game can constrain. The step is what one
    /// spinner click or arrow key moves the value by.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Number)")]
    public class CustomControlComponent_Number : CustomControlComponent
    {
        [Tooltip("The number shown in the field.")]
        [SerializeField]
        private float value;

        [Tooltip("Lowest value the field allows.")]
        [SerializeField]
        private float minValue;

        [Tooltip("Highest value the field allows.")]
        [SerializeField]
        private float maxValue = 100f;

        [Tooltip("How much one spinner click or arrow key moves the value.")]
        [SerializeField]
        private float step = 1f;

        [Tooltip("Raised while the streamer edits the number, with the new number and the one it replaced.")]
        [SerializeField]
        private UnityEvent<float, float> onValueChangedFromApp = new UnityEvent<float, float>();

        [Tooltip("Raised once the streamer settles on a number.")]
        [SerializeField]
        private UnityEvent<float> onValueCommittedFromApp = new UnityEvent<float>();

        /// <summary>The number shown in the field.</summary>
        public float Value
        {
            get { return value; }
        }

        /// <summary>Lowest value the field allows.</summary>
        public float MinValue
        {
            get { return minValue; }
        }

        /// <summary>Highest value the field allows.</summary>
        public float MaxValue
        {
            get { return maxValue; }
        }

        /// <summary>How much one spinner click or arrow key moves the value.</summary>
        public float Step
        {
            get { return step; }
        }

        /// <summary>Raised while the streamer edits the number, with the new number and the one it replaced.</summary>
        public UnityEvent<float, float> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on a number.</summary>
        public UnityEvent<float> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Number"; }
        }

        /// <summary>Sets the number and shows it in Tentacle.</summary>
        public void SetValue(float newValue)
        {
            value = newValue;
            SendControlState();
        }

        /// <summary>Changes the field's range and shows it in Tentacle.</summary>
        public void SetRange(float newMinValue, float newMaxValue, float newStep)
        {
            minValue = newMinValue;
            maxValue = newMaxValue;
            step = newStep;
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_Float, the hook Number and
        // Slider share there.
        /// <summary>
        /// Whether to take a number the streamer set in Tentacle. Override to
        /// refuse it, or to clamp it: call <see cref="SetValue"/> with the number
        /// you want and return false. Returning false leaves the component and
        /// Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_Float(float newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Number();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            var number = (CustomControl_Number)control;
            number.Value = value;
            number.Min = minValue;
            number.Max = maxValue;
            number.Step = step;
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Number)control).Value;
            if (!ShouldReceiveValue_Float(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
