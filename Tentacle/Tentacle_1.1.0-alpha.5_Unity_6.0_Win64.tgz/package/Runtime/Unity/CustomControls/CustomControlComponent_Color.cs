// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Color: a Unity Color, the
    // way the Unreal component hands Blueprint an FColor.
    /// <summary>
    /// A colour picker in Tentacle's custom-control panel.
    ///
    /// The value is a Unity <see cref="Color"/>: the "#RRGGBB" string the app
    /// actually sends is converted here rather than left for the game. Alpha is
    /// not part of the app's picker, so it is dropped on the way out and comes
    /// back opaque.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Color)")]
    public class CustomControlComponent_Color : CustomControlComponent
    {
        [Tooltip("The colour shown in the picker.")]
        [SerializeField]
        private Color value = Color.white;

        [Tooltip("Raised while the streamer adjusts the colour, with the new colour and the one it replaced.")]
        [SerializeField]
        private UnityEvent<Color, Color> onValueChangedFromApp = new UnityEvent<Color, Color>();

        [Tooltip("Raised once the streamer settles on a colour.")]
        [SerializeField]
        private UnityEvent<Color> onValueCommittedFromApp = new UnityEvent<Color>();

        /// <summary>The colour shown in the picker.</summary>
        public Color Value
        {
            get { return value; }
        }

        /// <summary>Raised while the streamer adjusts the colour, with the new colour and the one it replaced.</summary>
        public UnityEvent<Color, Color> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on a colour.</summary>
        public UnityEvent<Color> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Color"; }
        }

        /// <summary>Sets the colour and shows it in Tentacle.</summary>
        public void SetValue(Color newValue)
        {
            value = newValue;
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_Color.
        /// <summary>
        /// Whether to take a colour the streamer picked in Tentacle. Override to
        /// refuse it, or to clamp it: call <see cref="SetValue"/> with the colour
        /// you want and return false. Returning false leaves the component and
        /// Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_Color(Color newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Color();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            ((CustomControl_Color)control).Value = value.ToHex();
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            // Keeping what we had on an unparseable string is deliberate: the
            // alternative is a control that snaps to white whenever the app sends
            // something this version does not understand.
            var offered = TentacleConversions.ToColor(((CustomControl_Color)control).Value, value);
            if (!ShouldReceiveValue_Color(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
