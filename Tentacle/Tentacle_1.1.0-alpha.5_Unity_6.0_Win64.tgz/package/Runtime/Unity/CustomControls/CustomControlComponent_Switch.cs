// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Switch.
    /// <summary>
    /// An on/off switch in Tentacle's custom-control panel.
    ///
    /// A switch has no drag, so <see cref="OnValueChangedFromApp"/> and
    /// <see cref="OnValueCommittedFromApp"/> both fire on the same flip. Listen
    /// to whichever reads better where you use it.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Switch)")]
    public class CustomControlComponent_Switch : CustomControlComponent
    {
        [Tooltip("Whether the switch is on.")]
        [SerializeField]
        private bool value;

        [Tooltip("Raised when the streamer flips the switch, with the new position and the one it replaced.")]
        [SerializeField]
        private UnityEvent<bool, bool> onValueChangedFromApp = new UnityEvent<bool, bool>();

        [Tooltip("Raised when the streamer settles on a position.")]
        [SerializeField]
        private UnityEvent<bool> onValueCommittedFromApp = new UnityEvent<bool>();

        /// <summary>Whether the switch is on.</summary>
        public bool Value
        {
            get { return value; }
        }

        /// <summary>Raised when the streamer flips the switch, with the new position and the one it replaced.</summary>
        public UnityEvent<bool, bool> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised when the streamer settles on a position.</summary>
        public UnityEvent<bool> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Switch"; }
        }

        /// <summary>Sets the switch and shows it in Tentacle.</summary>
        public void SetValue(bool newValue)
        {
            value = newValue;
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_Bool.
        /// <summary>
        /// Whether to take a position the streamer set in Tentacle. Override to
        /// refuse it: returning false leaves the component and Tentacle's copy as
        /// they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_Bool(bool newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Switch();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            ((CustomControl_Switch)control).Value = value;
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Switch)control).Value;
            if (!ShouldReceiveValue_Bool(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
