// Copyright Tentacle. All Rights Reserved.
using UnityEngine;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlGroupComponent, Custom Control
    // (Group) in its Add Component menu, and it groups the same way.
    /// <summary>
    /// Files every custom control beneath it in the hierarchy under one group in
    /// Tentacle's panel.
    ///
    /// Grouping is by containment, so the grouping is something you can see in
    /// the hierarchy rather than a string repeated on each control. Controls
    /// read this when they register, and
    /// <see cref="SetGroupName"/> re-stamps the ones already registered.
    ///
    /// Nested groups resolve to the nearest one above a control, so an inner
    /// group wins over an outer.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Group)")]
    [DisallowMultipleComponent]
    public sealed class CustomControlGroupComponent : MonoBehaviour
    {
        [Tooltip("Heading this group appears under in Tentacle.")]
        [SerializeField]
        private string groupName = "New Group";

        /// <summary>Heading this group appears under in Tentacle.</summary>
        public string GroupName
        {
            get { return groupName; }
        }

        /// <summary>Renames the group and re-files every control already registered under it.</summary>
        public void SetGroupName(string newGroupName)
        {
            groupName = newGroupName ?? "";
            UpdateDescendantControls();
        }

        /// <summary>
        /// Pushes this group's name onto every control below it that a nearer
        /// group does not own.
        ///
        /// Inactive children are included, because a control disabled now will
        /// register with whatever this leaves on it when it is enabled again.
        /// </summary>
        private void UpdateDescendantControls()
        {
            var controls = GetComponentsInChildren<CustomControlComponent>(true);
            foreach (var control in controls)
            {
                if (control.GetComponentInParent<CustomControlGroupComponent>(true) != this) continue;
                control.SetGroup(groupName);
            }
        }
    }
}
