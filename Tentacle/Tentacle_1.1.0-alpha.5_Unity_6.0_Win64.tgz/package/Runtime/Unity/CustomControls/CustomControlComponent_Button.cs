// Copyright Tentacle. All Rights Reserved.
using UnityEngine;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Button.
    /// <summary>
    /// A button in Tentacle's custom-control panel.
    ///
    /// Carries no value: listen to <see cref="CustomControlComponent.OnClick"/>,
    /// or to OnMouseDown and OnMouseUp when the press itself matters - holding a
    /// horn down, say.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Button)")]
    public class CustomControlComponent_Button : CustomControlComponent
    {
        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Button"; }
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Button();
        }

        /// <summary>Nothing to write: a button has no value.</summary>
        protected override void WriteValue(CustomControl control)
        {
        }

        /// <summary>Nothing to read: a button has no value, so there is nothing to refuse.</summary>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            return true;
        }
    }
}
