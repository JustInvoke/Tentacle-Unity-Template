// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Vector2.
    /// <summary>
    /// A two-component vector field in Tentacle's custom-control panel.
    ///
    /// The value is a Unity <see cref="Vector2"/>, so it can be assigned
    /// straight to a transform or a material property; the wire's own numeric
    /// tuple never reaches the game.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Vector2)")]
    public class CustomControlComponent_Vector2 : CustomControlComponent
    {
        [Tooltip("The vector shown in the field.")]
        [SerializeField]
        private Vector2 value = Vector2.zero;

        [Tooltip("Raised while the streamer edits the vector, with the new vector and the one it replaced.")]
        [SerializeField]
        private UnityEvent<Vector2, Vector2> onValueChangedFromApp = new UnityEvent<Vector2, Vector2>();

        [Tooltip("Raised once the streamer settles on a vector.")]
        [SerializeField]
        private UnityEvent<Vector2> onValueCommittedFromApp = new UnityEvent<Vector2>();

        /// <summary>The vector shown in the field.</summary>
        public Vector2 Value
        {
            get { return value; }
        }

        /// <summary>Raised while the streamer edits the vector, with the new vector and the one it replaced.</summary>
        public UnityEvent<Vector2, Vector2> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on a vector.</summary>
        public UnityEvent<Vector2> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Vector2"; }
        }

        /// <summary>Sets the vector and shows it in Tentacle.</summary>
        public void SetValue(Vector2 newValue)
        {
            value = newValue;
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_Vector2.
        /// <summary>
        /// Whether to take a vector the streamer set in Tentacle. Override to
        /// refuse it, or to clamp it: call <see cref="SetValue"/> with the vector
        /// you want and return false. Returning false leaves the component and
        /// Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_Vector2(Vector2 newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Vector2();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            ((CustomControl_Vector2)control).Value = value;
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Vector2)control).Value;
            if (!ShouldReceiveValue_Vector2(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
