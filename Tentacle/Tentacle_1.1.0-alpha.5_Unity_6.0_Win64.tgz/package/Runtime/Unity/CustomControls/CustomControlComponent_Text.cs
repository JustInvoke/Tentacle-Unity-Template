// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomControlComponent_Text.
    /// <summary>
    /// A text field in Tentacle's custom-control panel.
    ///
    /// <see cref="OnValueChangedFromApp"/> fires as the streamer types;
    /// <see cref="OnValueCommittedFromApp"/> once they finish. Anything that costs
    /// real work - a lookup, a spawn - belongs on the commit.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Control (Text)")]
    public class CustomControlComponent_Text : CustomControlComponent
    {
        [Tooltip("The text in the field.")]
        [SerializeField]
        private string value = "";

        [Tooltip("Greyed-out hint shown while the field is empty.")]
        [SerializeField]
        private string placeholder = "Enter value...";

        [Tooltip("Raised as the streamer types, with the new text and the text it replaced.")]
        [SerializeField]
        private UnityEvent<string, string> onValueChangedFromApp = new UnityEvent<string, string>();

        [Tooltip("Raised once the streamer settles on the text.")]
        [SerializeField]
        private UnityEvent<string> onValueCommittedFromApp = new UnityEvent<string>();

        /// <summary>The text in the field.</summary>
        public string Value
        {
            get { return value; }
        }

        /// <summary>Greyed-out hint shown while the field is empty.</summary>
        public string Placeholder
        {
            get { return placeholder; }
        }

        /// <summary>Raised as the streamer types, with the new text and the text it replaced.</summary>
        public UnityEvent<string, string> OnValueChangedFromApp
        {
            get { return onValueChangedFromApp; }
        }

        /// <summary>Raised once the streamer settles on the text.</summary>
        public UnityEvent<string> OnValueCommittedFromApp
        {
            get { return onValueCommittedFromApp; }
        }

        /// <inheritdoc/>
        public override string ControlType
        {
            get { return "Text"; }
        }

        /// <summary>Sets the text and shows it in Tentacle.</summary>
        public void SetValue(string newValue)
        {
            value = newValue ?? "";
            SendControlState();
        }

        /// <summary>Changes the empty-field hint and shows it in Tentacle.</summary>
        public void SetPlaceholder(string newPlaceholder)
        {
            placeholder = newPlaceholder ?? "";
            SendControlState();
        }

        // The Unreal plugin's ShouldReceiveValue_String, the hook Select and
        // Text share there.
        /// <summary>
        /// Whether to take text the streamer typed in Tentacle. Override to
        /// refuse it, or to clean it up: call <see cref="SetValue"/> with the
        /// text you want and return false. Returning false leaves the component
        /// and Tentacle's copy as they were.
        /// </summary>
        protected virtual bool ShouldReceiveValue_String(string newValue)
        {
            return true;
        }

        /// <inheritdoc/>
        protected override CustomControl CreateControl()
        {
            return new CustomControl_Text();
        }

        /// <inheritdoc/>
        protected override void WriteValue(CustomControl control)
        {
            var text = (CustomControl_Text)control;
            text.Value = value ?? "";
            text.Placeholder = placeholder ?? "";
        }

        /// <inheritdoc/>
        protected override bool ReadValue(CustomControl control, bool committed)
        {
            var offered = ((CustomControl_Text)control).Value;
            if (!ShouldReceiveValue_String(offered)) return false;

            var previous = value;
            value = offered;
            if (committed) InvokeListeners(onValueCommittedFromApp, value);
            else InvokeListeners(onValueChangedFromApp, value, previous);
            return true;
        }
    }
}
