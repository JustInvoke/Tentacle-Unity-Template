// Copyright Tentacle. All Rights Reserved.
using UnityEngine;

namespace Tcl
{
    /// <summary>
    /// The hidden component that pumps the Tentacle client once per frame.
    ///
    /// It exists because delivering messages needs a frame tick and Unity has no
    /// engine-level per-frame callback outside a component. Hidden and not saved,
    /// so it never shows up in a scene, is never serialized into one, and cannot
    /// be deleted by accident; <see cref="Tentacle"/> creates it and no
    /// game ever needs to.
    /// </summary>
    [AddComponentMenu("")]
    [DisallowMultipleComponent]
    public sealed class TentacleHost : MonoBehaviour
    {
        /// <summary>Creates the host object. Only the runtime calls this.</summary>
        internal static TentacleHost Spawn()
        {
            var carrier = new GameObject("Tentacle")
            {
                hideFlags = HideFlags.HideAndDontSave,
            };
            var component = carrier.AddComponent<TentacleHost>();
            DontDestroyOnLoad(carrier);
            return component;
        }

        /// <summary>Delivers everything the socket received since the last frame.</summary>
        private void Update()
        {
            Tentacle.Pump();
        }

        /// <summary>Closes the connection when the game exits.</summary>
        private void OnApplicationQuit()
        {
            Tentacle.Shutdown();
        }
    }
}
