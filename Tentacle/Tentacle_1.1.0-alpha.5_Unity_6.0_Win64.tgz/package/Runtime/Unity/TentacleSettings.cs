// Copyright Tentacle. All Rights Reserved.
using UnityEngine;

namespace Tcl
{
    // The fields the Unreal plugin's ATentacle also has carry its names
    // (AutoConnect, SessionLabel, DataDirectoryOverride); the rest follow them.
    /// <summary>
    /// Project-wide Tentacle settings.
    ///
    /// Optional by design: with no asset in the project the defaults below apply
    /// and the plugin connects to a locally running Tentacle with no setup at
    /// all. Create one (Assets &gt; Create &gt; Tentacle &gt; Settings) inside any
    /// <c>Resources</c> folder, named <c>TentacleSettings</c>, to change them.
    ///
    /// Deliberately small. Tentacle publishes where it is listening, so there is
    /// no host or port to configure and nothing here is a credential; the fields
    /// are the handful of choices a project genuinely differs on.
    /// </summary>
    [CreateAssetMenu(fileName = ResourceName, menuName = "Tentacle/Settings")]
    public sealed class TentacleSettings : ScriptableObject
    {
        /// <summary>Name the asset must have inside a Resources folder to be found.</summary>
        public const string ResourceName = "TentacleSettings";

        [Header("Connection")]
        [Tooltip("Connect as soon as the game starts. Turn off to call Tentacle.Connect() yourself.")]
        public bool AutoConnect = true;

        [Tooltip("Name shown for this game in Tentacle's session list. Empty uses the product name.")]
        public string SessionLabel = "";

        [Tooltip("Tentacle's data folder, where its sidecar.json lives. Empty uses the platform default.")]
        public string DataDirectoryOverride = "";

        [Header("Reconnect")]
        [Tooltip("Delay before the first retry, in seconds.")]
        [Min(0f)]
        public float ReconnectInitialDelaySeconds = 1f;

        [Tooltip("Longest the retry delay is allowed to grow to, in seconds.")]
        [Min(0f)]
        public float ReconnectMaxDelaySeconds = 30f;

        [Header("Behaviour")]
        [Tooltip("Load the viewer-property registry as soon as a session opens. Needed for property reads by name.")]
        public bool RefreshRegistryOnConnect = true;

        [Tooltip("How many recent stream events are remembered, so a reconnect's replay is not delivered twice.")]
        [Min(1)]
        public int StreamDeduplicationWindow = TentacleDeduplicator.DefaultCapacity;

        [Header("Diagnostics")]
        [Tooltip("Send Tentacle's own diagnostics to the Unity console.")]
        public bool LogToConsole = true;

        [Tooltip("Include routine lifecycle messages (connected, disconnected) as well as problems.")]
        public bool LogLifecycle = true;

        /// <summary>
        /// The defaults instance handed out while the project has no asset. Kept
        /// rather than made per call: CreateInstance produces a real
        /// ScriptableObject that nothing destroys, and no asset is the normal
        /// state, so a fresh one per call would leak one object per call and
        /// Unity would report them all at domain unload. A domain reload clears
        /// this along with everything else.
        /// </summary>
        private static TentacleSettings defaults;

        /// <summary>
        /// The settings asset from Resources, or a defaults instance when the
        /// project has none. Never null: a missing asset is the normal state, not
        /// a misconfiguration.
        /// </summary>
        public static TentacleSettings LoadOrDefault()
        {
            var asset = Resources.Load<TentacleSettings>(ResourceName);
            if (asset != null) return asset;

            if (defaults == null) defaults = CreateInstance<TentacleSettings>();
            return defaults;
        }
    }
}
