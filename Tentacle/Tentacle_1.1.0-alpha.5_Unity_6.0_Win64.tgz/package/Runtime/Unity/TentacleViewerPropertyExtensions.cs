// Copyright Tentacle. All Rights Reserved.
using Tcl.Json;

namespace Tcl
{
    // Spelled exactly as the Unreal plugin spells them on UTclViewer:
    // Viewer->GetProperty_Int("Scores", "Points", Result) in C++ becomes
    // viewer.GetProperty_Int("Scores", "Points", out points) here, the value in
    // an out parameter and the outcome returned, which is C#'s TryGet shape.
    //
    // Extension methods rather than instance methods because the core keeps the
    // viewer a plain data object: it holds values keyed by id and knows nothing
    // about the registry that gives those ids names.
    /// <summary>
    /// Viewer-property reads and writes on the viewer itself:
    /// <c>viewer.GetProperty_Int("Scores", "Points", out points)</c>.
    ///
    /// The values live on the viewer and the registry resolves the names, so
    /// these forward to <see cref="Tentacle_ViewerProperties"/> and add nothing
    /// of their own; they exist because a game thinks "this viewer's score", not
    /// "the property service's opinion about this viewer".
    ///
    /// Each overload takes the surface to resolve against. The
    /// <see cref="Tentacle"/> singleton's is the default, so a game that
    /// uses the singleton - which is nearly all of them - never passes it.
    /// </summary>
    public static class TentacleViewerPropertyExtensions
    {
        /// <summary>Reads a viewer's property as a raw JSON value.</summary>
        public static FindPropertyResult GetPropertyValue(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            out JsonValue value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .GetPropertyValue(viewer, collectionName, propertyName, out value, caseSensitive);
        }

        /// <summary>Reads a viewer's property as a string.</summary>
        public static FindPropertyResult GetProperty_String(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            out string value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .GetProperty_String(viewer, collectionName, propertyName, out value, caseSensitive);
        }

        /// <summary>Reads a viewer's property as a floating-point number.</summary>
        public static FindPropertyResult GetProperty_Float(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            out double value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .GetProperty_Float(viewer, collectionName, propertyName, out value, caseSensitive);
        }

        /// <summary>Reads a viewer's property as a whole number.</summary>
        public static FindPropertyResult GetProperty_Int(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            out long value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .GetProperty_Int(viewer, collectionName, propertyName, out value, caseSensitive);
        }

        /// <summary>Reads a viewer's property as a boolean.</summary>
        public static FindPropertyResult GetProperty_Bool(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            out bool value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .GetProperty_Bool(viewer, collectionName, propertyName, out value, caseSensitive);
        }

        /// <summary>Writes a string property for this viewer.</summary>
        public static SetPropertyResult SetProperty_String(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            string value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .SetProperty_String(viewer, collectionName, propertyName, value, caseSensitive);
        }

        /// <summary>Writes a floating-point property for this viewer.</summary>
        public static SetPropertyResult SetProperty_Float(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            double value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .SetProperty_Float(viewer, collectionName, propertyName, value, caseSensitive);
        }

        /// <summary>Writes a whole-number property for this viewer.</summary>
        public static SetPropertyResult SetProperty_Int(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            long value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .SetProperty_Int(viewer, collectionName, propertyName, value, caseSensitive);
        }

        /// <summary>Writes a boolean property for this viewer.</summary>
        public static SetPropertyResult SetProperty_Bool(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            bool value,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .SetProperty_Bool(viewer, collectionName, propertyName, value, caseSensitive);
        }

        /// <summary>
        /// Adds an amount to this viewer's floating-point property, handing back
        /// the value it wrote.
        /// </summary>
        public static SetPropertyResult AddToProperty_Float(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            double amount,
            out double newValue,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .AddToProperty_Float(viewer, collectionName, propertyName, amount, out newValue, caseSensitive);
        }

        /// <summary>
        /// Adds an amount to this viewer's whole-number property, handing back
        /// the value it wrote.
        /// </summary>
        public static SetPropertyResult AddToProperty_Int(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            long amount,
            out long newValue,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .AddToProperty_Int(viewer, collectionName, propertyName, amount, out newValue, caseSensitive);
        }

        /// <summary>Flips this viewer's boolean property, handing back the value it wrote.</summary>
        public static SetPropertyResult ToggleProperty_Bool(
            this Viewer viewer,
            string collectionName,
            string propertyName,
            out bool newValue,
            bool caseSensitive = false,
            Tentacle_ViewerProperties properties = null)
        {
            return Resolve(properties)
                .ToggleProperty_Bool(viewer, collectionName, propertyName, out newValue, caseSensitive);
        }

        /// <summary>
        /// The surface to resolve names against: the caller's, or the singleton's.
        ///
        /// Deliberately reached through Tentacle.Client rather than a
        /// cached reference, because the runtime rebuilds its client on every
        /// domain reload and a cached one would go stale.
        /// </summary>
        private static Tentacle_ViewerProperties Resolve(Tentacle_ViewerProperties properties)
        {
            return properties ?? Tentacle.ViewerProperties;
        }
    }
}
