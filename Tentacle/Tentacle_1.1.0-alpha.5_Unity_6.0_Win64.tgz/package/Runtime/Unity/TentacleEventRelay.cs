// Copyright Tentacle. All Rights Reserved.
using System;
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // No Unreal counterpart as a type: an Unreal user binds the delegates on
    // UTentacle_Stream straight from the Details panel, and a Unity scene has no
    // such panel for a C# event. Every UnityEvent here is named after the event
    // it relays, so the names are the Unreal delegates' names. The per-kind
    // platform events are deliberately not relayed: nearly eighty UnityEvents
    // would bury the Inspector, and the catch-alls already carry them.
    /// <summary>
    /// Every event a scene reacts to, as UnityEvents you fill in from the
    /// Inspector, for a project that drives things from the scene rather than
    /// from code.
    ///
    /// Each UnityEvent carries the name and the arguments of the event it
    /// relays: the connection status, a viewer arriving, every stream event and
    /// every cross-platform "Anywhere" view of one, the end of a Twitch raid, and
    /// every custom event. It is a convenience over <see cref="Tentacle"/>,
    /// not a replacement: drop it on a GameObject; several may coexist.
    ///
    /// Each platform's own events, such as <c>OnCheer_Twitch</c>, are for code:
    /// subscribe to them on <see cref="Tentacle.Stream"/>. In the
    /// Inspector, <see cref="OnEvent_Twitch"/> and <see cref="OnEvent_Kick"/>
    /// carry them.
    ///
    /// Subscriptions are made in OnEnable and dropped in OnDisable, so a disabled
    /// object costs nothing and a destroyed one leaves no dangling handler.
    /// </summary>
    [AddComponentMenu("Tentacle/Tentacle Event Relay")]
    public sealed class TentacleEventRelay : MonoBehaviour
    {
        [Tooltip("Raised whenever the connection to Tentacle changes status.")]
        [SerializeField]
        private UnityEvent<ConnectionStatus> onConnectionStatusChanged = new UnityEvent<ConnectionStatus>();

        [Tooltip("Raised the first time a viewer is seen this session.")]
        [SerializeField]
        private UnityEvent<Viewer> onViewerAdded = new UnityEvent<Viewer>();

        [Tooltip("Raised for every stream event, whatever its platform or kind.")]
        [SerializeField]
        private UnityEvent<StreamEventBase, Viewer> onEventAnywhere = new UnityEvent<StreamEventBase, Viewer>();

        [Tooltip("Raised for every Twitch event.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Twitch_Base, Viewer> onEventTwitch = new UnityEvent<StreamEvent_Twitch_Base, Viewer>();

        [Tooltip("Raised for every Kick event.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Kick_Base, Viewer> onEventKick = new UnityEvent<StreamEvent_Kick_Base, Viewer>();

        [Tooltip("Raised when a viewer joins chat, on either platform.")]
        [SerializeField]
        private UnityEvent<Viewer> onChatJoinAnywhere = new UnityEvent<Viewer>();

        [Tooltip("Raised for a chat message from either platform. Commands are not included.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> onChatMessageAnywhere =
            new UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer>();

        [Tooltip("Raised for a chat message the app recognised as a command, from either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> onChatCommandAnywhere =
            new UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer>();

        [Tooltip("Raised for a chat message or command carrying at least one emoji.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> onChatMessageWithEmojisAnywhere =
            new UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer>();

        [Tooltip("Raised for a chat message or command carrying at least one emote.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> onChatMessageWithEmotesAnywhere =
            new UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer>();

        [Tooltip("Raised when a viewer is banned or timed out, on either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Ban, Viewer> onBanAnywhere =
            new UnityEvent<StreamEvent_Anywhere_Ban, Viewer>();

        [Tooltip("Raised when the channel's title, category, or similar changes. Carries no viewer.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChannelUpdate> onChannelUpdateAnywhere =
            new UnityEvent<StreamEvent_Anywhere_ChannelUpdate>();

        [Tooltip("Raised when a viewer cheers bits on Twitch.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Donation, Viewer> onDonationAnywhere =
            new UnityEvent<StreamEvent_Anywhere_Donation, Viewer>();

        [Tooltip("Raised on a new follow, on either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Follow, Viewer> onFollowAnywhere =
            new UnityEvent<StreamEvent_Anywhere_Follow, Viewer>();

        [Tooltip("Raised on a channel-points or reward redemption.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Redemption, Viewer> onRedemptionAnywhere =
            new UnityEvent<StreamEvent_Anywhere_Redemption, Viewer>();

        [Tooltip("Raised on a first-time subscription.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Subscription, Viewer> onSubscriptionAnywhere =
            new UnityEvent<StreamEvent_Anywhere_Subscription, Viewer>();

        [Tooltip("Raised on gifted subscriptions.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_SubscriptionGift, Viewer> onSubscriptionGiftAnywhere =
            new UnityEvent<StreamEvent_Anywhere_SubscriptionGift, Viewer>();

        [Tooltip("Raised when an existing subscription is renewed or resubscribed.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_SubscriptionRenewal, Viewer> onSubscriptionRenewalAnywhere =
            new UnityEvent<StreamEvent_Anywhere_SubscriptionRenewal, Viewer>();

        [Tooltip("Raised when the game calls EndRaid_Twitch, since Twitch sends no raid-over event.")]
        [SerializeField]
        private UnityEvent onRaidEndedTwitch = new UnityEvent();

        [Tooltip("Raised for any custom event the streamer configured.")]
        [SerializeField]
        private UnityEvent<CustomEvent, Viewer> onCustomEvent = new UnityEvent<CustomEvent, Viewer>();

        /// <summary>The client this relay subscribed to, so it unsubscribes from the same one.</summary>
        private TentacleClient subscribed;

        // The same seam as CustomControlComponent.RegistryOverride.
        /// <summary>
        /// The client relays subscribe to, or null for the singleton's - which is
        /// what a game always gets.
        /// </summary>
        internal static TentacleClient ClientOverride;

        /// <summary>Relays <see cref="TentacleClient.OnConnectionStatusChanged"/>.</summary>
        public UnityEvent<ConnectionStatus> OnConnectionStatusChanged
        {
            get { return onConnectionStatusChanged; }
        }

        /// <summary>Relays <see cref="Tentacle_Viewers.OnViewerAdded"/>.</summary>
        public UnityEvent<Viewer> OnViewerAdded
        {
            get { return onViewerAdded; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnEvent_Anywhere"/>.</summary>
        public UnityEvent<StreamEventBase, Viewer> OnEvent_Anywhere
        {
            get { return onEventAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnEvent_Twitch"/>.</summary>
        public UnityEvent<StreamEvent_Twitch_Base, Viewer> OnEvent_Twitch
        {
            get { return onEventTwitch; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnEvent_Kick"/>.</summary>
        public UnityEvent<StreamEvent_Kick_Base, Viewer> OnEvent_Kick
        {
            get { return onEventKick; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnChatJoin_Anywhere"/>.</summary>
        public UnityEvent<Viewer> OnChatJoin_Anywhere
        {
            get { return onChatJoinAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnChatMessage_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessage_Anywhere
        {
            get { return onChatMessageAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnChatCommand_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatCommand_Anywhere
        {
            get { return onChatCommandAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnChatMessageWithEmojis_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmojis_Anywhere
        {
            get { return onChatMessageWithEmojisAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnChatMessageWithEmotes_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmotes_Anywhere
        {
            get { return onChatMessageWithEmotesAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnBan_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Ban, Viewer> OnBan_Anywhere
        {
            get { return onBanAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnChannelUpdate_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChannelUpdate> OnChannelUpdate_Anywhere
        {
            get { return onChannelUpdateAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnDonation_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Donation, Viewer> OnDonation_Anywhere
        {
            get { return onDonationAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnFollow_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Follow, Viewer> OnFollow_Anywhere
        {
            get { return onFollowAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnRedemption_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Redemption, Viewer> OnRedemption_Anywhere
        {
            get { return onRedemptionAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnSubscription_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Subscription, Viewer> OnSubscription_Anywhere
        {
            get { return onSubscriptionAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnSubscriptionGift_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_SubscriptionGift, Viewer> OnSubscriptionGift_Anywhere
        {
            get { return onSubscriptionGiftAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnSubscriptionRenewal_Anywhere"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_SubscriptionRenewal, Viewer> OnSubscriptionRenewal_Anywhere
        {
            get { return onSubscriptionRenewalAnywhere; }
        }

        /// <summary>Relays <see cref="Tentacle_Stream.OnRaidEnded_Twitch"/>.</summary>
        public UnityEvent OnRaidEnded_Twitch
        {
            get { return onRaidEndedTwitch; }
        }

        /// <summary>Relays <see cref="Tentacle_CustomEvents.OnCustomEvent"/>.</summary>
        public UnityEvent<CustomEvent, Viewer> OnCustomEvent
        {
            get { return onCustomEvent; }
        }

        /// <summary>Starts relaying.</summary>
        private void OnEnable()
        {
            StartRelaying();
        }

        /// <summary>Stops relaying.</summary>
        private void OnDisable()
        {
            StopRelaying();
        }

        // Split out of OnEnable and OnDisable for the reason
        // CustomControlComponent.RegisterControl gives: Unity runs the enable
        // lifecycle only in play mode.
        /// <summary>Subscribes to the client. What OnEnable does.</summary>
        internal void StartRelaying()
        {
            if (subscribed != null) return;
            subscribed = ClientOverride ?? Tentacle.Client;

            subscribed.OnConnectionStatusChanged += RelayConnectionStatusChanged;
            subscribed.Viewers.OnViewerAdded += RelayViewerAdded;
            subscribed.Stream.OnEvent_Anywhere += RelayEventAnywhere;
            subscribed.Stream.OnEvent_Twitch += RelayEventTwitch;
            subscribed.Stream.OnEvent_Kick += RelayEventKick;
            subscribed.Stream.OnChatJoin_Anywhere += RelayChatJoin;
            subscribed.Stream.OnChatMessage_Anywhere += RelayChatMessage;
            subscribed.Stream.OnChatCommand_Anywhere += RelayChatCommand;
            subscribed.Stream.OnChatMessageWithEmojis_Anywhere += RelayChatMessageWithEmojis;
            subscribed.Stream.OnChatMessageWithEmotes_Anywhere += RelayChatMessageWithEmotes;
            subscribed.Stream.OnBan_Anywhere += RelayBan;
            subscribed.Stream.OnChannelUpdate_Anywhere += RelayChannelUpdate;
            subscribed.Stream.OnDonation_Anywhere += RelayDonation;
            subscribed.Stream.OnFollow_Anywhere += RelayFollow;
            subscribed.Stream.OnRedemption_Anywhere += RelayRedemption;
            subscribed.Stream.OnSubscription_Anywhere += RelaySubscription;
            subscribed.Stream.OnSubscriptionGift_Anywhere += RelaySubscriptionGift;
            subscribed.Stream.OnSubscriptionRenewal_Anywhere += RelaySubscriptionRenewal;
            subscribed.Stream.OnRaidEnded_Twitch += RelayRaidEnded;
            subscribed.CustomEvents.OnCustomEvent += RelayCustomEvent;
        }

        /// <summary>
        /// Unsubscribes from the client this relay actually subscribed to. What
        /// OnDisable does.
        ///
        /// Deliberately not through Tentacle.Client: leaving play mode
        /// tears the runtime down before components are disabled, and touching
        /// that property here would build a fresh client - and the GameObject
        /// that pumps it - in the middle of the teardown.
        /// </summary>
        internal void StopRelaying()
        {
            if (subscribed == null) return;

            subscribed.OnConnectionStatusChanged -= RelayConnectionStatusChanged;
            subscribed.Viewers.OnViewerAdded -= RelayViewerAdded;
            subscribed.Stream.OnEvent_Anywhere -= RelayEventAnywhere;
            subscribed.Stream.OnEvent_Twitch -= RelayEventTwitch;
            subscribed.Stream.OnEvent_Kick -= RelayEventKick;
            subscribed.Stream.OnChatJoin_Anywhere -= RelayChatJoin;
            subscribed.Stream.OnChatMessage_Anywhere -= RelayChatMessage;
            subscribed.Stream.OnChatCommand_Anywhere -= RelayChatCommand;
            subscribed.Stream.OnChatMessageWithEmojis_Anywhere -= RelayChatMessageWithEmojis;
            subscribed.Stream.OnChatMessageWithEmotes_Anywhere -= RelayChatMessageWithEmotes;
            subscribed.Stream.OnBan_Anywhere -= RelayBan;
            subscribed.Stream.OnChannelUpdate_Anywhere -= RelayChannelUpdate;
            subscribed.Stream.OnDonation_Anywhere -= RelayDonation;
            subscribed.Stream.OnFollow_Anywhere -= RelayFollow;
            subscribed.Stream.OnRedemption_Anywhere -= RelayRedemption;
            subscribed.Stream.OnSubscription_Anywhere -= RelaySubscription;
            subscribed.Stream.OnSubscriptionGift_Anywhere -= RelaySubscriptionGift;
            subscribed.Stream.OnSubscriptionRenewal_Anywhere -= RelaySubscriptionRenewal;
            subscribed.Stream.OnRaidEnded_Twitch -= RelayRaidEnded;
            subscribed.CustomEvents.OnCustomEvent -= RelayCustomEvent;
            subscribed = null;
        }

        private void RelayConnectionStatusChanged(ConnectionStatus status) { InvokeListeners(onConnectionStatusChanged, status); }

        private void RelayViewerAdded(Viewer viewer) { InvokeListeners(onViewerAdded, viewer); }

        private void RelayEventAnywhere(StreamEventBase e, Viewer v) { InvokeListeners(onEventAnywhere, e, v); }

        private void RelayEventTwitch(StreamEvent_Twitch_Base e, Viewer v) { InvokeListeners(onEventTwitch, e, v); }

        private void RelayEventKick(StreamEvent_Kick_Base e, Viewer v) { InvokeListeners(onEventKick, e, v); }

        private void RelayChatJoin(Viewer viewer) { InvokeListeners(onChatJoinAnywhere, viewer); }

        private void RelayChatMessage(StreamEvent_Anywhere_ChatMessage e, Viewer v) { InvokeListeners(onChatMessageAnywhere, e, v); }

        private void RelayChatCommand(StreamEvent_Anywhere_ChatMessage e, Viewer v) { InvokeListeners(onChatCommandAnywhere, e, v); }

        private void RelayChatMessageWithEmojis(StreamEvent_Anywhere_ChatMessage e, Viewer v) { InvokeListeners(onChatMessageWithEmojisAnywhere, e, v); }

        private void RelayChatMessageWithEmotes(StreamEvent_Anywhere_ChatMessage e, Viewer v) { InvokeListeners(onChatMessageWithEmotesAnywhere, e, v); }

        private void RelayBan(StreamEvent_Anywhere_Ban e, Viewer v) { InvokeListeners(onBanAnywhere, e, v); }

        private void RelayChannelUpdate(StreamEvent_Anywhere_ChannelUpdate e) { InvokeListeners(onChannelUpdateAnywhere, e); }

        private void RelayDonation(StreamEvent_Anywhere_Donation e, Viewer v) { InvokeListeners(onDonationAnywhere, e, v); }

        private void RelayFollow(StreamEvent_Anywhere_Follow e, Viewer v) { InvokeListeners(onFollowAnywhere, e, v); }

        private void RelayRedemption(StreamEvent_Anywhere_Redemption e, Viewer v) { InvokeListeners(onRedemptionAnywhere, e, v); }

        private void RelaySubscription(StreamEvent_Anywhere_Subscription e, Viewer v) { InvokeListeners(onSubscriptionAnywhere, e, v); }

        private void RelaySubscriptionGift(StreamEvent_Anywhere_SubscriptionGift e, Viewer v) { InvokeListeners(onSubscriptionGiftAnywhere, e, v); }

        private void RelaySubscriptionRenewal(StreamEvent_Anywhere_SubscriptionRenewal e, Viewer v) { InvokeListeners(onSubscriptionRenewalAnywhere, e, v); }

        private void RelayRaidEnded() { InvokeListeners(onRaidEndedTwitch); }

        private void RelayCustomEvent(CustomEvent e, Viewer v) { InvokeListeners(onCustomEvent, e, v); }

        // A UnityEvent calls its listeners in one pass, so a listener that throws
        // still stops the ones after it on that UnityEvent; catching here keeps
        // it from reaching the client's other subscribers.
        /// <summary>Invokes a UnityEvent, reporting a listener that throws.</summary>
        private static void InvokeListeners(UnityEvent unityEvent)
        {
            try
            {
                unityEvent.Invoke();
            }
            catch (Exception exception)
            {
                Report(exception);
            }
        }

        /// <summary>Invokes a one-argument UnityEvent, reporting a listener that throws.</summary>
        private static void InvokeListeners<T>(UnityEvent<T> unityEvent, T argument)
        {
            try
            {
                unityEvent.Invoke(argument);
            }
            catch (Exception exception)
            {
                Report(exception);
            }
        }

        /// <summary>Invokes a two-argument UnityEvent, reporting a listener that throws.</summary>
        private static void InvokeListeners<T1, T2>(UnityEvent<T1, T2> unityEvent, T1 first, T2 second)
        {
            try
            {
                unityEvent.Invoke(first, second);
            }
            catch (Exception exception)
            {
                Report(exception);
            }
        }

        /// <summary>Logs a listener that threw.</summary>
        private static void Report(Exception exception)
        {
            TentacleLog.Error("Tentacle: an event relay listener threw: " + exception);
        }
    }
}
