// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclCustomEventListenerComponent: the same list of
    // names, the same OnTriggered, and the same case rule, with CaseSensitive
    // (bCaseSensitive there) to opt into exact matching.
    /// <summary>
    /// Reacts to the custom events you name, authored in the scene: list the
    /// names in the Inspector and wire <see cref="OnTriggered"/> to whatever
    /// should happen.
    ///
    /// It listens while its GameObject is enabled and stops when it is disabled
    /// or destroyed, so there is nothing to subscribe or tear down in code.
    ///
    /// Names are matched case-insensitively by default; turn on
    /// <see cref="CaseSensitive"/> if you need exact matching. The list is read
    /// each time an event arrives, so names added while the game runs take
    /// effect at once.
    /// </summary>
    [AddComponentMenu("Tentacle/Custom Event Listener")]
    public sealed class CustomEventListenerComponent : MonoBehaviour
    {
        [Tooltip("The custom event names to react to, as they are named in Tentacle.")]
        [SerializeField]
        private List<string> eventNames = new List<string>();

        [Tooltip("Match the names exactly, case included. Off matches them whatever their case.")]
        [SerializeField]
        private bool caseSensitive;

        [Tooltip("Raised for each listed custom event, with the viewer who triggered it, or none.")]
        [SerializeField]
        private UnityEvent<CustomEvent, Viewer> onTriggered = new UnityEvent<CustomEvent, Viewer>();

        /// <summary>
        /// The surface this listener subscribed to, remembered so it unsubscribes
        /// from the same one - not through Tentacle, which leaving play
        /// mode may already have torn down.
        /// </summary>
        private Tentacle_CustomEvents subscribed;

        // The same seam as CustomControlComponent.RegistryOverride.
        /// <summary>
        /// The surface listeners subscribe to, or null for the singleton's -
        /// which is what a game always gets.
        /// </summary>
        internal static Tentacle_CustomEvents CustomEventsOverride;

        /// <summary>The custom event names this listener reacts to.</summary>
        public List<string> EventNames
        {
            get { return eventNames; }
        }

        /// <summary>
        /// Whether names must match exactly, case included. False, the default,
        /// matches them whatever their case.
        /// </summary>
        public bool CaseSensitive
        {
            get { return caseSensitive; }
            set { caseSensitive = value; }
        }

        /// <summary>Raised for each listed custom event, with the viewer who triggered it, or null for none.</summary>
        public UnityEvent<CustomEvent, Viewer> OnTriggered
        {
            get { return onTriggered; }
        }

        /// <summary>Starts listening.</summary>
        private void OnEnable()
        {
            StartListening();
        }

        /// <summary>Stops listening.</summary>
        private void OnDisable()
        {
            StopListening();
        }

        // Split out of OnEnable and OnDisable for the reason
        // CustomControlComponent.RegisterControl gives: Unity runs the enable
        // lifecycle only in play mode.
        /// <summary>Subscribes to every custom event. What OnEnable does.</summary>
        internal void StartListening()
        {
            if (subscribed != null) return;
            subscribed = CustomEventsOverride ?? Tentacle.CustomEvents;
            subscribed.OnCustomEvent += HandleCustomEvent;
        }

        /// <summary>Unsubscribes from the surface it subscribed to. What OnDisable does.</summary>
        internal void StopListening()
        {
            if (subscribed == null) return;
            subscribed.OnCustomEvent -= HandleCustomEvent;
            subscribed = null;
        }

        /// <summary>Passes a listed event on.</summary>
        private void HandleCustomEvent(CustomEvent customEvent, Viewer viewer)
        {
            if (customEvent == null || !Lists(customEvent.Name)) return;
            try
            {
                onTriggered.Invoke(customEvent, viewer);
            }
            catch (Exception exception)
            {
                TentacleLog.Error("Tentacle: a custom-event listener threw: " + exception);
            }
        }

        /// <summary>Whether <paramref name="name"/> is one of the listed names, under the case rule.</summary>
        private bool Lists(string name)
        {
            if (string.IsNullOrEmpty(name) || eventNames == null) return false;
            var comparison = caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            foreach (var listed in eventNames)
            {
                if (string.Equals(listed, name, comparison)) return true;
            }
            return false;
        }
    }
}
