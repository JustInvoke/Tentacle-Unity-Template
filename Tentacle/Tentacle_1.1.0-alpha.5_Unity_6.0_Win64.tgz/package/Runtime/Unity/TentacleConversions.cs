// Copyright Tentacle. All Rights Reserved.
using UnityEngine;

namespace Tcl
{
    // Vectors need no conversion: a control's value is a UnityEngine.Vector3
    // all the way down to the JSON reader, the way Unreal's is an FVector and
    // Godot's a Vector3. Colour is the one value the wire carries in a shape
    // Unity has no type for, because Tentacle's colour picker speaks hex.
    /// <summary>
    /// Turns the wire's "#RRGGBB" colour strings into the Unity
    /// <see cref="Color"/> a game assigns to something, and back.
    ///
    /// Used by the custom-control components, and public because a game reading
    /// a raw control or a viewer colour wants the same conversion.
    /// </summary>
    public static class TentacleConversions
    {
        /// <summary>
        /// The Unity colour for an "#RRGGBB" or "#RRGGBBAA" string, or
        /// <paramref name="fallback"/> when the string is empty or in a form
        /// Unity cannot parse. Never throws: the colour comes from a streaming
        /// platform, and one of them sending something unexpected must not take
        /// a game down.
        /// </summary>
        public static Color ToColor(string hex, Color fallback)
        {
            if (string.IsNullOrEmpty(hex)) return fallback;

            Color parsed;
            return ColorUtility.TryParseHtmlString(hex, out parsed) ? parsed : fallback;
        }

        /// <summary>The Unity colour for a hex string, falling back to white.</summary>
        public static Color ToColor(string hex)
        {
            return ToColor(hex, Color.white);
        }

        /// <summary>
        /// The "#RRGGBB" string for a Unity colour. Alpha is dropped: Tentacle's
        /// colour picker is opaque, and sending eight digits where it expects six
        /// would round-trip as a different colour.
        /// </summary>
        public static string ToHex(this Color value)
        {
            return "#" + ColorUtility.ToHtmlStringRGB(value);
        }

    }
}
