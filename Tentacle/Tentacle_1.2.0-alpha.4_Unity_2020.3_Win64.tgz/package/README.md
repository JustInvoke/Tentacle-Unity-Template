# Tentacle for Unity

Connect a Unity project to the [Tentacle](https://www.tentacle.live) desktop app:
stream events, chat, viewer properties, custom controls, custom events and OBS
calls, from C# or from the inspector.

Tentacle runs on the streamer's machine and hosts the connection; this package
dials in to it. Nothing in your game opens a listening socket, so there is no
firewall prompt, and several games can be connected at once - a play-mode
session beside a packaged build, for instance.

A game can also ship with Tentacle inside it, so its players need no app:
set **Build Mode** to **Embedded** in the settings asset, and the player signs in
to Twitch or Kick through `Tentacle.Connections`. See Embedded Mode in the
Unity docs at https://www.tentacle.live/docs.

## Requirements

- Unity 2020.3 LTS or newer
- Editor and Windows Standalone, on Mono or IL2CPP (Embedded mode: the Editor
  and 64-bit Windows players)
- The Tentacle desktop app, on the same machine, unless the game runs in
  Embedded mode

## Getting started

Nothing to configure. Add the package and the plugin connects to a running
Tentacle on its own:

```csharp
using Tcl;
using UnityEngine;

public sealed class Greeter : MonoBehaviour
{
    private void OnEnable()
    {
        Tentacle.OnChatMessage += HandleChatMessage;
    }

    private void OnDisable()
    {
        Tentacle.OnChatMessage -= HandleChatMessage;
    }

    private void HandleChatMessage(StreamEvent_Anywhere_ChatMessage message, Viewer viewer)
    {
        Debug.Log(viewer.DisplayName + " said " + message.Text);
    }
}
```

Prefer to wire things up in the scene? Drop a **Tentacle Event Relay** component
on a GameObject and fill in its UnityEvents from the inspector. The **Tentacle
Twitch Event Relay** and **Tentacle Kick Event Relay** do the same for each
platform's own chat message.

The names are the Unreal plugin's, minus Unreal's type prefixes, so what you
know from one carries over to the other.

## What you get

**Stream events.** Where an event lives says which platform it covers.
`Tentacle` itself raises the cross-platform events, for what Twitch and Kick
agree on: `OnChatMessage`, `OnChatCommand`, `OnFollow`, `OnDonation`,
`OnSubscription`, `OnBan`, and the rest. `Tentacle.Twitch` and `Tentacle.Kick`
raise each platform's own events, one for every kind of event it sends, named
after that platform's own reference, which hand you that kind already typed:

```csharp
Tentacle.Twitch.OnChannelCheer += (cheer, viewer) => Debug.Log(cheer.Bits + " bits");
Tentacle.Kick.OnChannelFollow += (followed, viewer) => Debug.Log(followed.Follower.Username + " followed");
```

`Tentacle.OnStreamEvent` carries everything, for handling many kinds in one
place with a type test such as `e is StreamEvent_Twitch_Cheer cheer`.

Every event about a viewer arrives with that viewer, already resolved. Events
are de-duplicated by id, so a handler never runs twice for one event. They are
sent live: events that happen while the game is disconnected are not sent when
it reconnects.

**Custom controls.** Sliders, switches, colour pickers and buttons the streamer
drives live from Tentacle's panel. Add a `Tentacle > Custom Control (Slider)`
component, set its label and range in the inspector, and wire its UnityEvents
there, or react from code:

```csharp
GetComponent<CustomControlComponent_Slider>().OnValueChangedFromApp.AddListener((value, previous) =>
{
    transform.localScale = Vector3.one * value;
});
```

The control appears in Tentacle when the object is enabled and disappears when
it is not. Put one under a `Custom Control (Group)` to file it under a heading.
Values arrive as Unity types - a `Color` for a colour picker, a `Vector3` for a
vector field.

**Viewer properties.** Per-viewer values the streamer defined - scores, levels,
currencies, flags - read and written by name:

```csharp
if (viewer.AddToProperty_Int("Game", "Score", 10, out var score) == SetPropertyResult.Success)
{
    Debug.Log("Score is now " + score);
}

if (viewer.GetProperty_Int("Game", "Lives", out var lives) == FindPropertyResult.Found)
{
    Debug.Log(lives);
}
```

Writes apply locally at once and reconcile with Tentacle in the background, so a
score updated per kill never waits on a round trip.

**Custom events.** Named events the streamer configured, so the game reacts to a
name and never has to encode the trigger rules:

```csharp
Tentacle.CustomEvents.Subscribe("Spawn Boss", (customEvent, viewer) => SpawnBoss());
```

Or add a `Tentacle > Custom Event Listener` component, list the names, and wire
its **On Triggered** in the inspector. Names are matched case-insensitively
unless you ask for exact matching.

**Chat and OBS.** `Tentacle.SendChatMessage("gg")` for every connected platform,
`Tentacle.Twitch.SendChatMessage("gg")` or `Tentacle.Kick.PostChatMessage("gg")`
for one, and `Tentacle.Obs.SetCurrentProgramScene("Ending")`. The game needs no OBS
credentials; Tentacle already holds the connection the streamer configured.

## Settings

Optional. With no asset in the project the defaults apply. To change them,
create one at **Assets > Create > Tentacle > Settings** inside any `Resources`
folder, named `TentacleSettings`: auto-connect, the session label shown in
Tentacle, reconnect backoff, and how much the plugin logs.

## Notes

- Tentacle not running is an ordinary state, never an error. The plugin retries
  with backoff and connects whenever the app comes up.
- Every event fires on the main thread, inside the frame that delivers it, so a
  handler may touch GameObjects freely.
- Entering and leaving play mode repeatedly leaves no orphaned sockets and no
  duplicated sessions in Tentacle.

## Support

Docs and downloads: [tentacle.live](https://www.tentacle.live)
