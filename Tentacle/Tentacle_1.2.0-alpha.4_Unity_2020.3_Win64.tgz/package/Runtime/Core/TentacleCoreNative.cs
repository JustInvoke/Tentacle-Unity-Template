// Copyright Tentacle. All Rights Reserved.
using System;
using System.Runtime.InteropServices;

namespace Tcl
{
    // The C ABI of the Tentacle core (crates/tentacle-ffi, declared in
    // include/tentacle_ffi.h), one to one. Blittable types only - IntPtr
    // handles, byte arrays, and integers - so Mono and IL2CPP marshal it
    // identically, and there are no callbacks: IL2CPP would need every one to be
    // a static method, and a domain reload would leave one dangling.
    /// <summary>The native Tentacle core's functions.</summary>
    internal static class TentacleCoreNative
    {
        /// <summary>The library's name, which Unity resolves per platform (tentacle_ffi.dll on Windows).</summary>
        private const string Library = "tentacle_ffi";

        /// <summary>tcl_connection_send's success result.</summary>
        internal const int Ok = 0;

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern IntPtr tcl_version();

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern IntPtr tcl_core_create(byte[] configJson, UIntPtr length);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern void tcl_core_destroy(IntPtr core);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern IntPtr tcl_connection_open(IntPtr core);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern int tcl_connection_send(IntPtr connection, byte[] frame, UIntPtr length);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern long tcl_connection_poll(IntPtr connection, byte[] buffer, UIntPtr capacity);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern int tcl_connection_wait(IntPtr connection, uint timeoutMilliseconds);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern int tcl_connection_is_closed(IntPtr connection);

        [DllImport(Library, CallingConvention = CallingConvention.Cdecl)]
        internal static extern void tcl_connection_close(IntPtr connection);
    }
}
