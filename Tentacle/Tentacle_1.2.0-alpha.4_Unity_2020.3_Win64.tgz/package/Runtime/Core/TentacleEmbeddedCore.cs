// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.Text;
using Tcl.Json;

namespace Tcl
{
    /// <summary>
    /// How Tentacle runs when it is embedded in the game rather than reached in
    /// the Tentacle app.
    /// </summary>
    public sealed class TentacleEmbeddedOptions
    {
        /// <summary>
        /// Where embedded Tentacle keeps what it remembers between runs, such as
        /// the signed-in accounts. Null or empty keeps nothing, so the player
        /// signs in again every run.
        /// </summary>
        public string DataDirectory;

        /// <summary>
        /// The client ID of your own Twitch application, to sign in with instead
        /// of Tentacle's. Null or empty uses Tentacle's.
        /// </summary>
        public string TwitchClientId;

        /// <summary>
        /// The config the game ships: the text of the files the Tentacle app
        /// exports (Data &gt; Export: Timers, Custom Events, Viewer
        /// Properties, and Bot), applied each time Tentacle starts. What each
        /// file defines wins by name, so a game update that ships a changed
        /// file brings its players' copies in line with it, and a change the
        /// game makes to one of those items while it runs lasts until the next
        /// start. What the files stop naming is removed, except a viewer
        /// property or collection, which is kept with every value viewers
        /// hold. What the game creates itself is never touched. A file
        /// Tentacle cannot read is skipped and reported in the log, and then
        /// nothing is removed. <see cref="Tentacle"/> fills this from the
        /// settings' config folder.
        /// </summary>
        public IList<string> ConfigFiles;

        /// <summary>The options as the core reads them.</summary>
        internal byte[] ToConfigJson()
        {
            var members = new List<KeyValuePair<string, JsonValue>>();
            if (!string.IsNullOrEmpty(DataDirectory))
            {
                members.Add(JsonValue.Member("dataDirectory", JsonValue.FromString(DataDirectory)));
            }
            if (!string.IsNullOrEmpty(TwitchClientId))
            {
                members.Add(JsonValue.Member("twitchClientId", JsonValue.FromString(TwitchClientId)));
            }
            if (ConfigFiles != null && ConfigFiles.Count > 0)
            {
                var files = new List<JsonValue>();
                foreach (var file in ConfigFiles)
                {
                    if (!string.IsNullOrEmpty(file)) files.Add(JsonValue.FromString(file));
                }
                members.Add(JsonValue.Member("configFiles", JsonValue.FromArray(files)));
            }
            return Encoding.UTF8.GetBytes(JsonValue.Object(members.ToArray()).ToJson());
        }
    }

    // One core per process, because a core is a whole Tentacle: its own Twitch
    // session, token refreshes and state on disk. Every embedded connection is a
    // session on it, as every WebSocket is on the app.
    /// <summary>
    /// The Tentacle core running inside this process, which embedded
    /// connections are sessions on. Started by the first embedded connection.
    /// </summary>
    public static class TentacleEmbeddedCore
    {
        private static readonly object Gate = new object();
        private static IntPtr core;
        private static bool unloadHooked;
        private static byte[] runningConfig;
        private static bool warnedOtherSettings;

        // Every connection open on the core, so stopping it closes each one
        // first: a transport nothing disposed (one left by a domain reload, or
        // a disconnect still closing in the background) would otherwise keep
        // its native handle, and its reader thread, for good.
        private static readonly HashSet<IOpenConnection> Open = new HashSet<IOpenConnection>();

        /// <summary>A connection the core closes as it stops.</summary>
        internal interface IOpenConnection
        {
            /// <summary>Ends the connection's reader and closes its handle.</summary>
            void Stop();
        }

        /// <summary>Remembers <paramref name="connection"/> until it stops.</summary>
        internal static void Track(IOpenConnection connection)
        {
            lock (Gate) Open.Add(connection);
        }

        /// <summary>Forgets <paramref name="connection"/>, which has stopped.</summary>
        internal static void Untrack(IOpenConnection connection)
        {
            lock (Gate) Open.Remove(connection);
        }

        /// <summary>How many connections are open on the core.</summary>
        internal static int OpenConnectionCount
        {
            get
            {
                lock (Gate) return Open.Count;
            }
        }

        /// <summary>Whether two configs are the same bytes.</summary>
        private static bool SameConfig(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return a == b;
            for (var i = 0; i < a.Length; i++)
            {
                if (a[i] != b[i]) return false;
            }
            return true;
        }

        /// <summary>Whether the core is running.</summary>
        public static bool IsRunning
        {
            get
            {
                lock (Gate) return core != IntPtr.Zero;
            }
        }

        /// <summary>
        /// The running core, started with <paramref name="options"/> if it is not
        /// running yet (a running core keeps the options it started with). Zero
        /// when it could not start. Throws <see cref="DllNotFoundException"/>
        /// when the native library is missing from this build.
        /// </summary>
        internal static IntPtr Acquire(TentacleEmbeddedOptions options)
        {
            lock (Gate)
            {
                var config = (options ?? new TentacleEmbeddedOptions()).ToConfigJson();
                if (core != IntPtr.Zero)
                {
                    // As Unreal's and Godot's do: a second start that asks for
                    // other settings gets the running core's, which says so once.
                    if (!warnedOtherSettings && !SameConfig(config, runningConfig))
                    {
                        warnedOtherSettings = true;
                        TentacleLog.Warn("Tentacle: the embedded core is already running with other Embedded settings; it keeps those until it restarts");
                    }
                    return core;
                }

                core = TentacleCoreNative.tcl_core_create(config, (UIntPtr)config.Length);
                if (core == IntPtr.Zero)
                {
                    TentacleLog.Error("Tentacle: the embedded core could not start");
                    return IntPtr.Zero;
                }
                runningConfig = config;
                warnedOtherSettings = false;

                if (!unloadHooked)
                {
                    // The native library outlives a domain reload, and so would a
                    // core nothing can reach any more, still holding its Twitch
                    // session open. Stopping it with the domain prevents that.
                    unloadHooked = true;
                    AppDomain.CurrentDomain.DomainUnload += (sender, args) => Shutdown();
                    AppDomain.CurrentDomain.ProcessExit += (sender, args) => Shutdown();
                }
                TentacleLog.Info("Tentacle: started the embedded core");
                return core;
            }
        }

        /// <summary>
        /// Stops the core, closing every embedded connection. The next embedded
        /// connection starts a fresh one. Safe to call when it is not running.
        /// </summary>
        public static void Shutdown()
        {
            IntPtr stopping;
            IOpenConnection[] open;
            lock (Gate)
            {
                stopping = core;
                core = IntPtr.Zero;
                runningConfig = null;
                warnedOtherSettings = false;
                open = new IOpenConnection[Open.Count];
                Open.CopyTo(open);
            }
            // The core first, which closes every session: each reader sees its
            // session end and reports it, as losing the core should be reported.
            // Handles stay valid after the core is gone, so closing them follows,
            // outside the lock, since stopping one waits for its reader.
            if (stopping != IntPtr.Zero)
            {
                TentacleCoreNative.tcl_core_destroy(stopping);
                TentacleLog.Info("Tentacle: stopped the embedded core");
            }
            foreach (var connection in open) connection.Stop();
        }
    }
}
