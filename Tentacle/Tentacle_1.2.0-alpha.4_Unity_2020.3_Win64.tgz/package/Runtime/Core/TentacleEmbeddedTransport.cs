// Copyright Tentacle. All Rights Reserved.
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // The frames are the engine protocol exactly as the app's WebSocket carries
    // it, so the client above cannot tell the difference; only the transport
    // under it changes. A reader thread sleeps in tcl_connection_wait and hands
    // each frame on; the client already marshals transport events onto the
    // game's thread.
    /// <summary>
    /// The session socket for Tentacle embedded in the game: a connection to
    /// the Tentacle core running in this process (<see cref="TentacleEmbeddedCore"/>)
    /// instead of a WebSocket to the Tentacle app.
    ///
    /// Features:
    /// - No app, port, or discovery file: the first connection starts the core
    /// - The same engine protocol frames as the WebSocket, so nothing above the
    ///   transport changes
    /// - A missing native library fails the connection with an explanation
    ///   rather than throwing into the game
    /// </summary>
    public sealed class TentacleEmbeddedTransport : ITentacleSocket
    {
        /// <summary>How long the reader sleeps between checks that it should stop.</summary>
        private const uint WaitMilliseconds = 100;

        /// <summary>
        /// How long stopping waits for the reader, well past the reader's own
        /// wait. One that is not back by then is left to end on its own, with
        /// its handle open, rather than closed under a call in progress.
        /// </summary>
        private const int StopWaitMilliseconds = 2000;

        private readonly TentacleEmbeddedOptions options;
        private readonly object gate = new object();
        private Session session;
        private Task pendingStop;
        private bool missingLibraryReported;

        /// <summary>Raised for every inbound message, with its type and payload.</summary>
        public event Action<string, JsonValue> MessageReceived;

        /// <summary>Raised when the core ends the connection.</summary>
        public event Action<string> Disconnected;

        /// <summary>Raised when the transport fails.</summary>
        public event Action<string> Faulted;

        /// <summary>A transport that starts the core with <paramref name="options"/> if it is not running.</summary>
        public TentacleEmbeddedTransport(TentacleEmbeddedOptions options)
        {
            this.options = options ?? new TentacleEmbeddedOptions();
        }

        /// <summary>
        /// Opens a connection to the embedded core, starting it if need be.
        /// <paramref name="url"/> is ignored: the core is in this process.
        /// </summary>
        public Task<bool> ConnectAsync(string url, CancellationToken cancellationToken)
        {
            if (cancellationToken.IsCancellationRequested) return Task.FromResult(false);
            try
            {
                var core = TentacleEmbeddedCore.Acquire(options);
                if (core == IntPtr.Zero) return Task.FromResult(false);

                var handle = TentacleCoreNative.tcl_connection_open(core);
                if (handle == IntPtr.Zero) return Task.FromResult(false);

                var opened = new Session(this, handle);
                Session replaced;
                lock (gate)
                {
                    replaced = session;
                    session = opened;
                }
                if (replaced != null) replaced.Stop();
                opened.Start();
                return Task.FromResult(true);
            }
            catch (Exception exception) when (exception is DllNotFoundException || exception is EntryPointNotFoundException)
            {
                // Retrying cannot fix a build without the library, so say so once
                // rather than on every attempt.
                if (!missingLibraryReported)
                {
                    missingLibraryReported = true;
                    TentacleLog.Error(
                        "Tentacle: embedded mode needs the tentacle_ffi native library, which this build does not have ("
                        + exception.Message + ")");
                }
                return Task.FromResult(false);
            }
        }

        /// <summary>Closes the connection, ending its session.</summary>
        public Task DisconnectAsync()
        {
            Session closing;
            Task stopping;
            lock (gate)
            {
                closing = session;
                session = null;
                if (closing == null) return Task.CompletedTask;
                // Off the game's thread: stopping waits for the reader to wake.
                // Kept, so Dispose can wait for it rather than return with the
                // handle still open.
                stopping = Task.Run(() => closing.Stop());
                pendingStop = stopping;
            }
            return stopping;
        }

        /// <summary>Sends one message.</summary>
        public Task SendAsync(string messageType, JsonValue data)
        {
            Session current;
            lock (gate) current = session;
            if (current == null)
            {
                TentacleLog.Warn("Tentacle: dropping " + messageType + "; the embedded connection is not open");
                return Task.CompletedTask;
            }

            var envelope = data == null
                ? JsonValue.Object(JsonValue.Member("type", JsonValue.FromString(messageType)))
                : JsonValue.Object(
                    JsonValue.Member("type", JsonValue.FromString(messageType)),
                    JsonValue.Member("data", data));
            current.Send(messageType, Encoding.UTF8.GetBytes(envelope.ToJson()));
            return Task.CompletedTask;
        }

        /// <summary>Closes the connection and releases the transport.</summary>
        public void Dispose()
        {
            Session closing;
            Task stopping;
            lock (gate)
            {
                closing = session;
                session = null;
                stopping = pendingStop;
                pendingStop = null;
            }
            if (closing != null) closing.Stop();
            // A disconnect still closing in the background: the transport is not
            // released until its handle is.
            if (stopping != null) stopping.Wait(StopWaitMilliseconds);
        }

        /// <summary>Hands one frame from the core to the subscriber.</summary>
        private void Receive(string frame)
        {
            var envelope = JsonValue.ParseOrNull(frame);
            var type = envelope != null ? JsonRead.ReadOptionalString(envelope, "type") : null;
            if (string.IsNullOrEmpty(type))
            {
                TentacleLog.Warn("Tentacle: ignoring a frame from the embedded core with no message type");
                return;
            }
            JsonValue data;
            if (!envelope.TryGetMember("data", out data)) data = null;

            var handler = MessageReceived;
            if (handler != null) handler(type, data);
        }

        private void RaiseDisconnected(string reason)
        {
            var handler = Disconnected;
            if (handler != null) handler(reason);
        }

        private void RaiseFaulted(string message)
        {
            var handler = Faulted;
            if (handler != null) handler(message);
        }

        // One open connection and the thread reading it. A reconnect makes a new
        // one, so a late frame from the old reader can never land on the new
        // session's handle, and the handle is closed only once its reader has
        // stopped - the C ABI forbids closing it under a call in progress.
        private sealed class Session : TentacleEmbeddedCore.IOpenConnection
        {
            private readonly TentacleEmbeddedTransport owner;
            private readonly object sendGate = new object();
            private readonly Thread reader;
            private IntPtr handle;
            private volatile bool stopping;

            public Session(TentacleEmbeddedTransport owner, IntPtr handle)
            {
                this.owner = owner;
                this.handle = handle;
                reader = new Thread(Read) { IsBackground = true, Name = "Tentacle embedded reader" };
            }

            public void Start()
            {
                TentacleEmbeddedCore.Track(this);
                reader.Start();
            }

            public void Send(string messageType, byte[] frame)
            {
                lock (sendGate)
                {
                    if (handle == IntPtr.Zero) return;
                    var result = TentacleCoreNative.tcl_connection_send(handle, frame, (UIntPtr)frame.Length);
                    if (result != TentacleCoreNative.Ok)
                    {
                        TentacleLog.Warn("Tentacle: the embedded core refused " + messageType + " (" + result + ")");
                    }
                }
            }

            /// <summary>
            /// Stops the reader and closes the connection. Safe to call more than
            /// once, and from two threads at once (a disconnect closing in the
            /// background and the core's shutdown).
            /// </summary>
            public void Stop()
            {
                stopping = true;
                if (Thread.CurrentThread != reader && reader.IsAlive && !reader.Join(StopWaitMilliseconds))
                {
                    // The C ABI forbids closing the handle under a call in progress.
                    TentacleLog.Warn("Tentacle: the embedded reader did not stop in time; leaving its connection open");
                    return;
                }
                lock (sendGate)
                {
                    if (handle != IntPtr.Zero)
                    {
                        TentacleCoreNative.tcl_connection_close(handle);
                        handle = IntPtr.Zero;
                    }
                }
                TentacleEmbeddedCore.Untrack(this);
            }

            private void Read()
            {
                var buffer = new byte[64 * 1024];
                try
                {
                    while (!stopping)
                    {
                        if (TentacleCoreNative.tcl_connection_wait(handle, WaitMilliseconds) == 0) continue;
                        while (!stopping)
                        {
                            var length = TentacleCoreNative.tcl_connection_poll(handle, buffer, (UIntPtr)buffer.Length);
                            if (length > 0)
                            {
                                owner.Receive(Encoding.UTF8.GetString(buffer, 0, (int)length));
                            }
                            else if (length < 0)
                            {
                                // The frame stays queued until a buffer fits it.
                                buffer = new byte[checked((int)-length)];
                            }
                            else
                            {
                                break;
                            }
                        }
                        if (!stopping && TentacleCoreNative.tcl_connection_is_closed(handle) != 0)
                        {
                            owner.RaiseDisconnected("the embedded core closed the session");
                            return;
                        }
                    }
                }
                catch (Exception exception)
                {
                    if (!stopping) owner.RaiseFaulted("the embedded connection failed: " + exception.Message);
                }
            }
        }
    }
}
