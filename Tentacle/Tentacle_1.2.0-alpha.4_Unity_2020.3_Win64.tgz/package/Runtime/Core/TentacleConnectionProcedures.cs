// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Concurrent;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // The core's side is crates/tentacle-core/src/rpc: it answers each
    // Rpc_Request with the status and body the app's /api/trpc/<procedure>
    // would, so the generated client reads the answer exactly as it reads
    // the app's.
    /// <summary>
    /// Carries the tRPC procedures over the engine connection instead of HTTP,
    /// for Tentacle embedded in the game.
    ///
    /// It sits under the generated <see cref="TentacleHttpClient"/> as its
    /// HTTP handler, so everything above it is unchanged: each request becomes
    /// an <c>Rpc_Request</c> frame naming the procedure and carrying its input
    /// (a query's <c>?input=</c>, or a mutation's body), and the matching
    /// <c>Rpc_Response</c> becomes the response.
    ///
    /// Features:
    /// - Answers are matched to their requests by id, so calls may overlap
    /// - An answer completes its call on the transport's thread, never waiting
    ///   for a Pump, so a caller can await it from anywhere
    /// - A call with no session, or whose session ends before it is answered,
    ///   fails as a transport error, which the generated client reports as one
    /// - A cancelled call is forgotten, and its answer ignored when it comes
    /// </summary>
    internal sealed class TentacleConnectionProcedures : HttpMessageHandler
    {
        /// <summary>Message type of a procedure call.</summary>
        public const string RequestType = "Rpc_Request";

        /// <summary>Message type of a procedure's answer.</summary>
        public const string ResponseType = "Rpc_Response";

        private const string ProcedurePath = "/api/trpc/";

        private readonly Func<string, JsonValue, bool> send;
        private readonly ConcurrentDictionary<string, TaskCompletionSource<HttpResponseMessage>> pending =
            new ConcurrentDictionary<string, TaskCompletionSource<HttpResponseMessage>>();
        private long lastId;

        /// <summary>
        /// Calls go out through <paramref name="send"/>, which sends a message
        /// on the session and answers false when there is none.
        /// </summary>
        public TentacleConnectionProcedures(Func<string, JsonValue, bool> send)
        {
            this.send = send;
        }

        /// <summary>How many calls are waiting for their answer.</summary>
        public int PendingCount
        {
            get { return pending.Count; }
        }

        /// <inheritdoc />
        protected override async Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            var uri = request.RequestUri;
            var path = uri != null ? uri.AbsolutePath : "";
            var at = path.IndexOf(ProcedurePath, StringComparison.Ordinal);
            if (at < 0)
            {
                throw new HttpRequestException("not a Tentacle procedure: " + uri);
            }
            var procedure = Uri.UnescapeDataString(path.Substring(at + ProcedurePath.Length));

            string input;
            if (request.Content != null)
            {
                input = await request.Content.ReadAsStringAsync().ConfigureAwait(false);
            }
            else
            {
                input = QueryInput(uri.Query);
            }

            var id = "rpc-" + Interlocked.Increment(ref lastId);
            var answer = new TaskCompletionSource<HttpResponseMessage>(TaskCreationOptions.RunContinuationsAsynchronously);
            pending[id] = answer;

            var data = string.IsNullOrEmpty(input)
                ? JsonValue.Object(
                    JsonValue.Member("id", JsonValue.FromString(id)),
                    JsonValue.Member("procedure", JsonValue.FromString(procedure)))
                : JsonValue.Object(
                    JsonValue.Member("id", JsonValue.FromString(id)),
                    JsonValue.Member("procedure", JsonValue.FromString(procedure)),
                    JsonValue.Member("input", JsonValue.FromString(input)));

            bool sent;
            try
            {
                sent = send(RequestType, data);
            }
            catch
            {
                Forget(id);
                throw;
            }
            if (!sent)
            {
                Forget(id);
                throw new HttpRequestException("there is no connection to Tentacle");
            }

            using (cancellationToken.Register(() =>
            {
                TaskCompletionSource<HttpResponseMessage> abandoned;
                if (pending.TryRemove(id, out abandoned)) abandoned.TrySetCanceled(cancellationToken);
            }))
            {
                var response = await answer.Task.ConfigureAwait(false);
                response.RequestMessage = request;
                return response;
            }
        }

        /// <summary>
        /// Completes the call an <c>Rpc_Response</c> answers. True when it
        /// answered a call still waiting; an answer to a call that was
        /// cancelled, or to none, is dropped.
        /// </summary>
        public bool Complete(JsonValue payload)
        {
            var id = payload != null ? JsonRead.ReadOptionalString(payload, "id") : null;
            if (string.IsNullOrEmpty(id)) return false;

            TaskCompletionSource<HttpResponseMessage> answer;
            if (!pending.TryRemove(id, out answer)) return false;

            var status = JsonRead.ReadNullableInt32(payload, "status");
            if (!status.HasValue || status.Value < 100 || status.Value > 599)
            {
                answer.TrySetException(new HttpRequestException("Tentacle's answer carried no usable status"));
                return true;
            }

            var body = JsonRead.ReadOptionalString(payload, "body") ?? "";
            answer.TrySetResult(new HttpResponseMessage((HttpStatusCode)status.Value)
            {
                Content = new StringContent(body, Encoding.UTF8, "application/json"),
            });
            return true;
        }

        /// <summary>Fails every call still waiting: its session has ended, so no answer will come.</summary>
        public void FailAll(string reason)
        {
            foreach (var id in pending.Keys)
            {
                TaskCompletionSource<HttpResponseMessage> answer;
                if (pending.TryRemove(id, out answer))
                {
                    answer.TrySetException(new HttpRequestException(
                        "the connection to Tentacle ended before it answered (" + reason + ")"));
                }
            }
        }

        /// <inheritdoc />
        protected override void Dispose(bool disposing)
        {
            if (disposing) FailAll("the client was disposed");
            base.Dispose(disposing);
        }

        private void Forget(string id)
        {
            TaskCompletionSource<HttpResponseMessage> unused;
            pending.TryRemove(id, out unused);
        }

        /// <summary>The <c>input</c> parameter of a query string, decoded, or null.</summary>
        private static string QueryInput(string query)
        {
            if (string.IsNullOrEmpty(query)) return null;
            foreach (var part in query.TrimStart('?').Split('&'))
            {
                if (part.StartsWith("input=", StringComparison.Ordinal))
                {
                    return Uri.UnescapeDataString(part.Substring("input=".Length));
                }
            }
            return null;
        }
    }
}
