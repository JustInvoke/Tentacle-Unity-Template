// Copyright Tentacle. All Rights Reserved.
using System;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // A surface of its own on the entry point rather than on Tentacle_Twitch,
    // because the app computes the subathon stats; no platform provides them. The
    // Unreal plugin keeps its subathon fetches on its deprecated Stream component
    // until the counters work, and reports through completion delegates; the
    // tasks here hand back the whole generated type instead. Left out of the user
    // docs' guides until the counters work.
    /// <summary>
    /// Internal only, and not working yet: the subathon counters behind this
    /// surface are unfinished, so what it answers is not meaningful for your
    /// stream. Do not build on it.
    ///
    /// The subathon stats Tentacle keeps: subscriptions, gifted subscriptions,
    /// and donations since the subathon started, each with goal progress.
    /// Reached as <c>Tentacle.Subathon</c>.
    /// </summary>
    public sealed class Tentacle_Subathon
    {
        private readonly TentacleClient client;

        /// <summary>Creates the subathon surface for a client.</summary>
        internal Tentacle_Subathon(TentacleClient client)
        {
            this.client = client;
        }

        /// <summary>
        /// Internal only, and not working yet: the subathon counters behind this
        /// are unfinished, so what it answers is not meaningful for your stream.
        /// Do not build on it.
        ///
        /// The subathon subscription counter, or null when the request failed.
        /// </summary>
        public Task<SubathonStats_Subscriptions> FetchSubscriptionsAsync(
            CancellationToken cancellationToken = default)
        {
            return FetchAsync(
                (http, token) => http.SubsAsync(null, token),
                "subathonStats.subs",
                SubathonStats_Subscriptions.Parse,
                cancellationToken);
        }

        /// <summary>
        /// Internal only, and not working yet: the subathon counters behind this
        /// are unfinished, so what it answers is not meaningful for your stream.
        /// Do not build on it.
        ///
        /// The subathon gifted-subscription counter, or null when the request
        /// failed.
        /// </summary>
        public Task<SubathonStats_GiftedSubscriptions> FetchGiftedSubscriptionsAsync(
            CancellationToken cancellationToken = default)
        {
            return FetchAsync(
                (http, token) => http.GiftedSubsAsync(null, token),
                "subathonStats.giftedSubs",
                SubathonStats_GiftedSubscriptions.Parse,
                cancellationToken);
        }

        /// <summary>
        /// Internal only, and not working yet: the subathon counters behind this
        /// are unfinished, so what it answers is not meaningful for your stream.
        /// Do not build on it.
        ///
        /// The subathon donation counter in dollars, or null when the request
        /// failed.
        /// </summary>
        public Task<SubathonStats_Donations> FetchDonationsAsync(
            CancellationToken cancellationToken = default)
        {
            return FetchAsync(
                (http, token) => http.DonationsAsync(null, token),
                "subathonStats.donations",
                SubathonStats_Donations.Parse,
                cancellationToken);
        }

        /// <summary>
        /// Runs one subathon query and parses its payload into the counter's
        /// generated type. The three counters differ only in the procedure and
        /// the type, so they share this rather than each unwrapping the envelope.
        /// </summary>
        private async Task<T> FetchAsync<T>(
            Func<TentacleHttpClient, CancellationToken, Task<TentacleHttpResult>> call,
            string procedure,
            Func<JsonValue, T> parse,
            CancellationToken cancellationToken)
            where T : class
        {
            var payload = await client.CallAsync(call, procedure, cancellationToken).ConfigureAwait(false);
            return payload == null ? null : parse(payload);
        }
    }
}
