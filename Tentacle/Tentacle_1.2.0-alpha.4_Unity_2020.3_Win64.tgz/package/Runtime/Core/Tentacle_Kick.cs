// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_Kick, by name and by event. Split in two
    // like Tentacle_Twitch: the generated half
    // (Runtime/Generated/Stream/Tentacle_Kick.PlatformEvents.cs) declares one
    // event per Kick event kind, named after Kick's own reference, and
    // RaisePlatformEvent, held to Unreal's Tentacle_Kick.h by a generator test;
    // this half keeps the calls that address Kick alone. Kick has nothing added
    // by Tentacle, so unlike Twitch it has no Extras, and the client raises its
    // per-kind events straight through RaisePlatformEvent.
    /// <summary>
    /// Kick on its own, in Kick's own words: every Kick stream event, one event
    /// per kind, and the calls that address Kick alone. Reached as
    /// <c>Tentacle.Kick</c>.
    ///
    /// Every Kick event kind has an event of its own, named after the title
    /// Kick's webhook reference gives it, that hands over that kind already
    /// typed: <c>OnChannelFollow</c> with a
    /// <see cref="StreamEvent_Kick_ChannelFollowed"/>, and <c>OnChatMessage</c>
    /// with every chat message, commands included. What Kick shares with Twitch
    /// also has a cross-platform event on the entry point itself, such as
    /// <see cref="TentacleClient.OnFollow"/> for a follow on either platform,
    /// raised right after the Kick event here.
    ///
    /// For one Kick event, the entry point's <see cref="TentacleClient.OnStreamEvent"/>
    /// fires first, then the kind's own event here, then the entry point's
    /// cross-platform event for the kind, if it has one (for a chat message, its
    /// message or command event, then its emoji and emote events).
    ///
    /// Features:
    /// - One event per Kick event kind, typed as that kind, with the viewer the
    ///   event concerns wherever it concerns one
    /// - Kick's own Post Chat Message, as the broadcaster or the bot, replies included
    /// - Handlers run on the thread that pumps the client, each on its own, so one
    ///   that throws stops no other
    /// </summary>
    public sealed partial class Tentacle_Kick
    {
        private readonly TentacleClient client;

        /// <summary>Creates the Kick surface for a client.</summary>
        internal Tentacle_Kick(TentacleClient client)
        {
            this.client = client;
        }

        /// <summary>
        /// Posts a message in the broadcaster's Kick chat: Kick's Post Chat
        /// Message. To send on every connected platform at once, use
        /// <see cref="TentacleClient.SendChatMessage"/> instead.
        ///
        /// Fire-and-forget: a message Kick refuses surfaces in Tentacle's log
        /// rather than here. Validated the way
        /// <see cref="TentacleClient.SendChatMessage"/> validates: empty content,
        /// or content over <see cref="TentacleClient.ChatMessageMaxLength"/>
        /// characters, is refused with a warning rather than posted.
        /// </summary>
        /// <param name="content">The message.</param>
        /// <param name="type">Post as the broadcaster (<c>User</c>) or as the channel's bot (<c>Bot</c>).</param>
        /// <param name="replyToMessageId">
        /// The id of the chat message this one replies to (a Kick chat message's
        /// <c>MessageId</c>), or null for none.
        /// </param>
        public void PostChatMessage(string content, KickChatMessageType type = KickChatMessageType.User, string replyToMessageId = null)
        {
            if (!TentacleClient.IsSendableChatText(content))
            {
                return;
            }

            var members = new List<KeyValuePair<string, JsonValue>>
            {
                JsonValue.Member("content", JsonValue.FromString(content)),
                // Kick's `type` travels as `messageType`, beside the message's own `type`.
                JsonValue.Member("messageType", JsonValue.FromString(type == KickChatMessageType.Bot ? "bot" : "user")),
            };
            if (!string.IsNullOrEmpty(replyToMessageId))
            {
                members.Add(JsonValue.Member("replyToMessageId", JsonValue.FromString(replyToMessageId)));
            }

            client.SendSocketMessage("Kick_PostChatMessage", JsonValue.FromObject(members));
        }

        /// <summary>
        /// Carries one of the generated half's Kick API requests to Tentacle as
        /// the app's <c>kick.*</c> procedure, and reads its response.
        /// </summary>
        private Task<PlatformResponse<T>> RequestAsync<T>(
            string procedure,
            bool isQuery,
            JsonValue input,
            Func<JsonValue, T> parse,
            CancellationToken cancellationToken)
            where T : class
        {
            return client.PlatformRequestAsync(procedure, isQuery, input, parse, cancellationToken);
        }

        /// <summary>Raises a one-argument event, each subscriber on its own.</summary>
        private static void Raise<T>(Action<T> handler, T argument)
        {
            TentacleHandlers.Raise(handler, argument, "stream");
        }

        /// <summary>Raises a two-argument event, each subscriber on its own.</summary>
        private static void Raise<T>(Action<T, Viewer> handler, T argument, Viewer viewer)
        {
            TentacleHandlers.Raise(handler, argument, viewer, "stream");
        }
    }
}
