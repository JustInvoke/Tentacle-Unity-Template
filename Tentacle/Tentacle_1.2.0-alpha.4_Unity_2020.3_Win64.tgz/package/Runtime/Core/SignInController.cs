// Copyright Tentacle. All Rights Reserved.

using System;

namespace Tcl
{
    // Unreal's UTclSignInController, Godot's TclSignInController, and
    // tentacle-web's SignInController. The SignInButton component runs one.
    /// <summary>
    /// The logic of a sign-in button for one platform, with no look of its own,
    /// for a button of your own design: call <see cref="Press"/> when it is
    /// clicked, and show what <see cref="OnStateChanged"/> hands you. Made by
    /// <see cref="Tentacle_Connections.CreateSignInController"/>.
    ///
    /// Pressing does what the label says: Connect signs the player in and opens
    /// the sign-in page, Cancel abandons a sign-in in progress, Disconnect signs
    /// the account out, and Sign in again signs the player in again. It only
    /// opens the page for a sign-in it started. Dispose it when the button goes
    /// away.
    /// </summary>
    public sealed class SignInController : IDisposable
    {
        private readonly Tentacle_Connections connections;
        private readonly bool openBrowser;
        private PlatformConnectionPrompt prompt;
        private double promptDeadline;
        private PlatformConnectionResult result;
        private bool startedHere;
        private bool disposed;

        /// <summary>The platform the controller signs in to.</summary>
        public StreamPlatform Platform { get; private set; }

        /// <summary>What the button should show now.</summary>
        public SignInState State { get; private set; }

        /// <summary>Raised whenever what the button should show changes, the countdown while signing in included.</summary>
        public event Action<SignInState> OnStateChanged;

        /// <summary>How a page is opened; the connections surface's unless a test swaps in its own.</summary>
        internal Action<string> OpenUrl;

        internal SignInController(Tentacle_Connections connections, StreamPlatform platform, bool openBrowser)
        {
            this.connections = connections;
            this.openBrowser = openBrowser;
            Platform = platform;
            State = Describe();
        }

        /// <summary>Does what the label says: sign in, cancel, or disconnect. Does nothing while the state cannot be pressed.</summary>
        public void Press()
        {
            switch (State.Stage)
            {
                case SignInStage.NotConnected:
                case SignInStage.NeedsReconnect:
                    SignIn();
                    break;
                case SignInStage.SigningIn:
                    Cancel();
                    break;
                case SignInStage.Connecting:
                case SignInStage.Connected:
                    Disconnect();
                    break;
            }
        }

        /// <summary>Signs the player in, whatever the stage: for a second "Sign in again" button.</summary>
        public void SignIn()
        {
            if (disposed || !connections.IsEmbedded) return;
            result = null;
            startedHere = true;
            connections.Connect(Platform);
            Refresh();
        }

        /// <summary>Abandons the sign-in in progress.</summary>
        public void Cancel()
        {
            if (disposed || !connections.IsEmbedded) return;
            connections.CancelConnect(Platform);
            Refresh();
        }

        /// <summary>Signs the platform's account out.</summary>
        public void Disconnect()
        {
            if (disposed || !connections.IsEmbedded) return;
            connections.Disconnect(Platform);
            Refresh();
        }

        /// <summary>Opens the sign-in page in progress again, or for the first time when the controller does not open it.</summary>
        public void OpenPage()
        {
            if (prompt == null) return;
            var open = OpenUrl ?? connections.OpenUrl;
            if (open != null) TentacleHandlers.Raise(open, prompt.Url, "sign-in page");
        }

        /// <summary>Stops following the platform. The controller is finished after this.</summary>
        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            connections.Forget(this);
        }

        /// <summary>Works out the state again, and raises <see cref="OnStateChanged"/> when it changed.</summary>
        internal void Refresh()
        {
            if (disposed) return;
            var next = Describe();
            if (next.Equals(State)) return;
            State = next;
            TentacleHandlers.Raise(OnStateChanged, State, "sign-in state");
        }

        internal void HandlePrompt(PlatformConnectionPrompt shown)
        {
            if (shown.Platform != Platform) return;
            // A sign-in someone else started, the game's SignInAsync say, shows
            // here too, but only the controller that asked opens the page.
            prompt = shown;
            promptDeadline = connections.NowSeconds + shown.ExpiresInSeconds;
            result = null;
            if (startedHere && openBrowser) OpenPage();
            Refresh();
        }

        internal void HandleResult(PlatformConnectionResult ended)
        {
            if (ended.Platform != Platform) return;
            prompt = null;
            result = ended;
            startedHere = false;
            Refresh();
        }

        private SignInState Describe()
        {
            double secondsLeft = 0;
            if (prompt != null)
            {
                secondsLeft = promptDeadline - connections.NowSeconds;
                // Ran out here; the core's result says so shortly.
                if (secondsLeft <= 0) prompt = null;
            }
            var note = connections.IsEmbedded ? "" : "Twitch and Kick connect through the Tentacle app";
            return SignInState.Describe(Platform, note, connections.GetConnection(Platform), prompt, secondsLeft, result);
        }
    }
}
