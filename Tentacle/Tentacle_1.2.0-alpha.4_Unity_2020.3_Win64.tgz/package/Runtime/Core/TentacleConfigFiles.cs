// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.IO;

namespace Tcl
{
    // Unreal's FTclConfigFiles and Godot's TclConfigFiles read the same way:
    // every .json file in one folder, in name order, so the files the Tentacle
    // app exports are picked up with no list to keep. Engine-neutral, so it sits
    // in Core and is tested outside play mode.
    /// <summary>Reads the config files an embedded game ships from a folder.</summary>
    internal static class TentacleConfigFiles
    {
        /// <summary>
        /// The text of every <c>.json</c> file in <paramref name="directory"/>,
        /// in name order. Empty when the folder is not there, which is a game
        /// that ships no config. A file that cannot be read is reported and
        /// skipped.
        /// </summary>
        public static IList<string> Read(string directory)
        {
            var texts = new List<string>();
            if (string.IsNullOrEmpty(directory) || !Directory.Exists(directory)) return texts;

            var files = new List<string>();
            foreach (var file in Directory.GetFiles(directory))
            {
                if (string.Equals(Path.GetExtension(file), ".json", StringComparison.OrdinalIgnoreCase)) files.Add(file);
            }
            files.Sort(StringComparer.Ordinal);

            foreach (var file in files)
            {
                try
                {
                    texts.Add(File.ReadAllText(file));
                }
                catch (Exception error) when (error is IOException || error is UnauthorizedAccessException)
                {
                    TentacleLog.Warn("could not read the config file " + file + ": " + error.Message);
                }
            }
            return texts;
        }
    }
}
