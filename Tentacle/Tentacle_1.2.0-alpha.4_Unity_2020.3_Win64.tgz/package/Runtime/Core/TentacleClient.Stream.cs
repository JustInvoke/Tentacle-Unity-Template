// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using Tcl.Json;

namespace Tcl
{
    // The stream half of the client: what the Unreal plugin puts on the ATentacle
    // actor itself under Tentacle|Stream - the catch-all, the chat split, chat
    // joins, the cross-platform events, the chat sends that reach every
    // connected platform, and ChatMessageMaxLength - and the dispatch that fans
    // one stream event out across the client, Tentacle_Twitch and Tentacle_Kick
    // in ATentacle::HandleStreamEvent's order: this OnStreamEvent, the kind's own
    // event on its platform, then the cross-platform event for the kind (for a
    // chat message, ATentacle::DispatchChatMessage's split). De-duplication and
    // the viewer merge happen once, here, before any surface hears the event.
    //
    // The other half (TentacleClient.cs) carries the class's doc comment, so this
    // half's declaration carries none: a partial class documents itself once.
    public sealed partial class TentacleClient
    {
        /// <summary>
        /// Longest chat message either platform accepts, in characters. A longer
        /// one is refused with a warning rather than sent.
        /// </summary>
        public const int ChatMessageMaxLength = 500;

        /// <summary>
        /// Raised for every stream event, whatever its platform or kind, including
        /// kinds this version of the package has no event of its own for. It fires
        /// first, before every other event for the same stream event: the kind's
        /// own event on its platform next (such as <c>Twitch.OnChannelCheer</c>),
        /// then the cross-platform event for the kind here. Each event says which
        /// platform it came from: match <see cref="StreamEvent_Twitch_Base"/> or
        /// <see cref="StreamEvent_Kick_Base"/>, or the kind's own type. The viewer
        /// is the one the event is about, or null for an event about the channel
        /// itself.
        /// </summary>
        public event Action<StreamEventBase, Viewer> OnStreamEvent;

        /// <summary>
        /// Raised when a viewer joins chat. Only Twitch reports joins: Tentacle
        /// checks who is in the Twitch chat every 30 seconds, so a join arrives
        /// up to 30 seconds after it happens, and viewers already in chat when
        /// Tentacle connects to Twitch raise none. The viewer's own
        /// <see cref="Viewer.Twitch"/> and <see cref="Viewer.Kick"/> profiles say
        /// which platforms they are known on.
        /// </summary>
        public event Action<Viewer> OnChatJoin;

        /// <summary>
        /// Raised for a chat message that is not a command, from either platform,
        /// after the platform's own chat message event
        /// (<c>Twitch.OnChannelChatMessage</c> or <c>Kick.OnChatMessage</c>).
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessage;

        /// <summary>
        /// Raised for a chat message the app recognised as a command. A command
        /// does NOT also raise <see cref="OnChatMessage"/>, matching how the app
        /// classifies it.
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatCommand;

        /// <summary>
        /// Raised for a chat message carrying at least one emoji, in addition to
        /// <see cref="OnChatMessage"/> or <see cref="OnChatCommand"/>, and after it.
        /// Count them with <see cref="ChatMessageUtils.GetEmojiCount"/>.
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmojis;

        /// <summary>
        /// Raised for a chat message carrying at least one emote, in addition to
        /// <see cref="OnChatMessage"/> or <see cref="OnChatCommand"/>, and after
        /// the emoji event. Count them with <see cref="ChatMessageUtils.GetEmoteCount"/>.
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmotes;

        /// <summary>Raised when a viewer is banned or timed out, on either platform.</summary>
        public event Action<StreamEvent_Anywhere_Ban, Viewer> OnBan;

        /// <summary>
        /// Raised when the channel's title, category, or similar changes. Carries
        /// no viewer: the event describes the channel, not a person.
        /// </summary>
        public event Action<StreamEvent_Anywhere_ChannelUpdate> OnChannelUpdate;

        /// <summary>
        /// Raised when a viewer cheers bits on Twitch. Kick has no donation event,
        /// so this is never raised for Kick.
        /// </summary>
        public event Action<StreamEvent_Anywhere_Donation, Viewer> OnDonation;

        /// <summary>Raised on a new follow, on either platform.</summary>
        public event Action<StreamEvent_Anywhere_Follow, Viewer> OnFollow;

        /// <summary>Raised on a channel-points or reward redemption, on either platform.</summary>
        public event Action<StreamEvent_Anywhere_Redemption, Viewer> OnRedemption;

        /// <summary>Raised on a first-time subscription, on either platform.</summary>
        public event Action<StreamEvent_Anywhere_Subscription, Viewer> OnSubscription;

        /// <summary>Raised on gifted subscriptions, on either platform.</summary>
        public event Action<StreamEvent_Anywhere_SubscriptionGift, Viewer> OnSubscriptionGift;

        /// <summary>Raised when an existing subscription is renewed or resubscribed, on either platform.</summary>
        public event Action<StreamEvent_Anywhere_SubscriptionRenewal, Viewer> OnSubscriptionRenewal;

        /// <summary>
        /// Sends a chat message to every connected platform. Fire-and-forget:
        /// Tentacle acknowledges nothing, so there is no completion to await.
        /// <c>Twitch.SendChatMessage</c> and <c>Kick.PostChatMessage</c> send on
        /// one platform alone, with that platform's own options.
        ///
        /// Validation happens here rather than on the far side of the socket,
        /// because a warning in the Unity console is visible to whoever wrote the
        /// call and a rejection inside Tentacle is not: an empty message, or one
        /// over <see cref="ChatMessageMaxLength"/> characters, is refused.
        /// <c>isBot</c> sends as the bot identity where the platform supports one
        /// (Kick).
        /// </summary>
        public void SendChatMessage(string message, bool isBot = false)
        {
            SendChatMessageInternal(message, isBot, null);
        }

        /// <summary>
        /// Sends a chat message addressed to one viewer on every connected
        /// platform. Validated as <see cref="SendChatMessage"/> is, and refused
        /// for a null viewer.
        /// </summary>
        public void SendChatMessageToViewer(Viewer viewer, string message, bool isBot = false)
        {
            if (viewer == null || string.IsNullOrEmpty(viewer.ViewerId))
            {
                TentacleLog.Warn("Tentacle: not sending a chat message to a null viewer");
                return;
            }
            SendChatMessageInternal(message, isBot, viewer.ViewerId);
        }

        /// <summary>
        /// Whether a chat message's text is one every platform accepts, warning
        /// when it is not. Every chat send, the platforms' own included, checks
        /// through here, so they all refuse the same text the same way.
        /// </summary>
        internal static bool IsSendableChatText(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                TentacleLog.Warn("Tentacle: not sending an empty chat message");
                return false;
            }
            if (text.Length > ChatMessageMaxLength)
            {
                TentacleLog.Warn(
                    "Tentacle: not sending a chat message of " + text.Length
                    + " characters; the limit is " + ChatMessageMaxLength);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Builds and sends the message. The viewer id is an internal parameter
        /// rather than a public overload, so there is one public way to address a
        /// viewer and it is the one that checks the viewer.
        /// </summary>
        private void SendChatMessageInternal(string message, bool isBot, string viewerId)
        {
            if (!IsSendableChatText(message))
            {
                return;
            }

            var members = new List<KeyValuePair<string, JsonValue>>
            {
                JsonValue.Member("message", JsonValue.FromString(message)),
                JsonValue.Member("isBot", JsonValue.FromBool(isBot)),
            };

            // Absent fields carry meaning: no platform means every connected one,
            // and no viewerId means the message is addressed to nobody.
            if (!string.IsNullOrEmpty(viewerId))
            {
                members.Add(JsonValue.Member("viewerId", JsonValue.FromString(viewerId)));
            }

            SendSocketMessage("Stream_SendChatMessage", JsonValue.FromObject(members));
        }

        // ATentacle::HandleChatJoin: a join is Tentacle's own event, not a
        // platform's, so it is raised here alone, and a join that names no viewer
        // raises nothing. The viewer's own profiles say which platform they are on.
        /// <summary>Handles the payload of an inbound <c>Stream_ChatJoin</c>.</summary>
        internal void HandleChatJoin(JsonValue payload)
        {
            if (payload == null) return;

            var viewerJson = payload["viewer"];
            if (viewerJson == null || viewerJson.Kind != JsonKind.Object) return;

            var data = ViewerData.Parse(viewerJson);
            if (data == null) return;
            var viewer = Viewers.UpsertViewer(data);

            RaiseStream(OnChatJoin, viewer);
        }

        /// <summary>
        /// Handles the payload of an inbound <c>Stream_Event</c>: de-duplicate,
        /// refresh the viewer, then fan out from the catch-all to the kind's own
        /// event on its platform and on to the cross-platform view.
        /// </summary>
        internal void HandleStreamEvent(JsonValue payload)
        {
            if (payload == null) return;

            var streamEvent = StreamEventBase.Parse(payload["event"]);
            if (streamEvent == null) return;

            // Once, before any surface: a duplicate reaches none of them.
            if (!streamDeduplicator.TryAdd(streamEvent.Id)) return;

            // The viewer is only merged once the event survived de-duplication:
            // a duplicate carries a viewer snapshot from when the event happened,
            // which can be older than what the cache already holds.
            var viewer = Viewers.UpsertViewer(payload["viewer"]);

            RaiseStream(OnStreamEvent, streamEvent, viewer);

            // The platform surface raises the kind's own event (the Twitch one
            // opening its incoming raid window first, for a raid).
            bool known;
            var twitchEvent = streamEvent as StreamEvent_Twitch_Base;
            var kickEvent = streamEvent as StreamEvent_Kick_Base;
            if (twitchEvent != null) known = Twitch.Dispatch(twitchEvent, viewer);
            else if (kickEvent != null) known = Kick.RaisePlatformEvent(kickEvent, viewer);
            else known = false;

            // A kind with no event of its own is one this version predates, and it
            // has no cross-platform view here either: the catch-all was its whole
            // delivery, as on Unreal.
            if (!known) return;

            DispatchCrossPlatform(TentacleAnywhereView.For(streamEvent), viewer);
        }

        /// <summary>
        /// Raises the cross-platform event matching a stream event's
        /// cross-platform view, or nothing when its kind has none.
        /// </summary>
        private void DispatchCrossPlatform(StreamEventAnywhereBase crossPlatform, Viewer viewer)
        {
            if (crossPlatform == null) return;

            var chat = crossPlatform as StreamEvent_Anywhere_ChatMessage;
            if (chat != null) { DispatchChatMessage(chat, viewer); return; }

            var ban = crossPlatform as StreamEvent_Anywhere_Ban;
            if (ban != null) { RaiseStream(OnBan, ban, viewer); return; }

            var channelUpdate = crossPlatform as StreamEvent_Anywhere_ChannelUpdate;
            if (channelUpdate != null) { RaiseStream(OnChannelUpdate, channelUpdate); return; }

            var donation = crossPlatform as StreamEvent_Anywhere_Donation;
            if (donation != null) { RaiseStream(OnDonation, donation, viewer); return; }

            var follow = crossPlatform as StreamEvent_Anywhere_Follow;
            if (follow != null) { RaiseStream(OnFollow, follow, viewer); return; }

            var redemption = crossPlatform as StreamEvent_Anywhere_Redemption;
            if (redemption != null) { RaiseStream(OnRedemption, redemption, viewer); return; }

            var renewal = crossPlatform as StreamEvent_Anywhere_SubscriptionRenewal;
            if (renewal != null) { RaiseStream(OnSubscriptionRenewal, renewal, viewer); return; }

            var gift = crossPlatform as StreamEvent_Anywhere_SubscriptionGift;
            if (gift != null) { RaiseStream(OnSubscriptionGift, gift, viewer); return; }

            var subscription = crossPlatform as StreamEvent_Anywhere_Subscription;
            if (subscription != null) RaiseStream(OnSubscription, subscription, viewer);
        }

        // ATentacle::DispatchChatMessage, in its order.
        /// <summary>
        /// Splits one chat message across the cross-platform chat events: command
        /// or message first, then the emoji and emote events for whichever the
        /// message carries.
        /// </summary>
        private void DispatchChatMessage(StreamEvent_Anywhere_ChatMessage chat, Viewer viewer)
        {
            // The app decides what is a command by normalising the message; a
            // command is not also delivered as an ordinary chat message.
            if (!string.IsNullOrEmpty(chat.Command)) RaiseStream(OnChatCommand, chat, viewer);
            else RaiseStream(OnChatMessage, chat, viewer);

            if (chat.HasEmojis()) RaiseStream(OnChatMessageWithEmojis, chat, viewer);
            if (chat.HasEmotes()) RaiseStream(OnChatMessageWithEmotes, chat, viewer);
        }

        /// <summary>Raises a one-argument stream event, each subscriber on its own.</summary>
        private static void RaiseStream<T>(Action<T> handler, T argument)
        {
            TentacleHandlers.Raise(handler, argument, "stream");
        }

        /// <summary>Raises a two-argument stream event, each subscriber on its own.</summary>
        private static void RaiseStream<T>(Action<T, Viewer> handler, T argument, Viewer viewer)
        {
            TentacleHandlers.Raise(handler, argument, viewer, "stream");
        }
    }
}
