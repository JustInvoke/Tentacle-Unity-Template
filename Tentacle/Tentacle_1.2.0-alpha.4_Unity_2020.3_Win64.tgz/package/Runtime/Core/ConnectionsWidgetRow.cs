// Copyright Tentacle. All Rights Reserved.

using System;

namespace Tcl
{
    /// <summary>What a <see cref="ConnectionsWidgetRow"/> button does when pressed.</summary>
    internal enum ConnectionsWidgetAction
    {
        None,
        Connect,
        Disconnect,
        OpenPage,
        Cancel,
    }

    // Unreal's FTclConnectionsWidgetRow and Godot's TclConnectionsWidgetRow, with the
    // same rules and the same words, so a player sees the same sign-in on every
    // engine. Internal: the widget is the surface, and a game wanting its own
    // sign-in screen uses Tentacle_Connections directly.
    /// <summary>
    /// What one platform's row in a <c>ConnectionsWidget</c> shows: its status, a
    /// line of detail, and its buttons, worked out from what
    /// <see cref="Tentacle_Connections"/> last reported.
    /// </summary>
    internal sealed class ConnectionsWidgetRow
    {
        public string Title = "";
        public string Status = "";
        public string Detail = "";
        public ConnectionsWidgetAction PrimaryAction = ConnectionsWidgetAction.None;
        public string PrimaryLabel = "";
        public ConnectionsWidgetAction SecondaryAction = ConnectionsWidgetAction.None;
        public string SecondaryLabel = "";

        /// <summary>
        /// The row for <paramref name="platform"/>, given its connection (null
        /// before Tentacle has reported one), the sign-in prompt in progress
        /// (null for none) with <paramref name="secondsLeft"/> on it, the result
        /// of the last sign-in (null for none), and whether the widget opens the
        /// sign-in page by itself.
        /// </summary>
        public static ConnectionsWidgetRow Describe(
            StreamPlatform platform,
            PlatformConnection connection,
            PlatformConnectionPrompt prompt,
            double secondsLeft,
            PlatformConnectionResult result,
            bool openBrowserAutomatically)
        {
            var row = new ConnectionsWidgetRow { Title = PlatformName(platform) };

            if (prompt != null && secondsLeft > 0)
            {
                row.Status = "Finish signing in in your browser";
                var left = FormatTimeLeft(secondsLeft);
                row.Detail = string.IsNullOrEmpty(prompt.UserCode)
                    ? "Expires in " + left
                    : "Code " + prompt.UserCode + " · expires in " + left;
                row.PrimaryAction = ConnectionsWidgetAction.OpenPage;
                row.PrimaryLabel = openBrowserAutomatically ? "Open the page again" : "Open the sign-in page";
                row.SecondaryAction = ConnectionsWidgetAction.Cancel;
                row.SecondaryLabel = "Cancel";
                return row;
            }

            row.Detail = ResultDetail(result);
            if (connection == null)
            {
                row.Status = "Waiting for Tentacle";
                return row;
            }

            var account = connection.Account;
            if (account != null && connection.NeedsReconnect)
            {
                row.Status = account.DisplayName + " needs to sign in again";
                row.PrimaryAction = ConnectionsWidgetAction.Connect;
                row.PrimaryLabel = "Sign in again";
            }
            else if (account != null)
            {
                row.Status = connection.Status == PlatformConnectionStatus.Connected
                    ? "Connected as " + account.DisplayName
                    : "Connecting as " + account.DisplayName + "...";
                row.PrimaryAction = ConnectionsWidgetAction.Disconnect;
                row.PrimaryLabel = "Disconnect";
                // It signed in before this version asked for more: it still works,
                // and signing in again grants the rest.
                if (connection.MissingPermissions)
                {
                    if (string.IsNullOrEmpty(row.Detail)) row.Detail = "Sign in again to allow newer features";
                    row.SecondaryAction = ConnectionsWidgetAction.Connect;
                    row.SecondaryLabel = "Sign in again";
                }
            }
            else
            {
                row.Status = "Not connected";
                row.PrimaryAction = ConnectionsWidgetAction.Connect;
                row.PrimaryLabel = "Connect";
            }
            return row;
        }

        /// <summary>The platform's name as a player knows it.</summary>
        public static string PlatformName(StreamPlatform platform)
        {
            return platform == StreamPlatform.Kick ? "Kick" : "Twitch";
        }

        /// <summary><paramref name="seconds"/> as minutes and seconds, rounded up: <c>4:05</c>.</summary>
        public static string FormatTimeLeft(double seconds)
        {
            var whole = (int)Math.Ceiling(seconds);
            return (whole / 60) + ":" + (whole % 60).ToString("00");
        }

        /// <summary>
        /// Why the last sign-in did not connect, or empty when it did, was
        /// cancelled, or there was none.
        /// </summary>
        public static string ResultDetail(PlatformConnectionResult result)
        {
            if (result == null) return "";
            switch (result.Outcome)
            {
                case PlatformConnectionOutcome.Denied:
                    return "Sign-in was declined";
                case PlatformConnectionOutcome.Expired:
                    return "Sign-in ran out of time";
                case PlatformConnectionOutcome.Error:
                    return string.IsNullOrEmpty(result.Message) ? "Sign-in failed" : "Sign-in failed: " + result.Message;
                default:
                    return "";
            }
        }
    }
}
