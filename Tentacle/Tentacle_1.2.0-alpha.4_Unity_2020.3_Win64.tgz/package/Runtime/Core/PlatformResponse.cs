// Copyright Tentacle. All Rights Reserved.
namespace Tcl
{
    // The Unreal plugin's async action nodes split this into On Success, with
    // the response, and On Failure, with the status and message; a Task hands
    // both back in one value instead, and never faults, per the remote-calls
    // rule.
    /// <summary>
    /// What a Twitch or Kick API request came to: the platform's response, or why
    /// there is none. Never thrown: a request that failed, because the platform
    /// is not connected, refused it, or could not be reached, or because
    /// Tentacle is not running, is a response with <see cref="IsSuccess"/> false.
    /// <c>T</c> is the endpoint's response body.
    /// </summary>
    public sealed class PlatformResponse<T> where T : class
    {
        /// <summary>True when the platform responded to the request.</summary>
        public bool IsSuccess { get; }

        /// <summary>
        /// The platform's response, as its reference describes it, or null when the
        /// request failed or the endpoint responds with no body.
        /// </summary>
        public T Value { get; }

        /// <summary>
        /// The HTTP status Tentacle responded with: 200 on success, 400 for an
        /// input Tentacle refused or a platform that is not connected, 502 for a
        /// request the platform refused or did not respond to, and 0 when Tentacle
        /// itself was not reached.
        /// </summary>
        public int StatusCode { get; }

        /// <summary>Why the request failed, safe to show a user; null on success.</summary>
        public string ErrorMessage { get; }

        internal PlatformResponse(bool isSuccess, T value, int statusCode, string errorMessage)
        {
            IsSuccess = isSuccess;
            Value = value;
            StatusCode = statusCode;
            ErrorMessage = errorMessage;
        }
    }
}
