// Copyright Tentacle. All Rights Reserved.
using System.Collections.Generic;
using System.Globalization;
using System.Text;

namespace Tcl
{
    // The counterpart of the Unreal plugin's UTclChatMessageUtils, with the same
    // semantics, down to a null message counting as zero, which matches the
    // Unreal implementation's IsValid guard.
    /// <summary>
    /// Counting emojis and emotes on a chat message, turning an emoji into its
    /// code points, naming its image file in the open emoji image sets, and
    /// reading the roles a Twitch chat message's badges stand for.
    ///
    /// Lookups run against the cross-platform
    /// <see cref="StreamEvent_Anywhere_ChatMessage"/> view, they match on the
    /// dictionary key rather than the entry's own name, and they are
    /// case-insensitive unless asked otherwise.
    ///
    /// Written as extension methods, so a game calls
    /// <c>message.GetEmoteCount("Kappa")</c> rather than naming this class.
    ///
    /// Features:
    /// - Null-safe throughout: a null message counts as zero
    /// - Code-point extraction handles UTF-16 surrogate pairs, so a multi-byte
    ///   emoji yields one code point rather than two halves
    /// - Multi-code-point emoji (ZWJ sequences, skin-tone modifiers) yield every
    ///   code point in order, which is what an emoji CDN filename needs
    /// </summary>
    public static class ChatMessageUtils
    {
        /// <summary>
        /// How many times one emoji appears, by exact name. Zero when the message
        /// does not carry it.
        ///
        /// The plain name (<c>thumbs_up</c>) counts every skin tone of that emoji,
        /// and so does any of its aliases (<c>+1</c>); a tone-qualified key
        /// (<c>thumbs_up-light</c>) counts just that one tone.
        /// </summary>
        public static int GetEmojiCount(
            this StreamEvent_Anywhere_ChatMessage message, string name, bool caseSensitive = false)
        {
            if (message == null || message.Emojis == null) return 0;
            // Matching the key counts one tone; matching the name or an alias
            // covers every tone of the emoji.
            var total = 0;
            foreach (var pair in message.Emojis)
            {
                if (pair.Value == null) continue;
                if (Matches(pair.Key, name, caseSensitive)
                    || Matches(pair.Value.Name, name, caseSensitive)
                    || MatchesAny(pair.Value.Aliases, name, caseSensitive))
                {
                    total += pair.Value.Count;
                }
            }
            return total;
        }

        /// <summary>
        /// How many times one emote appears, by exact name. Zero when the message
        /// does not carry it.
        /// </summary>
        public static int GetEmoteCount(
            this StreamEvent_Anywhere_ChatMessage message, string name, bool caseSensitive = false)
        {
            if (message == null || message.Emotes == null) return 0;
            foreach (var pair in message.Emotes)
            {
                if (pair.Value != null && Matches(pair.Key, name, caseSensitive)) return pair.Value.Count;
            }
            return 0;
        }

        /// <summary>Total count of every emoji whose name contains a substring.</summary>
        public static int GetEmojiCountContaining(
            this StreamEvent_Anywhere_ChatMessage message, string substring, bool caseSensitive = false)
        {
            if (message == null || message.Emojis == null) return 0;
            var total = 0;
            foreach (var pair in message.Emojis)
            {
                if (pair.Value != null && Contains(pair.Key, substring, caseSensitive)) total += pair.Value.Count;
            }
            return total;
        }

        /// <summary>Total count of every emote whose name contains a substring.</summary>
        public static int GetEmoteCountContaining(
            this StreamEvent_Anywhere_ChatMessage message, string substring, bool caseSensitive = false)
        {
            if (message == null || message.Emotes == null) return 0;
            var total = 0;
            foreach (var pair in message.Emotes)
            {
                if (pair.Value != null && Contains(pair.Key, substring, caseSensitive)) total += pair.Value.Count;
            }
            return total;
        }

        /// <summary>True when the message carries at least one emoji.</summary>
        public static bool HasEmojis(this StreamEvent_Anywhere_ChatMessage message)
        {
            return message != null && message.Emojis != null && message.Emojis.Count > 0;
        }

        /// <summary>True when the message carries at least one emote.</summary>
        public static bool HasEmotes(this StreamEvent_Anywhere_ChatMessage message)
        {
            return message != null && message.Emotes != null && message.Emotes.Count > 0;
        }

        /// <summary>
        /// Whether a Twitch chat message wears a badge of this set, such as
        /// <c>bits</c>. Ignores case unless asked not to. False for a null message.
        /// </summary>
        public static bool HasBadge_Twitch(
            this StreamEvent_Twitch_ChatMessage message, string setId, bool caseSensitive = false)
        {
            return message != null && TentacleBadges.AnyTwitch(message.Badges, new[] { setId }, caseSensitive);
        }

        /// <summary>Whether a Twitch chat message is the broadcaster's.</summary>
        public static bool IsBroadcaster_Twitch(this StreamEvent_Twitch_ChatMessage message)
        {
            return message != null && TentacleBadges.AnyTwitch(message.Badges, TentacleBadges.TwitchBroadcaster);
        }

        /// <summary>Whether a Twitch chat message is a moderator's, Lead Moderators included.</summary>
        public static bool IsModerator_Twitch(this StreamEvent_Twitch_ChatMessage message)
        {
            return message != null && TentacleBadges.AnyTwitch(message.Badges, TentacleBadges.TwitchModerator);
        }

        /// <summary>Whether a Twitch chat message is a VIP's.</summary>
        public static bool IsVip_Twitch(this StreamEvent_Twitch_ChatMessage message)
        {
            return message != null && TentacleBadges.AnyTwitch(message.Badges, TentacleBadges.TwitchVip);
        }

        /// <summary>Whether a Twitch chat message wears the subscriber or founder badge.</summary>
        public static bool IsSubscriber_Twitch(this StreamEvent_Twitch_ChatMessage message)
        {
            return message != null && TentacleBadges.AnyTwitch(message.Badges, TentacleBadges.TwitchSubscriber);
        }

        /// <summary>
        /// The Unicode code points of an emoji, formatted <c>"U+1F600"</c>:
        /// uppercase hex, at least four digits, with the <c>U+</c> prefix. Empty
        /// for null or empty input.
        /// </summary>
        public static List<string> GetEmojiCodePoints(string emoji)
        {
            var result = new List<string>();
            foreach (var codePoint in CodePointsOf(emoji))
            {
                result.Add("U+" + codePoint.ToString("X4", CultureInfo.InvariantCulture));
            }
            return result;
        }

        /// <summary>
        /// The Unicode code points of an emoji, formatted <c>"1f600"</c>:
        /// lowercase hex, at least four digits, no prefix. Empty for null or empty
        /// input. To name an emoji's image file, use
        /// <see cref="GetEmojiImageFileName"/>, which follows each image set's own
        /// naming rules.
        /// </summary>
        public static List<string> GetEmojiHexValues(string emoji)
        {
            var result = new List<string>();
            foreach (var codePoint in CodePointsOf(emoji))
            {
                result.Add(codePoint.ToString("x4", CultureInfo.InvariantCulture));
            }
            return result;
        }

        // The same rules as tentacle-web's src/emoji.ts and the Unreal and Godot
        // plugins, held together by the same table of cases in each one's tests.

        /// <summary>VARIATION SELECTOR-16, which asks for the colour emoji rather than the text glyph.</summary>
        private const int VariationSelector = 0xFE0F;

        /// <summary>ZERO WIDTH JOINER, which welds several emoji into one.</summary>
        private const int ZeroWidthJoiner = 0x200D;

        /// <summary>The first regional indicator letter, A, which country flags are spelled with.</summary>
        private const int RegionalIndicatorA = 0x1F1E6;

        /// <summary>The last regional indicator letter, Z.</summary>
        private const int RegionalIndicatorZ = 0x1F1FF;

        /// <summary>WAVING BLACK FLAG, the base of a subdivision flag such as England's.</summary>
        private const int BlackFlag = 0x1F3F4;

        /// <summary>CANCEL TAG, which ends the tag letters a subdivision flag is spelled with.</summary>
        private const int CancelTag = 0xE007F;

        /// <summary>How far a tag character sits above the ASCII character it stands for.</summary>
        private const int TagOffset = 0xE0000;

        // Twemoji files one emoji against its own rule: eye in speech bubble keeps
        // no variation selector even though it has a joiner. It is the only one in
        // Emoji 18.0, checked against every file Twemoji v17.0.3 ships.
        private static readonly int[] TwemojiEyeInSpeechBubble = { 0x1F441, 0xFE0F, 0x200D, 0x1F5E8, 0xFE0F };

        // The folder each set's PNG images are in, pinned to a release so the
        // address cannot move under a game. Noto's are Google's own Noto CDN, by
        // emoji version, where flags are drawn as emoji at every size; the others
        // are the set's GitHub release on jsDelivr. tentacle-web's
        // tests/emoji-urls.test.ts requests real images from each, at every size,
        // and fails when these differ from its own.
        private const string NotoFolder = "https://fonts.gstatic.com/s/e/notoemoji/18.0/";
        private const string TwemojiFolder = "https://cdn.jsdelivr.net/gh/jdecked/twemoji@v17.0.3/assets/";
        private const string OpenMojiFolder = "https://cdn.jsdelivr.net/gh/hfg-gmuend/openmoji@17.0.0/color/";

        // The sizes, in pixels, each set ships its PNG images in, smallest first.
        private static readonly int[] NotoSizes = { 32, 72, 128, 512 };
        private static readonly int[] TwemojiSizes = { 72 };
        private static readonly int[] OpenMojiSizes = { 72, 618 };

        /// <summary>
        /// The address of an emoji's PNG image in one of the open emoji image
        /// sets.
        ///
        /// <paramref name="size"/> asks for an image at least that many pixels
        /// across: the address is for the smallest size the set ships that is as
        /// big, or its largest when none is. Noto ships 32, 72, 128, and 512
        /// pixels, Twemoji 72, and OpenMoji 72 and 618.
        ///
        /// Noto's images come from Google's own Noto CDN, the rest from the set's
        /// release on jsDelivr. Each address names a release of the set, so it
        /// does not move. A set may not have drawn the newest emoji yet, so treat
        /// an image that fails to download as normal. Empty for a null emoji, or
        /// one with no code points.
        /// </summary>
        public static string GetEmojiImageUrl(this ChatMessageEmoji emoji, EmojiImageSet imageSet, int size = 512)
        {
            if (emoji == null) return "";
            var values = ParseCodePoints(emoji.CodePoints);
            if (values == null) return "";

            switch (imageSet)
            {
                case EmojiImageSet.Noto:
                    var pixels = ImageSizeFor(NotoSizes, size).ToString(CultureInfo.InvariantCulture);
                    return NotoFolder + NotoSequenceName(values) + "/" + pixels + ".png";
                case EmojiImageSet.Twemoji:
                    return TwemojiFolder + SizeFolder(ImageSizeFor(TwemojiSizes, size)) + TwemojiFileName(values);
                case EmojiImageSet.OpenMoji:
                    return OpenMojiFolder + SizeFolder(ImageSizeFor(OpenMojiSizes, size)) + OpenMojiFileName(values);
                default:
                    return "";
            }
        }

        /// <summary>The smallest of a set's sizes that is at least <paramref name="size"/> pixels, or its largest when none is.</summary>
        private static int ImageSizeFor(int[] sizes, int size)
        {
            foreach (var available in sizes)
            {
                if (available >= size) return available;
            }
            return sizes[sizes.Length - 1];
        }

        /// <summary>A square size's folder, as Twemoji and OpenMoji name them: <c>72x72/</c>.</summary>
        private static string SizeFolder(int pixels)
        {
            var side = pixels.ToString(CultureInfo.InvariantCulture);
            return side + "x" + side + "/";
        }

        /// <summary>
        /// The file name of an emoji's PNG image in a copy of one of the open
        /// emoji image sets you ship or host yourself: <c>emoji_u2764.png</c> in
        /// Noto's own download, <c>2764.png</c> in Twemoji and OpenMoji.
        ///
        /// Each set names its files its own way, down to how it treats the
        /// invisible variation selector, so the name comes from here rather than
        /// from the code points joined together. Noto's download names flags by
        /// region code (<c>US.png</c>, <c>GB-ENG.png</c>) and keeps them in a
        /// folder of their own. To load an image straight from the set, use
        /// <see cref="GetEmojiImageUrl"/>. Empty for a null emoji, or one with no
        /// code points.
        /// </summary>
        public static string GetEmojiImageFileName(this ChatMessageEmoji emoji, EmojiImageSet imageSet)
        {
            if (emoji == null) return "";
            var values = ParseCodePoints(emoji.CodePoints);
            if (values == null) return "";

            switch (imageSet)
            {
                case EmojiImageSet.Noto:
                    return NotoFileName(values);
                case EmojiImageSet.Twemoji:
                    return TwemojiFileName(values);
                case EmojiImageSet.OpenMoji:
                    return OpenMojiFileName(values);
                default:
                    return "";
            }
        }

        /// <summary>
        /// Reads hex code points into their values. Null when there are none, or
        /// one is not written in hex.
        /// </summary>
        private static List<int> ParseCodePoints(List<string> codePoints)
        {
            if (codePoints == null || codePoints.Count == 0) return null;
            var values = new List<int>();
            foreach (var codePoint in codePoints)
            {
                if (string.IsNullOrEmpty(codePoint) || codePoint.Length > 6) return null;
                if (!int.TryParse(codePoint, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out var value))
                {
                    return null;
                }
                values.Add(value);
            }
            return values;
        }

        /// <summary>The two letters a country flag spells (<c>"US"</c>), or null when the emoji is not one.</summary>
        private static string CountryFlagLetters(List<int> values)
        {
            if (values.Count != 2) return null;
            var letters = new StringBuilder();
            foreach (var value in values)
            {
                if (value < RegionalIndicatorA || value > RegionalIndicatorZ) return null;
                letters.Append((char)('A' + (value - RegionalIndicatorA)));
            }
            return letters.ToString();
        }

        /// <summary>
        /// The region and subdivision a subdivision flag spells
        /// (<c>"GB-ENG"</c>), or null when the emoji is not one.
        /// </summary>
        private static string SubdivisionFlagCode(List<int> values)
        {
            if (values.Count < 3 || values[0] != BlackFlag || values[values.Count - 1] != CancelTag) return null;
            var letters = new StringBuilder();
            for (var index = 1; index < values.Count - 1; index++)
            {
                letters.Append((char)(values[index] - TagOffset));
            }
            var code = letters.ToString().ToUpperInvariant();
            return code.Substring(0, System.Math.Min(2, code.Length)) + "-" + code.Substring(System.Math.Min(2, code.Length));
        }

        /// <summary>
        /// How Noto names an emoji: its code points in lowercase, joined with
        /// underscores, with every variation selector dropped
        /// (<c>2764_200d_1f525</c>).
        /// </summary>
        private static string NotoSequenceName(List<int> values)
        {
            var parts = new List<string>();
            foreach (var value in values)
            {
                if (value != VariationSelector) parts.Add(value.ToString("x4", CultureInfo.InvariantCulture));
            }
            return string.Join("_", parts);
        }

        /// <summary>
        /// The name of a file in Noto's own download: <c>emoji_u</c> and the
        /// emoji's Noto name. Flags are the exception: the download keeps them
        /// apart, named by region code.
        /// </summary>
        private static string NotoFileName(List<int> values)
        {
            var flag = CountryFlagLetters(values) ?? SubdivisionFlagCode(values);
            if (flag != null) return flag + ".png";
            return "emoji_u" + NotoSequenceName(values) + ".png";
        }

        /// <summary>
        /// Twemoji's name: the code points in lowercase without leading zeros,
        /// joined with hyphens, with the variation selector dropped unless the
        /// emoji has a joiner.
        /// </summary>
        private static string TwemojiFileName(List<int> values)
        {
            var isException = values.Count == TwemojiEyeInSpeechBubble.Length;
            for (var index = 0; isException && index < values.Count; index++)
            {
                isException = values[index] == TwemojiEyeInSpeechBubble[index];
            }
            var keepSelector = values.Contains(ZeroWidthJoiner) && !isException;

            var parts = new List<string>();
            foreach (var value in values)
            {
                if (keepSelector || value != VariationSelector) parts.Add(value.ToString("x", CultureInfo.InvariantCulture));
            }
            return string.Join("-", parts) + ".png";
        }

        /// <summary>
        /// OpenMoji's name: the code points in uppercase, joined with hyphens,
        /// with the variation selector dropped only from an emoji that is one
        /// character and the selector.
        /// </summary>
        private static string OpenMojiFileName(List<int> values)
        {
            var kept = values.Count == 2 && values[1] == VariationSelector ? 1 : values.Count;
            var parts = new List<string>();
            for (var index = 0; index < kept; index++)
            {
                parts.Add(values[index].ToString("X4", CultureInfo.InvariantCulture));
            }
            return string.Join("-", parts) + ".png";
        }

        /// <summary>
        /// Walks a UTF-16 string and yields each Unicode code point, combining a
        /// surrogate pair into the single code point it encodes.
        ///
        /// An unpaired surrogate is yielded as itself rather than dropped: it is
        /// malformed input, and losing it silently would make the result look
        /// like a shorter, valid emoji.
        /// </summary>
        private static List<int> CodePointsOf(string text)
        {
            var result = new List<int>();
            if (string.IsNullOrEmpty(text)) return result;

            for (var index = 0; index < text.Length; )
            {
                int codePoint = text[index];
                if (char.IsHighSurrogate(text[index])
                    && index + 1 < text.Length
                    && char.IsLowSurrogate(text[index + 1]))
                {
                    codePoint = char.ConvertToUtf32(text[index], text[index + 1]);
                    index += 2;
                }
                else
                {
                    index += 1;
                }
                result.Add(codePoint);
            }
            return result;
        }

        /// <summary>Compares two names under the caller's case rule.</summary>
        private static bool Matches(string key, string name, bool caseSensitive)
        {
            return string.Equals(
                key,
                name,
                caseSensitive ? System.StringComparison.Ordinal : System.StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>Whether any of an emoji's other names matches.</summary>
        private static bool MatchesAny(List<string> names, string name, bool caseSensitive)
        {
            if (names == null) return false;
            foreach (var candidate in names)
            {
                if (Matches(candidate, name, caseSensitive)) return true;
            }
            return false;
        }

        /// <summary>Substring test under the caller's case rule.</summary>
        private static bool Contains(string key, string substring, bool caseSensitive)
        {
            if (key == null || substring == null) return false;
            return key.IndexOf(
                substring,
                caseSensitive ? System.StringComparison.Ordinal : System.StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
