// Copyright Tentacle. All Rights Reserved.
using System;

namespace Tcl
{
    // The Unreal plugin's UTentacle_TwitchExtras, by name and by member. It keeps
    // what Tentacle derives rather than receives from Twitch apart from
    // Tentacle_Twitch, so that everything directly on the Twitch surface is named
    // after Twitch's own reference. The Twitch surface opens the window as it
    // dispatches a raid (Tentacle_Twitch.Dispatch), as UTentacle_Twitch does.
    /// <summary>
    /// What Tentacle adds to Twitch: things Twitch itself does not have, kept
    /// apart so that everything directly on <c>Tentacle.Twitch</c> is a Twitch
    /// event or call you can look up in Twitch's own documentation. Reached as
    /// <c>Tentacle.Twitch.Extras</c>.
    ///
    /// Today that is the incoming raid window. Twitch reports a raid on your
    /// channel (<c>Tentacle.Twitch.OnChannelRaid</c>) but never reports it over,
    /// so the window stays open from the raid until your game closes it with
    /// <see cref="EndIncomingRaid"/>.
    /// </summary>
    public sealed class Tentacle_TwitchExtras
    {
        // The Unreal plugin's OnIncomingRaidEnded.
        /// <summary>
        /// Raised when <see cref="EndIncomingRaid"/> closes the incoming raid
        /// window. Twitch sends no event when a raid is over, so your game decides
        /// when it is, and this is how the rest of the game hears about it.
        /// </summary>
        public event Action OnIncomingRaidEnded;

        // The Unreal plugin's bIsIncomingRaidOngoing.
        /// <summary>
        /// True from a raid on your channel until <see cref="EndIncomingRaid"/> is
        /// called. It is already true when the raid's own
        /// <c>Tentacle.Twitch.OnChannelRaid</c> event fires.
        /// </summary>
        public bool IsIncomingRaidOngoing { get; private set; }

        /// <summary>Creates the Twitch extras for a Twitch surface.</summary>
        internal Tentacle_TwitchExtras()
        {
        }

        /// <summary>
        /// Closes the incoming raid window: <see cref="IsIncomingRaidOngoing"/>
        /// goes false and <see cref="OnIncomingRaidEnded"/> is raised. Safe to call
        /// when no raid is ongoing, though it raises the event each time.
        /// </summary>
        public void EndIncomingRaid()
        {
            IsIncomingRaidOngoing = false;
            TentacleHandlers.Raise(OnIncomingRaidEnded, "stream");
        }

        /// <summary>
        /// Opens the incoming raid window. The Twitch surface calls this for a
        /// raid before its <c>OnChannelRaid</c> fires, so a raid handler already
        /// sees the window open.
        /// </summary>
        internal void BeginIncomingRaid()
        {
            IsIncomingRaidOngoing = true;
        }
    }
}
