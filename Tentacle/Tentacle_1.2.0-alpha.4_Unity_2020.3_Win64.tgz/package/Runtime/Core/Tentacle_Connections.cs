// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // Unreal's UTentacle_Connections, under the same names, which follow the
    // Connections_* messages. Godot's Object owns connect() and disconnect(),
    // so Godot spells those two connect_platform() and disconnect_platform(),
    // inside Godot, rather than every plugin giving them up.
    /// <summary>
    /// Connecting the streaming platforms from the game, which signs the player
    /// in, and each platform's connection as Tentacle reports it.
    ///
    /// This is for Tentacle embedded in the game (a mode set to <c>TentacleMode.Embedded</c>),
    /// where the game signs the player in itself. The Tentacle app has its own
    /// sign-in, so with the app none of these messages are answered.
    ///
    /// <see cref="SignInAsync"/> does all of signing in at once, and
    /// <see cref="CreateSignInController"/> is the logic of a sign-in button of
    /// your own design (the <c>SignInButton</c> component runs one). For finer
    /// control, <see cref="Connect"/> starts it: <see cref="OnConnectPrompt"/>
    /// says what to show (open the page in a browser, and show the code in case
    /// it asks), and <see cref="OnConnectResult"/> how it ended. The account
    /// stays signed in across runs until <see cref="Disconnect"/>.
    ///
    /// Features:
    /// - <see cref="OnConnectionChanged"/> and <see cref="GetConnection"/> say
    ///   whether each platform is live and which account is signed in, including
    ///   one that must sign in again
    /// - Every call is fire-and-forget; its outcome arrives as an event
    /// </summary>
    public sealed class Tentacle_Connections
    {
        private readonly TentacleClient client;
        private readonly Dictionary<StreamPlatform, PlatformConnection> connections =
            new Dictionary<StreamPlatform, PlatformConnection>();

        // Each platform's SignInAsync in progress. Tentacle drops an attempt a
        // new Connect replaces without reporting it, so a new sign-in ends the
        // one it replaces itself, or that call would never finish.
        private readonly Dictionary<StreamPlatform, PendingSignIn> signIns =
            new Dictionary<StreamPlatform, PendingSignIn>();

        /// <summary>A SignInAsync call waiting on its result.</summary>
        private sealed class PendingSignIn
        {
            public TaskCompletionSource<PlatformConnectionResult> Completion;
            public bool OpenBrowser;
            public Action<PlatformConnectionPrompt> OnPrompt;
            public CancellationTokenRegistration Cancellation;
        }

        // Every live sign-in controller, which the client's pump keeps current for
        // the countdown, and which hears each message here before the events do.
        private readonly List<SignInController> signInControllers = new List<SignInController>();

        // Runtime/Unity sets this to Application.OpenURL; the core references
        // no UnityEngine. Tests capture it.
        /// <summary>Opens a sign-in page in the player's browser, or null to open nothing.</summary>
        internal Action<string> OpenUrl { get; set; }

        /// <summary>Whether Tentacle runs inside the game, where the game signs the player in.</summary>
        internal bool IsEmbedded
        {
            get { return client.IsEmbedded; }
        }

        /// <summary>The client's clock, in seconds.</summary>
        internal double NowSeconds
        {
            get { return client.Clock.NowSeconds; }
        }

        /// <summary>
        /// Raised when a platform's connection changes, and once for each
        /// platform as a session opens. <see cref="GetConnection"/> already
        /// returns the new connection when it is raised.
        /// </summary>
        public event Action<PlatformConnection> OnConnectionChanged;

        /// <summary>
        /// Raised when connecting needs the player: open <see cref="PlatformConnectionPrompt.Url"/>
        /// in a browser, and show <see cref="PlatformConnectionPrompt.UserCode"/>
        /// (when there is one) in case the page asks for it.
        /// </summary>
        public event Action<PlatformConnectionPrompt> OnConnectPrompt;

        /// <summary>Raised when connecting ends: connected, denied, expired, cancelled, or failed.</summary>
        public event Action<PlatformConnectionResult> OnConnectResult;

        internal Tentacle_Connections(TentacleClient client)
        {
            this.client = client;
        }

        /// <summary>
        /// A platform's connection as Tentacle last reported it, or null before
        /// it has reported one.
        /// </summary>
        public PlatformConnection GetConnection(StreamPlatform platform)
        {
            PlatformConnection connection;
            return connections.TryGetValue(platform, out connection) ? connection : null;
        }

        /// <summary>
        /// Signs the player in to <paramref name="platform"/> in one call, as the
        /// Connections widget's button does: Tentacle connects it, the sign-in
        /// page opens in the player's browser unless
        /// <paramref name="openBrowser"/> is false, and the task finishes with
        /// how it ended. <paramref name="onPrompt"/> is called as the page opens,
        /// with the code to show for Twitch. Signing in to the same platform
        /// again finishes this call as cancelled, and so does
        /// <paramref name="cancellationToken"/>. With the Tentacle app, which has
        /// its own sign-in, it finishes at once as an error.
        /// </summary>
        public Task<PlatformConnectionResult> SignInAsync(
            StreamPlatform platform,
            bool openBrowser = true,
            Action<PlatformConnectionPrompt> onPrompt = null,
            CancellationToken cancellationToken = default)
        {
            if (!client.IsEmbedded)
            {
                return Task.FromResult(new PlatformConnectionResult
                {
                    Platform = platform,
                    Outcome = PlatformConnectionOutcome.Error,
                    Message = "Twitch and Kick connect through the Tentacle app",
                });
            }

            var pending = new PendingSignIn
            {
                Completion = new TaskCompletionSource<PlatformConnectionResult>(TaskCreationOptions.RunContinuationsAsynchronously),
                OpenBrowser = openBrowser,
                OnPrompt = onPrompt,
            };
            PendingSignIn replaced;
            lock (signIns)
            {
                signIns.TryGetValue(platform, out replaced);
                signIns[platform] = pending;
            }
            if (replaced != null) Finish(replaced, Cancelled(platform));

            Connect(platform);
            if (cancellationToken.CanBeCanceled)
            {
                pending.Cancellation = cancellationToken.Register(() =>
                {
                    if (Take(platform, pending))
                    {
                        CancelConnect(platform);
                        Finish(pending, Cancelled(platform));
                    }
                });
            }
            return pending.Completion.Task;
        }

        /// <summary>
        /// A sign-in controller for <paramref name="platform"/>: the logic of a
        /// sign-in button with no look of its own, for a button of your own
        /// design. It opens the sign-in page in the player's browser unless
        /// <paramref name="openBrowser"/> is false. Dispose it when the button
        /// goes away. The <c>SignInButton</c> component makes one for you.
        /// </summary>
        public SignInController CreateSignInController(StreamPlatform platform, bool openBrowser = true)
        {
            var controller = new SignInController(this, platform, openBrowser);
            signInControllers.Add(controller);
            return controller;
        }

        /// <summary>Lets a disposed controller go.</summary>
        internal void Forget(SignInController controller)
        {
            signInControllers.Remove(controller);
        }

        /// <summary>Keeps every sign-in controller current, for the countdown while signing in; the client's pump calls it.</summary>
        internal void Tick()
        {
            // Backwards, and by index: a handler may dispose its controller.
            for (var index = signInControllers.Count - 1; index >= 0; index--)
            {
                if (index < signInControllers.Count) signInControllers[index].Refresh();
            }
        }

        /// <summary>
        /// Starts connecting <paramref name="platform"/>, which signs the player
        /// in, replacing any attempt already in progress.
        /// <see cref="OnConnectPrompt"/> follows with what to show them.
        /// </summary>
        public void Connect(StreamPlatform platform)
        {
            Send("Connections_Connect", platform);
        }

        /// <summary>Abandons the connection attempt in progress on <paramref name="platform"/>.</summary>
        public void CancelConnect(StreamPlatform platform)
        {
            Send("Connections_CancelConnect", platform);
        }

        /// <summary>Disconnects <paramref name="platform"/>, signing its account out and forgetting it.</summary>
        public void Disconnect(StreamPlatform platform)
        {
            Send("Connections_Disconnect", platform);
        }

        private void Send(string messageType, StreamPlatform platform)
        {
            var wire = platform == StreamPlatform.Kick ? "kick" : "twitch";
            client.SendSocketMessage(messageType, JsonValue.Object(JsonValue.Member("platform", JsonValue.FromString(wire))));
        }

        internal void HandleStatus(JsonValue payload)
        {
            var connection = PlatformConnection.Parse(payload);
            if (connection == null) return;
            connections[connection.Platform] = connection;
            foreach (var controller in signInControllers.ToArray()) controller.Refresh();
            TentacleHandlers.Raise(OnConnectionChanged, connection, "connections");
        }

        internal void HandlePrompt(JsonValue payload)
        {
            var prompt = PlatformConnectionPrompt.Parse(payload);
            if (prompt == null) return;
            PendingSignIn pending;
            lock (signIns) signIns.TryGetValue(prompt.Platform, out pending);
            if (pending != null)
            {
                if (pending.OpenBrowser && OpenUrl != null) TentacleHandlers.Raise(OpenUrl, prompt.Url, "sign-in page");
                TentacleHandlers.Raise(pending.OnPrompt, prompt, "sign-in prompt");
            }
            foreach (var controller in signInControllers.ToArray()) controller.HandlePrompt(prompt);
            TentacleHandlers.Raise(OnConnectPrompt, prompt, "connections");
        }

        internal void HandleResult(JsonValue payload)
        {
            var result = PlatformConnectionResult.Parse(payload);
            if (result == null) return;
            PendingSignIn pending;
            lock (signIns) signIns.TryGetValue(result.Platform, out pending);
            if (pending != null && Take(result.Platform, pending)) Finish(pending, result);
            foreach (var controller in signInControllers.ToArray()) controller.HandleResult(result);
            TentacleHandlers.Raise(OnConnectResult, result, "connections");
        }

        /// <summary>Removes <paramref name="pending"/> as its platform's sign-in, if it still is. Returns whether it was.</summary>
        private bool Take(StreamPlatform platform, PendingSignIn pending)
        {
            lock (signIns)
            {
                PendingSignIn current;
                if (!signIns.TryGetValue(platform, out current) || current != pending) return false;
                signIns.Remove(platform);
                return true;
            }
        }

        /// <summary>Finishes a sign-in with <paramref name="result"/>.</summary>
        private static void Finish(PendingSignIn pending, PlatformConnectionResult result)
        {
            pending.Cancellation.Dispose();
            pending.Completion.TrySetResult(result);
        }

        /// <summary>A sign-in on <paramref name="platform"/> that was cancelled.</summary>
        private static PlatformConnectionResult Cancelled(StreamPlatform platform)
        {
            return new PlatformConnectionResult { Platform = platform, Outcome = PlatformConnectionOutcome.Cancelled };
        }
    }
}
