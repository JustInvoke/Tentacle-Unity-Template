// Copyright Tentacle. All Rights Reserved.
using System.Collections.Generic;
using Tcl.Json;

namespace Tcl
{
    /// <summary>
    /// Who this process is, as told to Tentacle in the opening handshake.
    ///
    /// Tentacle hosts the engine socket and several sessions are live at once - an
    /// editor play-mode session next to a packaged build, games made in different
    /// engines side by side - so every connection has to say what it is. Custom
    /// controls are scoped to the session that registered them, which is why
    /// <see cref="InstanceId"/> must differ between two processes running the same
    /// project: without that the app cannot tell their controls apart.
    ///
    /// Features:
    /// - Clamps every field to the 128-character limit the server enforces, so an
    ///   over-long label degrades into a truncated one rather than a refused
    ///   connection
    /// - Serializes to the exact `Session_Hello` payload shape
    /// </summary>
    public sealed class TentacleEngineIdentity
    {
        /// <summary>Maximum length of every hello field, matching the server's schema.</summary>
        public const int MaxFieldLength = 128;

        /// <summary>Engine family. Lowercased by the server; always "unity" from this package.</summary>
        public string Engine = "unity";

        /// <summary>Host engine version, e.g. "6000.0.23f1". Empty when unknown.</summary>
        public string EngineVersion = "";

        /// <summary>Version of this plugin.</summary>
        public string PluginVersion = "";

        /// <summary>
        /// Stable identifier for this process. Two processes running the same
        /// project must not share one.
        /// </summary>
        public string InstanceId = "";

        /// <summary>Human-readable name shown in Tentacle's session list.</summary>
        public string Label = "";

        /// <summary>
        /// Whether this identity carries what the server requires. The server
        /// closes the socket on an invalid hello, so the runtime checks first and
        /// reports a usable message instead of a reconnect loop.
        /// </summary>
        public bool IsValid(out string problem)
        {
            if (string.IsNullOrEmpty(Clamp(Engine)))
            {
                problem = "the engine name is empty";
                return false;
            }
            if (string.IsNullOrEmpty(Clamp(InstanceId)))
            {
                problem = "the instance id is empty";
                return false;
            }
            problem = null;
            return true;
        }

        /// <summary>
        /// The connection password Tentacle's user set under Settings > System,
        /// sent as it is, never trimmed or truncated. Empty sends none, which is
        /// all Tentacle asks for until a password is set.
        /// </summary>
        public string Password = "";

        /// <summary>Builds the `data` payload of a `Session_Hello` frame.</summary>
        public JsonValue ToHelloPayload()
        {
            var members = new List<KeyValuePair<string, JsonValue>>
            {
                JsonValue.Member("engine", JsonValue.FromString(Clamp(Engine))),
                JsonValue.Member("engineVersion", JsonValue.FromString(Clamp(EngineVersion))),
                JsonValue.Member("pluginVersion", JsonValue.FromString(Clamp(PluginVersion))),
                JsonValue.Member("instanceId", JsonValue.FromString(Clamp(InstanceId))),
                JsonValue.Member("label", JsonValue.FromString(Clamp(Label))),
            };
            // Never clamped: a password with a space at either end is still that password.
            if (!string.IsNullOrEmpty(Password))
            {
                members.Add(JsonValue.Member("password", JsonValue.FromString(Password)));
            }
            return JsonValue.Object(members.ToArray());
        }

        /// <summary>Trims and truncates one field to what the server accepts.</summary>
        private static string Clamp(string value)
        {
            if (value == null) return "";
            var trimmed = value.Trim();
            return trimmed.Length <= MaxFieldLength ? trimmed : trimmed.Substring(0, MaxFieldLength);
        }
    }
}
