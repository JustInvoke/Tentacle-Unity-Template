// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_Twitch, by name and by event. This class is
    // split in two. The generated half
    // (Runtime/Generated/Stream/Tentacle_Twitch.PlatformEvents.cs) declares one
    // event per Twitch event kind, named after Twitch's own reference, and
    // RaisePlatformEvent, held to Unreal's Tentacle_Twitch.h by a generator test;
    // this half keeps Extras, the dispatch that opens its raid window, and the
    // calls that address Twitch alone. The catch-all, the chat split and chat
    // joins are Tentacle's own, so they live on the entry point alone
    // (TentacleClient.Stream.cs), which also decides the order around them, as
    // ATentacle::HandleStreamEvent does.
    /// <summary>
    /// Twitch on its own, in Twitch's own words: every Twitch stream event, one
    /// event per kind, and the calls that address Twitch alone. Reached as
    /// <c>Tentacle.Twitch</c>.
    ///
    /// Every Twitch event kind has an event of its own, named after the title
    /// Twitch's EventSub reference gives it, that hands over that kind already
    /// typed: <c>OnChannelCheer</c> with a <see cref="StreamEvent_Twitch_Cheer"/>,
    /// <c>OnChannelRaid</c> with a <see cref="StreamEvent_Twitch_Raid"/>, and
    /// <c>OnChannelChatMessage</c> with every chat message, commands included.
    /// What Twitch shares with Kick also has a cross-platform event on the entry
    /// point itself, such as <see cref="TentacleClient.OnFollow"/> for a follow on
    /// either platform, raised right after the Twitch event here.
    ///
    /// For one Twitch event, the entry point's <see cref="TentacleClient.OnStreamEvent"/>
    /// fires first, then the kind's own event here, then the entry point's
    /// cross-platform event for the kind, if it has one (for a chat message, its
    /// message or command event, then its emoji and emote events).
    ///
    /// Features:
    /// - One event per Twitch event kind, typed as that kind, with the viewer the
    ///   event concerns wherever it concerns one
    /// - <see cref="Extras"/>, for what Tentacle adds to Twitch: the incoming raid
    ///   window, since Twitch sends no "raid over" event
    /// - Twitch's own Send Chat Message, replies included
    /// - Handlers run on the thread that pumps the client, each on its own, so one
    ///   that throws stops no other
    /// </summary>
    public sealed partial class Tentacle_Twitch
    {
        private readonly TentacleClient client;

        // The Unreal plugin's Extras subobject on UTentacle_Twitch.
        /// <summary>
        /// What Tentacle adds to Twitch that Twitch itself does not have: the
        /// incoming raid window.
        /// </summary>
        public Tentacle_TwitchExtras Extras { get; private set; }

        /// <summary>Creates the Twitch surface for a client.</summary>
        internal Tentacle_Twitch(TentacleClient client)
        {
            this.client = client;
            Extras = new Tentacle_TwitchExtras();
        }

        /// <summary>
        /// Sends a message in the broadcaster's Twitch chat, from the broadcaster:
        /// Twitch's Send Chat Message. To send on every connected platform at
        /// once, use <see cref="TentacleClient.SendChatMessage"/> instead.
        ///
        /// Fire-and-forget: a message Twitch drops surfaces in Tentacle's log
        /// rather than here. Validated the way
        /// <see cref="TentacleClient.SendChatMessage"/> validates: an empty
        /// message, or one over <see cref="TentacleClient.ChatMessageMaxLength"/>
        /// characters, is refused with a warning rather than sent. During a shared
        /// chat session the message reaches every channel in the session.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="replyParentMessageId">
        /// The id of the chat message this one replies to (a Twitch chat message's
        /// <c>MessageId</c>), or null for none.
        /// </param>
        public void SendChatMessage(string message, string replyParentMessageId = null)
        {
            if (!TentacleClient.IsSendableChatText(message))
            {
                return;
            }

            var members = new List<KeyValuePair<string, JsonValue>>
            {
                JsonValue.Member("message", JsonValue.FromString(message)),
            };
            if (!string.IsNullOrEmpty(replyParentMessageId))
            {
                members.Add(JsonValue.Member("replyParentMessageId", JsonValue.FromString(replyParentMessageId)));
            }

            client.SendSocketMessage("Twitch_SendChatMessage", JsonValue.FromObject(members));
        }

        // UTentacle_Twitch::DispatchEvent, minus the cross-platform broadcasts,
        // which the client raises once this returns.
        /// <summary>
        /// Raises the kind's own event for one Twitch event, already
        /// de-duplicated, opening the incoming raid window first for a raid.
        /// Answers whether the kind was one this surface has an event for, which
        /// is what decides whether a cross-platform event follows.
        /// </summary>
        internal bool Dispatch(StreamEvent_Twitch_Base streamEvent, Viewer viewer)
        {
            // Opened first, so a handler on OnChannelRaid already sees the window open.
            if (streamEvent is StreamEvent_Twitch_Raid) Extras.BeginIncomingRaid();

            return RaisePlatformEvent(streamEvent, viewer);
        }

        /// <summary>
        /// Carries one of the generated half's Twitch API requests to Tentacle as
        /// the app's <c>twitch.*</c> procedure, and reads its response.
        /// </summary>
        private Task<PlatformResponse<T>> RequestAsync<T>(
            string procedure,
            bool isQuery,
            JsonValue input,
            Func<JsonValue, T> parse,
            CancellationToken cancellationToken)
            where T : class
        {
            return client.PlatformRequestAsync(procedure, isQuery, input, parse, cancellationToken);
        }

        /// <summary>Raises a one-argument event, each subscriber on its own.</summary>
        private static void Raise<T>(Action<T> handler, T argument)
        {
            TentacleHandlers.Raise(handler, argument, "stream");
        }

        /// <summary>Raises a two-argument event, each subscriber on its own.</summary>
        private static void Raise<T>(Action<T, Viewer> handler, T argument, Viewer viewer)
        {
            TentacleHandlers.Raise(handler, argument, viewer, "stream");
        }
    }
}
