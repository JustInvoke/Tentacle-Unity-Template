// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;

namespace Tcl
{
    // One reading of a badge list, shared by the viewer's badge members and the
    // Twitch chat message's extension methods, as the Unreal plugin shares one
    // between UTclViewer and UTclChatMessageUtils.
    /// <summary>
    /// The badge sets that stand for each role, and the lookups the viewer and
    /// chat message helpers run over a badge list.
    /// </summary>
    internal static class TentacleBadges
    {
        /// <summary>Twitch's broadcaster badge set.</summary>
        internal static readonly string[] TwitchBroadcaster = { "broadcaster" };

        /// <summary>
        /// Twitch's moderator badge sets. A Lead Moderator wears
        /// <c>lead_moderator</c> in place of <c>moderator</c>, unless they chose
        /// the plain one.
        /// </summary>
        internal static readonly string[] TwitchModerator = { "moderator", "lead_moderator" };

        /// <summary>Twitch's VIP badge set.</summary>
        internal static readonly string[] TwitchVip = { "vip" };

        /// <summary>Twitch's subscriber badge sets: a founder is one of the first.</summary>
        internal static readonly string[] TwitchSubscriber = { "subscriber", "founder" };

        /// <summary>Kick's broadcaster badge type.</summary>
        internal static readonly string[] KickBroadcaster = { "broadcaster" };

        /// <summary>Kick's moderator badge type.</summary>
        internal static readonly string[] KickModerator = { "moderator" };

        /// <summary>Kick's VIP badge type.</summary>
        internal static readonly string[] KickVip = { "vip" };

        /// <summary>Kick's subscriber badge types: a founder is one of the first.</summary>
        internal static readonly string[] KickSubscriber = { "subscriber", "founder" };

        /// <summary>Whether a Twitch badge of one of these sets is in the list.</summary>
        internal static bool AnyTwitch(List<TwitchChatBadge> badges, string[] setIds, bool caseSensitive = true)
        {
            if (badges == null) return false;
            foreach (var badge in badges)
            {
                if (badge != null && Matches(badge.SetId, setIds, caseSensitive)) return true;
            }
            return false;
        }

        /// <summary>Whether a Kick badge of one of these types is in the list.</summary>
        internal static bool AnyKick(List<KickBadge> badges, string[] types, bool caseSensitive = true)
        {
            if (badges == null) return false;
            foreach (var badge in badges)
            {
                if (badge != null && Matches(badge.Type, types, caseSensitive)) return true;
            }
            return false;
        }

        /// <summary>Whether an id is one of these, under the caller's case rule.</summary>
        private static bool Matches(string id, string[] wanted, bool caseSensitive)
        {
            var comparison = caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            foreach (var candidate in wanted)
            {
                if (string.Equals(id, candidate, comparison)) return true;
            }
            return false;
        }
    }
}
