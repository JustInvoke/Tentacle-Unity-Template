// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Tcl.Json;

namespace Tcl
{
    // The Unreal plugin's UTentacle_Timers, member for member: OnTimerFired,
    // Subscribe / Unsubscribe with the same case rule and the same trailing
    // option, the definitions pushed at the session, and CreateTimer,
    // UpdateTimer, DeleteTimer, StartTimer, PauseTimer, ResetTimer, and
    // FireTimer, each a Task with C#'s Async. Subscribing the same handler to
    // the same name twice runs it once, as it does on Unreal.
    /// <summary>
    /// The timers the streamer defined in Tentacle, firing at the game, and the
    /// definitions behind them.
    ///
    /// A timer fires on a schedule the streamer sets in Tentacle - a fixed
    /// interval or a random one from a range, repeating or once, only while the
    /// stream is live if they like, and only after enough chat - so the game
    /// reacts to one name and keeps no clock of its own. The streamer starts,
    /// pauses, and resets timers in Tentacle, and the game can too, and define
    /// its own: see <see cref="CreateTimerAsync"/>.
    ///
    /// Features:
    /// - <see cref="OnTimerFired"/> for every timer, or <see cref="Subscribe"/>
    ///   for one name
    /// - Names are matched case-insensitively by default, with an option for
    ///   exact matching
    /// - No de-duplication: every fire is a fire
    /// - <see cref="Definitions"/> holds every timer with whether it is counting
    ///   down, kept current as the streamer changes them
    /// </summary>
    public sealed class Tentacle_Timers
    {
        /// <summary>One handler waiting for one timer.</summary>
        private sealed class Subscription
        {
            public string TimerName;
            public Action<TimerEvent> Handler;
            public bool CaseSensitive;

            /// <summary>Whether this subscription is for <paramref name="name"/>, under its own case rule.</summary>
            public bool Matches(string name)
            {
                return string.Equals(
                    TimerName,
                    name,
                    CaseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase);
            }
        }

        /// <summary>Every subscription, in the order they were made, which is the order they run in.</summary>
        private readonly List<Subscription> subscriptions = new List<Subscription>();

        private readonly List<TimerDefinition> definitions = new List<TimerDefinition>();

        /// <summary>The last definitions as received, so ones sent again unchanged raise nothing.</summary>
        private string definitionsKey;

        /// <summary>Raised for every timer fire, whatever the timer's name, before the handlers subscribed to it.</summary>
        public event Action<TimerEvent> OnTimerFired;

        /// <summary>
        /// Raised whenever the timer definitions change, including when the first
        /// ones arrive. <see cref="Definitions"/> already holds the new ones when
        /// it is raised.
        /// </summary>
        public event Action OnDefinitionsChanged;

        /// <summary>Every timer the streamer defined, ordered by name, with whether it is counting down.</summary>
        public IReadOnlyList<TimerDefinition> Definitions
        {
            get { return definitions; }
        }

        /// <summary>Whether Tentacle has sent the definitions yet. Until it has, <see cref="Definitions"/> is empty.</summary>
        public bool AreDefinitionsLoaded { get; private set; }

        private readonly TentacleClient client;

        /// <summary>Creates the timers surface for a client.</summary>
        internal Tentacle_Timers(TentacleClient client)
        {
            this.client = client;
        }

        /// <summary>
        /// Creates a timer, stopped until <see cref="StartTimerAsync"/> starts it.
        /// Configuring a timer in Tentacle and shipping its export is the easier
        /// way to give a game the timers it needs; this is for timers the game
        /// decides on as it runs. Answers Success, NameTaken when another timer
        /// has the name, or Failed (the reason is logged). Never throws but for
        /// cancellation.
        /// </summary>
        public Task<DefinitionResult> CreateTimerAsync(TimerSettings settings, CancellationToken cancellationToken = default)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            var input = SettingsJson(settings, null, settings.Name);
            return client.ChangeDefinitionAsync(
                (http, token) => http.CreateTimerAsync(input, token), "timers.create", cancellationToken);
        }

        /// <summary>
        /// Changes how a timer runs. Every setting is sent, so start from the
        /// timer's definition to change only one; an empty
        /// <see cref="TimerSettings.Name"/> keeps its name. A new interval starts
        /// its countdown over. Answers Success, NotFound, NameTaken when renaming
        /// it to a name another timer has, or Failed.
        /// </summary>
        public Task<DefinitionResult> UpdateTimerAsync(
            string name,
            TimerSettings settings,
            bool caseSensitive = false,
            CancellationToken cancellationToken = default)
        {
            if (settings == null) throw new ArgumentNullException(nameof(settings));
            DefinitionResult unresolved;
            var id = Resolve(name, caseSensitive, out unresolved);
            if (id == null) return Task.FromResult(unresolved);
            var input = SettingsJson(settings, id, settings.Name);
            return client.ChangeDefinitionAsync(
                (http, token) => http.UpdateTimerAsync(input, token), "timers.update", cancellationToken);
        }

        /// <summary>Deletes a timer. Answers Success, NotFound, or Failed.</summary>
        public Task<DefinitionResult> DeleteTimerAsync(
            string name,
            bool caseSensitive = false,
            CancellationToken cancellationToken = default)
        {
            return Drive(name, caseSensitive, "timers.delete", (http, input, token) => http.DeleteTimerAsync(input, token), cancellationToken);
        }

        /// <summary>
        /// Starts a timer: resumes a paused countdown, or begins a fresh one. A
        /// running timer is left as it is. Answers Success, NotFound, or Failed.
        /// </summary>
        public Task<DefinitionResult> StartTimerAsync(
            string name,
            bool caseSensitive = false,
            CancellationToken cancellationToken = default)
        {
            return Drive(name, caseSensitive, "timers.start", (http, input, token) => http.StartTimerAsync(input, token), cancellationToken);
        }

        /// <summary>
        /// Pauses a running timer, keeping what its countdown has left. Answers
        /// Success, NotFound, or Failed.
        /// </summary>
        public Task<DefinitionResult> PauseTimerAsync(
            string name,
            bool caseSensitive = false,
            CancellationToken cancellationToken = default)
        {
            return Drive(name, caseSensitive, "timers.pause", (http, input, token) => http.PauseTimerAsync(input, token), cancellationToken);
        }

        /// <summary>
        /// Starts a timer's countdown over, leaving it running or paused as it
        /// was. Answers Success, NotFound, or Failed.
        /// </summary>
        public Task<DefinitionResult> ResetTimerAsync(
            string name,
            bool caseSensitive = false,
            CancellationToken cancellationToken = default)
        {
            return Drive(name, caseSensitive, "timers.reset", (http, input, token) => http.ResetTimerAsync(input, token), cancellationToken);
        }

        /// <summary>
        /// Fires a timer now, as its countdown ending would, whatever its chat
        /// minimum: <see cref="OnTimerFired"/> is raised for it everywhere. A
        /// repeating timer then starts its countdown over; one that does not
        /// stops. Answers Success, NotFound, or Failed.
        /// </summary>
        public Task<DefinitionResult> FireTimerAsync(
            string name,
            bool caseSensitive = false,
            CancellationToken cancellationToken = default)
        {
            return Drive(name, caseSensitive, "timers.fire", (http, input, token) => http.FireTimerAsync(input, token), cancellationToken);
        }

        /// <summary>
        /// The id of the timer with this name, or null with why: NotFound when
        /// there is no such timer, Failed when the timers have not arrived from
        /// Tentacle, which says nothing about the name.
        /// </summary>
        private string Resolve(string name, bool caseSensitive, out DefinitionResult unresolved)
        {
            unresolved = DefinitionResult.Failed;
            if (!AreDefinitionsLoaded)
            {
                TentacleLog.Warn("Tentacle: the timers have not arrived from Tentacle yet, so \"" + name
                    + "\" cannot be found; is it connected?");
                return null;
            }
            var definition = FindDefinitionByName(name, caseSensitive);
            if (definition != null) return definition.Id;
            unresolved = DefinitionResult.NotFound;
            return null;
        }

        /// <summary>Calls a procedure that acts on one timer, named by its id.</summary>
        private Task<DefinitionResult> Drive(
            string name,
            bool caseSensitive,
            string procedure,
            Func<TentacleHttpClient, string, CancellationToken, Task<TentacleHttpResult>> call,
            CancellationToken cancellationToken)
        {
            DefinitionResult unresolved;
            var id = Resolve(name, caseSensitive, out unresolved);
            if (id == null) return Task.FromResult(unresolved);
            var input = JsonValue.Object(JsonValue.Member("id", JsonValue.FromString(id))).ToJson();
            return client.ChangeDefinitionAsync((http, token) => call(http, input, token), procedure, cancellationToken);
        }

        /// <summary>Every setting as a create or an update sends it, with the id and name when given.</summary>
        private static string SettingsJson(TimerSettings settings, string id, string name)
        {
            var members = new List<KeyValuePair<string, JsonValue>>();
            if (id != null) members.Add(JsonValue.Member("id", JsonValue.FromString(id)));
            if (!string.IsNullOrEmpty(name)) members.Add(JsonValue.Member("name", JsonValue.FromString(name)));
            members.Add(JsonValue.Member("repeating", JsonValue.FromBool(settings.Repeating)));
            members.Add(JsonValue.Member("onlyWhileLive", JsonValue.FromBool(settings.OnlyWhileLive)));
            members.Add(JsonValue.Member("intervalMinSeconds", JsonValue.FromNumber(settings.IntervalMinSeconds)));
            members.Add(JsonValue.Member("intervalMaxSeconds", JsonValue.FromNumber(settings.IntervalMaxSeconds)));
            members.Add(JsonValue.Member("minChatMessages", JsonValue.FromNumber(settings.MinChatMessages)));
            return JsonValue.Object(members.ToArray()).ToJson();
        }

        /// <summary>
        /// Runs <paramref name="handler"/> every time the timer with this name
        /// fires. Names are matched case-insensitively by default; pass
        /// <c>caseSensitive: true</c> if you need exact matching. Subscribing the
        /// same handler to the same name twice runs it once. Call
        /// <see cref="Unsubscribe"/> with the same name and handler to stop.
        /// </summary>
        public void Subscribe(string timerName, Action<TimerEvent> handler, bool caseSensitive = false)
        {
            if (string.IsNullOrEmpty(timerName) || handler == null) return;
            foreach (var existing in subscriptions)
            {
                if (existing.Handler == handler && existing.CaseSensitive == caseSensitive && existing.Matches(timerName)) return;
            }
            subscriptions.Add(new Subscription
            {
                TimerName = timerName,
                Handler = handler,
                CaseSensitive = caseSensitive,
            });
        }

        /// <summary>
        /// Stops running <paramref name="handler"/> for this name. The name is
        /// compared the way that subscription compares names: any case for a
        /// case-insensitive subscription, exactly for a case-sensitive one.
        /// </summary>
        public void Unsubscribe(string timerName, Action<TimerEvent> handler)
        {
            if (string.IsNullOrEmpty(timerName) || handler == null) return;
            subscriptions.RemoveAll(subscription => subscription.Handler == handler && subscription.Matches(timerName));
        }

        /// <summary>
        /// The timer with this name, or null. Case-insensitive by default, the
        /// same rule <see cref="Subscribe"/> uses.
        /// </summary>
        public TimerDefinition FindDefinitionByName(string name, bool caseSensitive = false)
        {
            if (string.IsNullOrEmpty(name)) return null;
            var comparison = caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            foreach (var definition in definitions)
            {
                if (string.Equals(definition.Name, name, comparison)) return definition;
            }
            return null;
        }

        /// <summary>Handles the payload of an inbound <c>Timers_Definitions</c>.</summary>
        internal void HandleDefinitions(JsonValue payload)
        {
            if (payload == null || payload.Kind != JsonKind.Object) return;

            // Tentacle sends the current definitions every time a session opens,
            // so ones identical to those held are not a change.
            var key = JsonWriter.Write(payload);
            if (AreDefinitionsLoaded && key == definitionsKey) return;

            var parsed = JsonRead.ReadList(payload, "definitions", TimerDefinition.Parse, true, "Timers_Definitions");
            if (parsed == null) return;

            definitions.Clear();
            foreach (var definition in parsed)
            {
                if (definition != null) definitions.Add(definition);
            }
            AreDefinitionsLoaded = true;
            definitionsKey = key;

            TentacleHandlers.Raise(OnDefinitionsChanged, "timer-definitions");
        }

        /// <summary>Handles the payload of an inbound <c>Timers_Fired</c>.</summary>
        internal void HandleFired(JsonValue payload)
        {
            if (payload == null || payload.Kind != JsonKind.Object) return;

            var fired = TimerEvent.Parse(payload);
            if (fired == null) return;

            TentacleHandlers.Raise(OnTimerFired, fired, "timer");

            if (string.IsNullOrEmpty(fired.Name)) return;

            // A snapshot, so a handler that subscribes or unsubscribes while it
            // runs changes the next fire rather than this one.
            foreach (var subscription in subscriptions.ToArray())
            {
                if (!subscription.Matches(fired.Name)) continue;
                TentacleHandlers.Raise(subscription.Handler, fired, "timer");
            }
        }
    }
}
