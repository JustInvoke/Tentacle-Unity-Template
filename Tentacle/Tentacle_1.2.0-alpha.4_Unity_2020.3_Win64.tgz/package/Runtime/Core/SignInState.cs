// Copyright Tentacle. All Rights Reserved.

using System;

namespace Tcl
{
    /// <summary>Where a sign-in button's platform stands, which decides what pressing it does.</summary>
    public enum SignInStage
    {
        /// <summary>Signing in is not available here: Tentacle runs in the Tentacle app.</summary>
        Unavailable,

        /// <summary>Tentacle is starting and has not said how the platform stands yet.</summary>
        Waiting,

        /// <summary>No account is signed in. Pressing signs the player in.</summary>
        NotConnected,

        /// <summary>The player is signing in in their browser. Pressing cancels.</summary>
        SigningIn,

        /// <summary>An account is signed in and the platform is connecting. Pressing disconnects.</summary>
        Connecting,

        /// <summary>An account is signed in and connected. Pressing disconnects.</summary>
        Connected,

        /// <summary>The account has to sign in again before it can connect. Pressing signs the player in.</summary>
        NeedsReconnect,
    }

    // Unreal's FTclSignInState and Godot's TclSignInState, with the same rules, and
    // the Connections widget's words (ConnectionsWidgetRow) for the status and
    // detail, so a player reads the same sign-in on every engine.
    /// <summary>
    /// What a sign-in button shows for one platform: what its label says, a
    /// status line and a detail line to show beside it, and whether it can be
    /// pressed.
    /// </summary>
    public sealed class SignInState : IEquatable<SignInState>
    {
        /// <summary>The platform this is about.</summary>
        public StreamPlatform Platform { get; private set; }

        /// <summary>Where the platform stands, which decides what pressing does.</summary>
        public SignInStage Stage { get; private set; }

        /// <summary>What the button says: Connect, Cancel, Disconnect, or Sign in again.</summary>
        public string Label { get; private set; }

        /// <summary>The platform's name: Twitch or Kick.</summary>
        public string Title { get; private set; }

        /// <summary>Where the platform stands, in a few words, such as "Connected as Streamer".</summary>
        public string Status { get; private set; }

        /// <summary>
        /// A second line, or empty: Twitch's code and the time left while signing
        /// in, why the last sign-in failed, or that signing in again allows newer
        /// features.
        /// </summary>
        public string Detail { get; private set; }

        /// <summary>While signing in to Twitch, the code to show the player in case the page asks for it. Empty otherwise.</summary>
        public string UserCode { get; private set; }

        /// <summary>While signing in, the sign-in page. Empty otherwise.</summary>
        public string Url { get; private set; }

        /// <summary>The signed-in account's display name, or empty when none is signed in.</summary>
        public string AccountName { get; private set; }

        /// <summary>Whether pressing the button does anything: false while <see cref="SignInStage.Unavailable"/> or <see cref="SignInStage.Waiting"/>.</summary>
        public bool CanPress { get; private set; }

        /// <summary>
        /// True when the account signed in before an update asked the platform for
        /// more access: it keeps working, and signing in again turns on what needs it.
        /// </summary>
        public bool MissingPermissions { get; private set; }

        private SignInState()
        {
            Label = "Connect";
            Title = "";
            Status = "";
            Detail = "";
            UserCode = "";
            Url = "";
            AccountName = "";
        }

        /// <summary>
        /// The state for <paramref name="platform"/>, given why signing in is
        /// unavailable here (empty when it is available), its connection (null
        /// before Tentacle has reported one), the sign-in prompt in progress (null
        /// for none) with <paramref name="secondsLeft"/> on it, and the result of
        /// the last sign-in (null for none).
        /// </summary>
        internal static SignInState Describe(
            StreamPlatform platform,
            string unavailableNote,
            PlatformConnection connection,
            PlatformConnectionPrompt prompt,
            double secondsLeft,
            PlatformConnectionResult result)
        {
            var state = new SignInState
            {
                Platform = platform,
                Title = ConnectionsWidgetRow.PlatformName(platform),
            };

            if (!string.IsNullOrEmpty(unavailableNote))
            {
                state.Stage = SignInStage.Unavailable;
                state.Status = unavailableNote;
                return state;
            }

            // The widget's words for where the platform stands; a button has one
            // action per stage where a row has two buttons.
            var row = ConnectionsWidgetRow.Describe(platform, connection, prompt, secondsLeft, result, true);
            state.Status = row.Status;
            state.Detail = row.Detail;

            if (prompt != null && secondsLeft > 0)
            {
                state.Stage = SignInStage.SigningIn;
                state.Label = "Cancel";
                state.UserCode = prompt.UserCode ?? "";
                state.Url = prompt.Url ?? "";
                state.CanPress = true;
                return state;
            }

            if (connection == null)
            {
                state.Stage = SignInStage.Waiting;
                return state;
            }

            state.CanPress = true;
            var account = connection.Account;
            if (account != null) state.AccountName = account.DisplayName ?? "";

            if (account != null && connection.NeedsReconnect)
            {
                state.Stage = SignInStage.NeedsReconnect;
                state.Label = "Sign in again";
            }
            else if (account != null)
            {
                state.Stage = connection.Status == PlatformConnectionStatus.Connected ? SignInStage.Connected : SignInStage.Connecting;
                state.Label = "Disconnect";
                state.MissingPermissions = connection.MissingPermissions;
            }
            else
            {
                state.Stage = SignInStage.NotConnected;
            }
            return state;
        }

        /// <inheritdoc />
        public bool Equals(SignInState other)
        {
            if (ReferenceEquals(other, null)) return false;
            return Platform == other.Platform
                && Stage == other.Stage
                && Label == other.Label
                && Title == other.Title
                && Status == other.Status
                && Detail == other.Detail
                && UserCode == other.UserCode
                && Url == other.Url
                && AccountName == other.AccountName
                && CanPress == other.CanPress
                && MissingPermissions == other.MissingPermissions;
        }

        /// <inheritdoc />
        public override bool Equals(object obj)
        {
            return Equals(obj as SignInState);
        }

        /// <inheritdoc />
        public override int GetHashCode()
        {
            unchecked
            {
                var hash = (int)Platform;
                hash = (hash * 397) ^ (int)Stage;
                hash = (hash * 397) ^ Label.GetHashCode();
                hash = (hash * 397) ^ Status.GetHashCode();
                hash = (hash * 397) ^ Detail.GetHashCode();
                return hash;
            }
        }
    }
}
