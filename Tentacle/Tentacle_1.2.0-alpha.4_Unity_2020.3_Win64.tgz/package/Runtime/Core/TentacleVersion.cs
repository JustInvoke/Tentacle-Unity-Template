// Copyright Tentacle. All Rights Reserved.
namespace Tcl
{
    // Kept in lockstep with the `version` field of the package manifest. Nothing
    // at runtime can read that manifest - UnityEditor.PackageManager is
    // editor-only - so it is duplicated here and the duplication is held honest
    // by an edit-mode test that compares the two.
    /// <summary>
    /// This plugin's version, as reported to Tentacle in the handshake. It is
    /// the same as the package's version in the Package Manager.
    /// </summary>
    public static class TentacleVersion
    {
        /// <summary>The package version.</summary>
        public const string Plugin = "1.2.0-alpha.4";
    }
}
