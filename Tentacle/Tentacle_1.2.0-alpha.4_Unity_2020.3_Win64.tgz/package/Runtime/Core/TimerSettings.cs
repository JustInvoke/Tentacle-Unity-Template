// Copyright Tentacle. All Rights Reserved.
using System;

namespace Tcl
{
    // The Unreal plugin's FTclTimerSettings, field for field, with the same
    // defaults, so the same settings make the same timer in every engine.
    /// <summary>
    /// How a timer runs, for <see cref="Tentacle_Timers.CreateTimerAsync"/> and
    /// <see cref="Tentacle_Timers.UpdateTimerAsync"/>. Every setting is sent, so
    /// one you leave alone takes its default.
    /// </summary>
    [Serializable]
    public sealed class TimerSettings
    {
        /// <summary>The timer's name, unique among the timers. On an update, empty keeps the timer's own name.</summary>
        public string Name = "";

        /// <summary>Whether it starts its countdown again after it fires, rather than stopping.</summary>
        public bool Repeating = true;

        /// <summary>Whether it counts down only while the stream is live on a connected platform.</summary>
        public bool OnlyWhileLive = true;

        /// <summary>
        /// The shortest countdown, in seconds, from 1 to 86400. Each countdown's
        /// length is drawn from the range; equal ends make it fixed.
        /// </summary>
        public int IntervalMinSeconds = 600;

        /// <summary>The longest countdown, in seconds, from 1 to 86400.</summary>
        public int IntervalMaxSeconds = 600;

        /// <summary>How many viewer chat messages must come between two fires, up to 1000.</summary>
        public int MinChatMessages;
    }
}
