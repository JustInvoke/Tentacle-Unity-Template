// Copyright Tentacle. All Rights Reserved.
using System;
using UnityEngine.Events;

namespace Tcl
{
    /// <summary>
    /// What the three event relays share: the client they subscribe to, and
    /// invoking a UnityEvent so that a listener that throws reaches no other
    /// subscriber.
    ///
    /// There is one relay per surface - <see cref="TentacleEventRelay"/>,
    /// <see cref="TentacleTwitchEventRelay"/>, and <see cref="TentacleKickEventRelay"/>
    /// - because a single component would have to hold the entry point's
    /// <c>OnChatMessage</c> and Kick's under one name.
    /// </summary>
    internal static class TentacleRelay
    {
        // The same seam as CustomControlComponent.RegistryOverride.
        /// <summary>
        /// The client relays subscribe to, or null for the singleton's - which is
        /// what a game always gets.
        /// </summary>
        internal static TentacleClient ClientOverride;

        /// <summary>The client a relay starting now subscribes to.</summary>
        internal static TentacleClient Client
        {
            get { return ClientOverride ?? Tentacle.Client; }
        }

        // A UnityEvent calls its listeners in one pass, so a listener that throws
        // still stops the ones after it on that UnityEvent; catching here keeps
        // it from reaching the client's other subscribers.
        /// <summary>Invokes a UnityEvent, reporting a listener that throws.</summary>
        internal static void Invoke(UnityEvent unityEvent)
        {
            try
            {
                unityEvent.Invoke();
            }
            catch (Exception exception)
            {
                Report(exception);
            }
        }

        /// <summary>Invokes a one-argument UnityEvent, reporting a listener that throws.</summary>
        internal static void Invoke<T>(UnityEvent<T> unityEvent, T argument)
        {
            try
            {
                unityEvent.Invoke(argument);
            }
            catch (Exception exception)
            {
                Report(exception);
            }
        }

        /// <summary>Invokes a two-argument UnityEvent, reporting a listener that throws.</summary>
        internal static void Invoke<T1, T2>(UnityEvent<T1, T2> unityEvent, T1 first, T2 second)
        {
            try
            {
                unityEvent.Invoke(first, second);
            }
            catch (Exception exception)
            {
                Report(exception);
            }
        }

        /// <summary>Logs a listener that threw.</summary>
        private static void Report(Exception exception)
        {
            TentacleLog.Error("Tentacle: an event relay listener threw: " + exception);
        }
    }
}
