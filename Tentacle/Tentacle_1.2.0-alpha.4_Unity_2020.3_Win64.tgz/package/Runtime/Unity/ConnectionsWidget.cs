// Copyright Tentacle. All Rights Reserved.

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace Tcl
{
    // Unreal's UTclConnectionsWidget and Godot's TclConnectionsWidget. Built from
    // uGUI at runtime, as the demo scene's look is, so the package ships no prefab
    // whose GUIDs a project would have to keep.
    /// <summary>
    /// A ready-made sign-in screen for Embedded mode: one row per platform, with
    /// its status and a button to connect, disconnect, or sign in again. Add it
    /// to a GameObject under a Canvas (with an EventSystem in the scene, as any
    /// uGUI button needs) and the player can connect their Twitch or Kick
    /// channel with no code of yours. While signing in, it opens the sign-in page
    /// in the player's browser, shows Twitch's code and how long it has left, and
    /// offers to open the page again or cancel; afterwards it says why a sign-in
    /// that did not connect failed. In Paired mode it shows one line saying the
    /// Tentacle app connects the platforms instead. For a sign-in screen of your
    /// own, use <see cref="SignInButton"/> components, or <see cref="Tentacle_Connections.SignInAsync"/>.
    /// </summary>
    [AddComponentMenu("Tentacle/Connections Widget")]
    [RequireComponent(typeof(RectTransform))]
    public sealed class ConnectionsWidget : MonoBehaviour
    {
        [Tooltip("The platforms to offer, in the order they are listed.")]
        public StreamPlatform[] Platforms = { StreamPlatform.Twitch, StreamPlatform.Kick };

        [Tooltip("Open the sign-in page in the player's browser as soon as signing in needs them. Off, the row offers a button for it instead.")]
        public bool OpenBrowserAutomatically = true;

        [Header("Look")]
        [Tooltip("The font for every line. Empty uses Unity's built-in font.")]
        public Font Font;

        [Tooltip("The size of the platform names and statuses; the detail line is a little smaller.")]
        public int FontSize = 18;

        [Tooltip("The colour of the platform names and statuses.")]
        public Color TextColor = Color.white;

        [Tooltip("The colour of the detail line under a status.")]
        public Color MutedTextColor = new Color(1f, 1f, 1f, 0.7f);

        [Tooltip("The colour of the buttons.")]
        public Color ButtonColor = new Color(0.47f, 0.31f, 0.86f);

        [Tooltip("The colour of the buttons' labels.")]
        public Color ButtonTextColor = Color.white;

        // The same seam as CustomEventListenerComponent.CustomEventsOverride: it
        // lets the edit-mode tests drive the widget against a client of their own.
        /// <summary>A connections surface every widget uses instead of <see cref="Tentacle.Connections"/>, as if Tentacle were embedded.</summary>
        internal static Tentacle_Connections ConnectionsOverride;

        /// <summary>How the widget opens a page; a test swaps in a recorder so no browser opens.</summary>
        internal Action<string> OpenUrl = Application.OpenURL;

        /// <summary>The clock a prompt's time left is measured on, in seconds; a test swaps in its own.</summary>
        internal Func<double> Clock = () => Time.realtimeSinceStartupAsDouble;

        /// <summary>One platform's row and what it last heard.</summary>
        internal sealed class Row
        {
            public StreamPlatform Platform;
            public Text Status;
            public Text Detail;
            public Button Primary;
            public Text PrimaryText;
            public Button Secondary;
            public Text SecondaryText;
            public ConnectionsWidgetAction PrimaryAction;
            public ConnectionsWidgetAction SecondaryAction;
            public PlatformConnectionPrompt Prompt;
            public double PromptDeadline;
            public PlatformConnectionResult Result;
        }

        private readonly List<Row> rows = new List<Row>();
        private Tentacle_Connections connections;
        private Text note;

        /// <summary>The rows, for the tests.</summary>
        internal IReadOnlyList<Row> Rows
        {
            get { return rows; }
        }

        /// <summary>The line shown in Paired mode, or null while the rows are shown.</summary>
        internal Text Note
        {
            get { return note; }
        }

        private void OnEnable()
        {
            StartListening();
        }

        private void OnDisable()
        {
            StopListening();
        }

        private void Update()
        {
            // The countdown, while a row is signing in.
            foreach (var row in rows)
            {
                if (row.Prompt != null) Refresh(row);
            }
        }

        /// <summary>Builds the rows and follows the platforms' connections; what OnEnable does.</summary>
        internal void StartListening()
        {
            if (connections != null || note != null) return;

            connections = ConnectionsOverride;
            if (connections == null)
            {
                if (!Tentacle.IsEmbedded)
                {
                    note = MakeText("Note", transform, FontSize, MutedTextColor);
                    note.text = "Twitch and Kick connect through the Tentacle app";
                    return;
                }
                connections = Tentacle.Connections;
            }

            connections.OnConnectionChanged += HandleConnectionChanged;
            connections.OnConnectPrompt += HandleConnectPrompt;
            connections.OnConnectResult += HandleConnectResult;
            if (rows.Count == 0) Build();
            foreach (var row in rows) Refresh(row);
        }

        /// <summary>Stops following the platforms' connections; what OnDisable does.</summary>
        internal void StopListening()
        {
            // The surface subscribed to, not Tentacle.Connections again, which
            // during shutdown would build a new runtime.
            if (connections == null) return;
            connections.OnConnectionChanged -= HandleConnectionChanged;
            connections.OnConnectPrompt -= HandleConnectPrompt;
            connections.OnConnectResult -= HandleConnectResult;
            connections = null;
        }

        private void Build()
        {
            // Not ??: a destroyed Unity object compares equal to null only through ==.
            var layout = gameObject.GetComponent<VerticalLayoutGroup>();
            if (layout == null) layout = gameObject.AddComponent<VerticalLayoutGroup>();
            layout.spacing = 6f;
            layout.childControlWidth = true;
            layout.childControlHeight = true;
            layout.childForceExpandWidth = true;
            layout.childForceExpandHeight = false;

            foreach (var platform in Platforms) rows.Add(BuildRow(platform));
        }

        private Row BuildRow(StreamPlatform platform)
        {
            var row = new Row { Platform = platform };

            var line = new GameObject(ConnectionsWidgetRow.PlatformName(platform), typeof(RectTransform));
            line.transform.SetParent(transform, false);
            var lineLayout = line.AddComponent<HorizontalLayoutGroup>();
            lineLayout.spacing = 10f;
            lineLayout.childAlignment = TextAnchor.MiddleLeft;
            lineLayout.childControlWidth = true;
            lineLayout.childControlHeight = true;
            lineLayout.childForceExpandWidth = false;
            lineLayout.childForceExpandHeight = false;

            var title = MakeText("Title", line.transform, FontSize, TextColor);
            title.text = ConnectionsWidgetRow.PlatformName(platform);
            title.fontStyle = FontStyle.Bold;
            title.gameObject.AddComponent<LayoutElement>().minWidth = FontSize * 4f;

            row.Status = MakeText("Status", line.transform, FontSize, TextColor);
            row.Status.gameObject.AddComponent<LayoutElement>().flexibleWidth = 1f;

            row.Primary = MakeButton("Primary", line.transform, out row.PrimaryText);
            row.Primary.onClick.AddListener(() => Press(row, true));
            row.Secondary = MakeButton("Secondary", line.transform, out row.SecondaryText);
            row.Secondary.onClick.AddListener(() => Press(row, false));

            row.Detail = MakeText("Detail", transform, Mathf.Max(1, FontSize - 3), MutedTextColor);
            return row;
        }

        private Text MakeText(string objectName, Transform parent, int size, Color color)
        {
            var carrier = new GameObject(objectName, typeof(RectTransform));
            carrier.transform.SetParent(parent, false);
            var text = carrier.AddComponent<Text>();
            text.font = Font != null ? Font : BuiltInFont();
            text.fontSize = size;
            text.color = color;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Overflow;
            return text;
        }

        /// <summary>The editor's built-in font, which the widget's text uses when <see cref="Font"/> is not set.</summary>
        private static Font BuiltInFont()
        {
            // Unity 2022.2 renamed it, and asking for the other name logs an
            // error and leaves the text with no font.
#if UNITY_2022_2_OR_NEWER
            return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        private Button MakeButton(string objectName, Transform parent, out Text label)
        {
            var carrier = new GameObject(objectName, typeof(RectTransform));
            carrier.transform.SetParent(parent, false);
            var image = carrier.AddComponent<Image>();
            image.color = ButtonColor;
            // Sized to its label: a layout group that force-expands its children
            // reports itself as flexible, and the row would hand the button
            // every spare pixel.
            var padding = carrier.AddComponent<HorizontalLayoutGroup>();
            padding.padding = new RectOffset(12, 12, 6, 6);
            padding.childControlWidth = true;
            padding.childControlHeight = true;
            padding.childForceExpandWidth = false;
            padding.childForceExpandHeight = false;
            var button = carrier.AddComponent<Button>();
            button.targetGraphic = image;
            label = MakeText("Label", carrier.transform, FontSize, ButtonTextColor);
            label.alignment = TextAnchor.MiddleCenter;
            label.horizontalOverflow = HorizontalWrapMode.Overflow;
            return button;
        }

        private void Refresh(Row row)
        {
            var secondsLeft = 0.0;
            if (row.Prompt != null)
            {
                secondsLeft = row.PromptDeadline - Clock();
                // Ran out here; the core's result says so shortly.
                if (secondsLeft <= 0) row.Prompt = null;
            }
            var described = ConnectionsWidgetRow.Describe(
                row.Platform,
                connections != null ? connections.GetConnection(row.Platform) : null,
                row.Prompt,
                secondsLeft,
                row.Result,
                OpenBrowserAutomatically);

            row.Status.text = described.Status;
            row.Detail.text = described.Detail;
            row.Detail.gameObject.SetActive(described.Detail.Length > 0);
            row.PrimaryAction = described.PrimaryAction;
            row.PrimaryText.text = described.PrimaryLabel;
            row.Primary.gameObject.SetActive(described.PrimaryAction != ConnectionsWidgetAction.None);
            row.SecondaryAction = described.SecondaryAction;
            row.SecondaryText.text = described.SecondaryLabel;
            row.Secondary.gameObject.SetActive(described.SecondaryAction != ConnectionsWidgetAction.None);
        }

        private Row RowFor(StreamPlatform platform)
        {
            foreach (var row in rows)
            {
                if (row.Platform == platform) return row;
            }
            return null;
        }

        private void Press(Row row, bool primary)
        {
            if (connections == null) return;
            switch (primary ? row.PrimaryAction : row.SecondaryAction)
            {
                case ConnectionsWidgetAction.Connect:
                    row.Result = null;
                    connections.Connect(row.Platform);
                    break;
                case ConnectionsWidgetAction.Disconnect:
                    connections.Disconnect(row.Platform);
                    break;
                case ConnectionsWidgetAction.OpenPage:
                    if (row.Prompt != null) OpenUrl(row.Prompt.Url);
                    break;
                case ConnectionsWidgetAction.Cancel:
                    connections.CancelConnect(row.Platform);
                    break;
            }
            Refresh(row);
        }

        private void HandleConnectionChanged(PlatformConnection connection)
        {
            var row = RowFor(connection.Platform);
            if (row != null) Refresh(row);
        }

        private void HandleConnectPrompt(PlatformConnectionPrompt prompt)
        {
            var row = RowFor(prompt.Platform);
            if (row == null) return;
            row.Prompt = prompt;
            row.PromptDeadline = Clock() + prompt.ExpiresInSeconds;
            row.Result = null;
            if (OpenBrowserAutomatically) OpenUrl(prompt.Url);
            Refresh(row);
        }

        private void HandleConnectResult(PlatformConnectionResult result)
        {
            var row = RowFor(result.Platform);
            if (row == null) return;
            row.Prompt = null;
            row.Result = result;
            Refresh(row);
        }
    }
}
