// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using UnityEngine;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace Tcl
{
    // The stream works the way the Unreal plugin's Tentacle actor does.
    /// <summary>
    /// The Tentacle singleton: one connection per game, reachable from anywhere.
    ///
    /// A game touches <see cref="Client"/> (or the shortcuts beside it) and never
    /// creates or owns anything. The client is built from
    /// <see cref="TentacleSettings"/> before the first scene loads, along with
    /// the hidden component that pumps it, so a handler subscribed in
    /// <c>Awake</c> cannot miss anything.
    ///
    /// The stream is split by platform: what the platforms have in common is
    /// right here, in Tentacle's own words, such
    /// as <see cref="OnStreamEvent"/> for every event, <see cref="OnFollow"/> for a
    /// follow on Twitch or Kick, and <see cref="SendChatMessage"/> for every
    /// connected platform, and each platform's own events and calls are on
    /// <see cref="Twitch"/> and <see cref="Kick"/>, named after that platform's
    /// own reference, such as <c>Tentacle.Twitch.OnChannelCheer</c>.
    ///
    /// Surviving the editor is the awkward part, and it is handled explicitly. A
    /// domain reload destroys all managed state while the OS socket and its
    /// receive thread would otherwise carry on, so the runtime is shut down
    /// before a reload and before leaving play mode, and rebuilt afterwards. The
    /// effect for a game is that entering and leaving play mode repeatedly leaves
    /// no orphaned sockets and no duplicated sessions in Tentacle.
    /// </summary>
    public static class Tentacle
    {
        private static TentacleClient client;
        private static TentacleHost host;
        private static bool editorHooksInstalled;

        /// <summary>
        /// The connection and everything reachable through it. Built on first
        /// use; never null.
        /// </summary>
        public static TentacleClient Client
        {
            get
            {
                EnsureCreated();
                return client;
            }
        }

        /// <summary>
        /// Twitch on its own, in Twitch's own words: every Twitch stream event,
        /// one event per kind, and the calls that address Twitch alone.
        /// </summary>
        public static Tentacle_Twitch Twitch
        {
            get { return Client.Twitch; }
        }

        /// <summary>
        /// Kick on its own, in Kick's own words: every Kick stream event, one
        /// event per kind, and the calls that address Kick alone.
        /// </summary>
        public static Tentacle_Kick Kick
        {
            get { return Client.Kick; }
        }

        /// <summary>
        /// Internal only, and not working yet: the subathon counters Tentacle
        /// keeps, whose numbers are not meaningful for your stream. Do not build
        /// on them.
        /// </summary>
        public static Tentacle_Subathon Subathon
        {
            get { return Client.Subathon; }
        }

        /// <summary>Controls this game puts in Tentacle's custom-controls panel.</summary>
        public static Tentacle_CustomControls CustomControls
        {
            get { return Client.CustomControls; }
        }

        /// <summary>Named events the streamer configured.</summary>
        public static Tentacle_CustomEvents CustomEvents
        {
            get { return Client.CustomEvents; }
        }

        /// <summary>OBS requests relayed through Tentacle.</summary>
        public static Tentacle_Obs Obs
        {
            get { return Client.Obs; }
        }

        /// <summary>Per-viewer values the streamer defined.</summary>
        public static Tentacle_ViewerProperties ViewerProperties
        {
            get { return Client.ViewerProperties; }
        }

        /// <summary>Every viewer this session has been told about.</summary>
        public static Tentacle_Viewers Viewers
        {
            get { return Client.Viewers; }
        }

        /// <summary>Tentacle's chat bot as the streamer configured it, with every command it answers, kept current.</summary>
        public static Tentacle_Bot Bot
        {
            get { return Client.Bot; }
        }

        /// <summary>The timers the streamer defined, firing at the game, and their definitions, kept current.</summary>
        public static Tentacle_Timers Timers
        {
            get { return Client.Timers; }
        }

        /// <summary>Signing in to the streaming platforms from the game, for Tentacle embedded in it.</summary>
        public static Tentacle_Connections Connections
        {
            get { return Client.Connections; }
        }

        // The Unreal plugin's ATentacle::OnConnectionStatusChanged. It lives on
        // the actor there, which outlives any one connection; here the client
        // is rebuilt on every domain reload and when play mode ends, so the
        // runtime carries the event and forwards whichever client it holds.
        /// <summary>
        /// Raised when <see cref="ConnectionStatus"/> changes, on the main thread.
        ///
        /// Subscribe once: the subscription carries over when the runtime
        /// replaces its client, which a subscription to
        /// <see cref="TentacleClient.OnConnectionStatusChanged"/> on
        /// <see cref="Client"/> does not.
        /// </summary>
        public static event Action<ConnectionStatus> OnConnectionStatusChanged;

        /// <summary>
        /// Where the connection stands. Reads as Disconnected before the runtime
        /// exists rather than building it, so a status readout in OnDestroy
        /// cannot resurrect it.
        /// </summary>
        public static ConnectionStatus ConnectionStatus
        {
            get
            {
                return client != null ? client.ConnectionStatus : ConnectionStatus.Disconnected;
            }
        }

        /// <summary>True while a session is open.</summary>
        public static bool IsConnected
        {
            get { return ConnectionStatus == ConnectionStatus.Connected; }
        }

        /// <summary>
        /// True when Tentacle runs inside the game rather than in the Tentacle
        /// app: the settings asset's Editor Mode in the Editor and Build Mode in
        /// a build, or <c>-tentacle-mode</c> on the command line. Signing in from
        /// the game only applies when this is true. Reads the settings rather
        /// than building the runtime.
        /// </summary>
        public static bool IsEmbedded
        {
            get { return client != null ? client.IsEmbedded : ResolvesToEmbedded(TentacleSettings.LoadOrDefault()); }
        }

        /// <summary>
        /// The id Tentacle assigned the open session, or empty while not
        /// connected. A new one is issued on every reconnect. Reads as empty
        /// before the runtime exists rather than building it.
        /// </summary>
        public static string SessionId
        {
            get { return client != null ? client.SessionId : ""; }
        }

        // The counterpart of the Unreal plugin's ATentacle::ConnectionPassword.
        /// <summary>
        /// Tentacle's connection password, for a Tentacle whose user set one
        /// under Settings &gt; System &gt; Connection Password. Starts as the
        /// settings asset's <see cref="TentacleSettings.ConnectionPassword"/>; a
        /// game for other people sets it from its own settings screen, since the
        /// password belongs to whoever runs Tentacle. A change is sent with the
        /// next request and the next connection attempt. Empty sends none.
        /// </summary>
        public static string ConnectionPassword
        {
            get { return client != null ? client.ConnectionPassword : TentacleSettings.LoadOrDefault().ConnectionPassword ?? ""; }
            set { Client.ConnectionPassword = value; }
        }

        /// <summary>Starts connecting, and keeps retrying until <see cref="Disconnect"/>.</summary>
        public static void Connect()
        {
            Client.Connect();
        }

        /// <summary>Closes the session and stops retrying.</summary>
        public static void Disconnect()
        {
            if (client == null) return;
            client.Disconnect();
        }

        // The Unreal plugin's ATentacle stream members (category Tentacle|Stream).
        // They live on the actor there, which outlives any one connection; here
        // the client is rebuilt on every domain reload and when play mode ends, so
        // the runtime carries each event and forwards whichever client it holds,
        // as it does OnConnectionStatusChanged. That also means unsubscribing in
        // OnDisable never touches the client, so it cannot rebuild the runtime in
        // the middle of the editor tearing it down.

        /// <summary>
        /// Longest chat message either platform accepts, in characters. A longer
        /// one is refused with a warning rather than sent.
        /// </summary>
        public const int ChatMessageMaxLength = TentacleClient.ChatMessageMaxLength;

        /// <summary>
        /// Raised for every stream event, whatever its platform or kind, including
        /// kinds this version of the package has no event of its own for. It fires
        /// first, before every other event for the same stream event: the kind's
        /// own event on its platform next (such as <c>Twitch.OnChannelCheer</c>),
        /// then the cross-platform event for the kind here. Each event says which
        /// platform it came from: match <see cref="StreamEvent_Twitch_Base"/> or
        /// <see cref="StreamEvent_Kick_Base"/>, or the kind's own type. The viewer
        /// is the one the event is about, or null for an event about the channel
        /// itself.
        ///
        /// Like every event on <see cref="Tentacle"/> itself, the subscription
        /// carries over when the runtime replaces its client.
        /// </summary>
        public static event Action<StreamEventBase, Viewer> OnStreamEvent;

        /// <summary>
        /// Raised when a viewer joins chat. Only Twitch reports joins: Tentacle
        /// checks who is in the Twitch chat every 30 seconds, so a join arrives
        /// up to 30 seconds after it happens, and viewers already in chat when
        /// Tentacle connects to Twitch raise none. The viewer's own
        /// <see cref="Viewer.Twitch"/> and <see cref="Viewer.Kick"/> profiles say
        /// which platforms they are known on.
        /// </summary>
        public static event Action<Viewer> OnChatJoin;

        /// <summary>
        /// Raised for a chat message that is not a command, from either platform,
        /// after the platform's own chat message event
        /// (<c>Twitch.OnChannelChatMessage</c> or <c>Kick.OnChatMessage</c>).
        /// </summary>
        public static event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessage;

        /// <summary>
        /// Raised for a chat message the app recognised as a command. A command
        /// does not also raise <see cref="OnChatMessage"/>.
        /// </summary>
        public static event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatCommand;

        /// <summary>
        /// Raised for a chat message carrying at least one emoji, in addition to
        /// <see cref="OnChatMessage"/> or <see cref="OnChatCommand"/>, and after it.
        /// </summary>
        public static event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmojis;

        /// <summary>
        /// Raised for a chat message carrying at least one emote, in addition to
        /// <see cref="OnChatMessage"/> or <see cref="OnChatCommand"/>, and after
        /// the emoji event.
        /// </summary>
        public static event Action<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmotes;

        /// <summary>Raised when a viewer is banned or timed out, on either platform.</summary>
        public static event Action<StreamEvent_Anywhere_Ban, Viewer> OnBan;

        /// <summary>
        /// Raised when the channel's title, category, or similar changes. Carries
        /// no viewer: the event describes the channel, not a person.
        /// </summary>
        public static event Action<StreamEvent_Anywhere_ChannelUpdate> OnChannelUpdate;

        /// <summary>
        /// Raised when a viewer cheers bits on Twitch. Kick has no donation event,
        /// so this is never raised for Kick.
        /// </summary>
        public static event Action<StreamEvent_Anywhere_Donation, Viewer> OnDonation;

        /// <summary>Raised on a new follow, on either platform.</summary>
        public static event Action<StreamEvent_Anywhere_Follow, Viewer> OnFollow;

        /// <summary>Raised on a channel-points or reward redemption, on either platform.</summary>
        public static event Action<StreamEvent_Anywhere_Redemption, Viewer> OnRedemption;

        /// <summary>Raised on a first-time subscription, on either platform.</summary>
        public static event Action<StreamEvent_Anywhere_Subscription, Viewer> OnSubscription;

        /// <summary>Raised on gifted subscriptions, on either platform.</summary>
        public static event Action<StreamEvent_Anywhere_SubscriptionGift, Viewer> OnSubscriptionGift;

        /// <summary>Raised when an existing subscription is renewed or resubscribed, on either platform.</summary>
        public static event Action<StreamEvent_Anywhere_SubscriptionRenewal, Viewer> OnSubscriptionRenewal;

        /// <summary>
        /// Sends a chat message to every connected platform. Fire-and-forget. An
        /// empty message, or one over <see cref="ChatMessageMaxLength"/>
        /// characters, is refused with a warning rather than sent. <c>isBot</c>
        /// sends as the bot identity where the platform supports one (Kick).
        /// <c>Tentacle.Twitch.SendChatMessage</c> and
        /// <c>Tentacle.Kick.PostChatMessage</c> send on one platform alone, with
        /// that platform's own options.
        /// </summary>
        public static void SendChatMessage(string message, bool isBot = false)
        {
            Client.SendChatMessage(message, isBot);
        }

        /// <summary>
        /// Sends a chat message addressed to one viewer on every connected
        /// platform. Validated as <see cref="SendChatMessage"/> is, and refused
        /// for a null viewer.
        /// </summary>
        public static void SendChatMessageToViewer(Viewer viewer, string message, bool isBot = false)
        {
            Client.SendChatMessageToViewer(viewer, message, isBot);
        }

        /// <summary>
        /// Runs before the first scene loads, so a game object subscribing in
        /// Awake is already too late to miss anything.
        /// </summary>
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Bootstrap()
        {
            // Resolved once and handed on, rather than loaded again inside
            // EnsureCreated.
            var settings = TentacleSettings.LoadOrDefault();
            EnsureCreated(settings);
            if (settings.AutoConnect) client.Connect();
        }

        /// <summary>Builds the client and its pump host if they do not exist yet.</summary>
        private static void EnsureCreated()
        {
            EnsureCreated(null);
        }

        /// <summary>
        /// Builds the client and its pump host if they do not exist yet, using
        /// <paramref name="settings"/> when the caller has already resolved them.
        /// </summary>
        private static void EnsureCreated(TentacleSettings settings)
        {
            InstallEditorHooks();

            if (client == null)
            {
                var resolved = settings != null ? settings : TentacleSettings.LoadOrDefault();
                InstallLogSink(resolved);
                Adopt(new TentacleClient(BuildOptions(resolved)));
            }

            // Only while playing: edit mode has no frames to pump, and refuses
            // the DontDestroyOnLoad the pump object needs, which used to leave
            // a hidden object behind on every touch from an editor script.
            if (host == null && Application.isPlaying) host = TentacleHost.Spawn();
        }

        /// <summary>
        /// Drops every subscriber to the runtime's events as a play session
        /// starts. A domain reload does that already; with it turned off (Enter
        /// Play Mode Options), a handler a game never removed would otherwise
        /// hold its destroyed object and run again in the next session.
        /// </summary>
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ClearSubscribersForNewPlaySession()
        {
            ClearSubscribers();
        }

        /// <summary>Drops every subscriber to the runtime's events.</summary>
        internal static void ClearSubscribers()
        {
            OnConnectionStatusChanged = null;
            OnStreamEvent = null;
            OnChatJoin = null;
            OnChatMessage = null;
            OnChatCommand = null;
            OnChatMessageWithEmojis = null;
            OnChatMessageWithEmotes = null;
            OnBan = null;
            OnChannelUpdate = null;
            OnDonation = null;
            OnFollow = null;
            OnRedemption = null;
            OnSubscription = null;
            OnSubscriptionGift = null;
            OnSubscriptionRenewal = null;
        }

        /// <summary>
        /// Makes <paramref name="created"/> the runtime's client and forwards its
        /// status changes and cross-platform stream events.
        /// </summary>
        private static void Adopt(TentacleClient created)
        {
            client = created;
            client.OnConnectionStatusChanged += RaiseConnectionStatusChanged;
            client.Connections.OpenUrl = Application.OpenURL;
            ForwardStream(client);
        }

        /// <summary>Raises <see cref="OnConnectionStatusChanged"/>, each subscriber on its own.</summary>
        private static void RaiseConnectionStatusChanged(ConnectionStatus status)
        {
            TentacleHandlers.Raise(OnConnectionStatusChanged, status, "connection-status");
        }

        /// <summary>Forwards a client's cross-platform stream events to the runtime's own.</summary>
        private static void ForwardStream(TentacleClient source)
        {
            source.OnStreamEvent += RaiseStreamEvent;
            source.OnChatJoin += RaiseChatJoin;
            source.OnChatMessage += RaiseChatMessage;
            source.OnChatCommand += RaiseChatCommand;
            source.OnChatMessageWithEmojis += RaiseChatMessageWithEmojis;
            source.OnChatMessageWithEmotes += RaiseChatMessageWithEmotes;
            source.OnBan += RaiseBan;
            source.OnChannelUpdate += RaiseChannelUpdate;
            source.OnDonation += RaiseDonation;
            source.OnFollow += RaiseFollow;
            source.OnRedemption += RaiseRedemption;
            source.OnSubscription += RaiseSubscription;
            source.OnSubscriptionGift += RaiseSubscriptionGift;
            source.OnSubscriptionRenewal += RaiseSubscriptionRenewal;
        }

        /// <summary>Stops forwarding what <see cref="ForwardStream"/> forwarded.</summary>
        private static void StopForwardingStream(TentacleClient source)
        {
            source.OnStreamEvent -= RaiseStreamEvent;
            source.OnChatJoin -= RaiseChatJoin;
            source.OnChatMessage -= RaiseChatMessage;
            source.OnChatCommand -= RaiseChatCommand;
            source.OnChatMessageWithEmojis -= RaiseChatMessageWithEmojis;
            source.OnChatMessageWithEmotes -= RaiseChatMessageWithEmotes;
            source.OnBan -= RaiseBan;
            source.OnChannelUpdate -= RaiseChannelUpdate;
            source.OnDonation -= RaiseDonation;
            source.OnFollow -= RaiseFollow;
            source.OnRedemption -= RaiseRedemption;
            source.OnSubscription -= RaiseSubscription;
            source.OnSubscriptionGift -= RaiseSubscriptionGift;
            source.OnSubscriptionRenewal -= RaiseSubscriptionRenewal;
        }

        // Each raises the runtime's own event one subscriber at a time, so a
        // throwing handler stops neither the others nor the client's dispatch.
        private static void RaiseStreamEvent(StreamEventBase e, Viewer v) { TentacleHandlers.Raise(OnStreamEvent, e, v, "stream"); }

        private static void RaiseChatJoin(Viewer v) { TentacleHandlers.Raise(OnChatJoin, v, "stream"); }

        private static void RaiseChatMessage(StreamEvent_Anywhere_ChatMessage e, Viewer v) { TentacleHandlers.Raise(OnChatMessage, e, v, "stream"); }

        private static void RaiseChatCommand(StreamEvent_Anywhere_ChatMessage e, Viewer v) { TentacleHandlers.Raise(OnChatCommand, e, v, "stream"); }

        private static void RaiseChatMessageWithEmojis(StreamEvent_Anywhere_ChatMessage e, Viewer v) { TentacleHandlers.Raise(OnChatMessageWithEmojis, e, v, "stream"); }

        private static void RaiseChatMessageWithEmotes(StreamEvent_Anywhere_ChatMessage e, Viewer v) { TentacleHandlers.Raise(OnChatMessageWithEmotes, e, v, "stream"); }

        private static void RaiseBan(StreamEvent_Anywhere_Ban e, Viewer v) { TentacleHandlers.Raise(OnBan, e, v, "stream"); }

        private static void RaiseChannelUpdate(StreamEvent_Anywhere_ChannelUpdate e) { TentacleHandlers.Raise(OnChannelUpdate, e, "stream"); }

        private static void RaiseDonation(StreamEvent_Anywhere_Donation e, Viewer v) { TentacleHandlers.Raise(OnDonation, e, v, "stream"); }

        private static void RaiseFollow(StreamEvent_Anywhere_Follow e, Viewer v) { TentacleHandlers.Raise(OnFollow, e, v, "stream"); }

        private static void RaiseRedemption(StreamEvent_Anywhere_Redemption e, Viewer v) { TentacleHandlers.Raise(OnRedemption, e, v, "stream"); }

        private static void RaiseSubscription(StreamEvent_Anywhere_Subscription e, Viewer v) { TentacleHandlers.Raise(OnSubscription, e, v, "stream"); }

        private static void RaiseSubscriptionGift(StreamEvent_Anywhere_SubscriptionGift e, Viewer v) { TentacleHandlers.Raise(OnSubscriptionGift, e, v, "stream"); }

        private static void RaiseSubscriptionRenewal(StreamEvent_Anywhere_SubscriptionRenewal e, Viewer v) { TentacleHandlers.Raise(OnSubscriptionRenewal, e, v, "stream"); }

        // The same seam as CustomControlComponent.RegistryOverride: it lets
        // the edit-mode tests drive the runtime's own events against a client of
        // their own, without a real socket or the object that pumps it.
        /// <summary>
        /// Shuts the runtime down and makes <paramref name="replacement"/> its
        /// client, without spawning the pump host.
        /// </summary>
        internal static void UseClient(TentacleClient replacement)
        {
            Shutdown();
            if (replacement != null) Adopt(replacement);
        }

        /// <summary>Turns the settings asset into client options.</summary>
        private static TentacleClientOptions BuildOptions(TentacleSettings settings)
        {
            var label = string.IsNullOrEmpty(settings.SessionLabel)
                ? Application.productName + (Application.isEditor ? " (Editor)" : "")
                : settings.SessionLabel;

            var options = new TentacleClientOptions
            {
                Identity = new TentacleEngineIdentity
                {
                    Engine = "unity",
                    EngineVersion = Application.unityVersion,
                    PluginVersion = TentacleVersion.Plugin,
                    // Unique per process, which is what keeps a play-mode session
                    // and a packaged build of the same project apart in Tentacle.
                    InstanceId = Guid.NewGuid().ToString("N"),
                    Label = label,
                    Password = settings.ConnectionPassword ?? "",
                },
                DataDirectory = string.IsNullOrEmpty(settings.DataDirectoryOverride)
                    ? null
                    : settings.DataDirectoryOverride,
                ReconnectPolicy = new TentacleReconnectPolicy
                {
                    InitialDelaySeconds = settings.ReconnectInitialDelaySeconds,
                    MaxDelaySeconds = settings.ReconnectMaxDelaySeconds,
                },
                StreamDeduplicationWindow = settings.StreamDeduplicationWindow,
                RefreshRegistryOnConnect = settings.RefreshRegistryOnConnect,
            };

            if (ResolvesToEmbedded(settings))
            {
                options.Socket = new TentacleEmbeddedTransport(new TentacleEmbeddedOptions
                {
                    DataDirectory = string.IsNullOrEmpty(settings.EmbeddedDataDirectory)
                        ? System.IO.Path.Combine(Application.persistentDataPath, "Tentacle")
                        : settings.EmbeddedDataDirectory,
                    TwitchClientId = settings.TwitchClientId,
                    ConfigFiles = TentacleConfigFiles.Read(ConfigFolderPath(settings)),
                });
                options.Endpoints = TentacleEndpoints.Embedded();
            }
            return options;
        }

        /// <summary>Whether <paramref name="settings"/> put Tentacle inside the game, where it is running now.</summary>
        private static bool ResolvesToEmbedded(TentacleSettings settings)
        {
            return TentacleModeResolver.ResolvesToEmbedded(settings.EditorMode, settings.BuildMode, Application.isEditor, Environment.GetCommandLineArgs());
        }

        // StreamingAssets is copied into a build untouched, and is a plain
        // folder on every platform embedded Tentacle runs on, so the files are
        // read the same way in the Editor and in a build.
        /// <summary>
        /// The folder <paramref name="settings"/> read config files from: their
        /// <see cref="TentacleSettings.ConfigFolder"/> under StreamingAssets, or
        /// that folder itself when it is a full path.
        /// </summary>
        internal static string ConfigFolderPath(TentacleSettings settings)
        {
            var folder = string.IsNullOrEmpty(settings.ConfigFolder) ? TentacleSettings.DefaultConfigFolder : settings.ConfigFolder;
            return System.IO.Path.Combine(Application.streamingAssetsPath, folder);
        }

        /// <summary>Points the package's diagnostics at the Unity console.</summary>
        private static void InstallLogSink(TentacleSettings settings)
        {
            if (!settings.LogToConsole)
            {
                TentacleLog.InstallSink(null);
                return;
            }

            var includeLifecycle = settings.LogLifecycle;
            TentacleLog.InstallSink((level, message) =>
            {
                switch (level)
                {
                    case TentacleLogLevel.Error:
                        Debug.LogError(message);
                        break;
                    case TentacleLogLevel.Warning:
                        Debug.LogWarning(message);
                        break;
                    default:
                        if (includeLifecycle) Debug.Log(message);
                        break;
                }
            });
        }

        /// <summary>Advances the client. Called once per frame by the host.</summary>
        internal static void Pump()
        {
            if (client != null) client.Pump();
        }

        /// <summary>
        /// The client if one exists, without building one. Used by anything
        /// running during teardown, where creating a client - and the GameObject
        /// that pumps it - would resurrect the runtime the editor is in the
        /// middle of destroying.
        /// </summary>
        public static TentacleClient CurrentClient
        {
            get { return client; }
        }

        /// <summary>
        /// Closes the connection and drops everything, so the next touch of
        /// <see cref="Client"/> builds a fresh one. Called when play mode ends,
        /// before a domain reload, and when the application quits.
        /// </summary>
        internal static void Shutdown()
        {
            if (client != null)
            {
                client.OnConnectionStatusChanged -= RaiseConnectionStatusChanged;
                StopForwardingStream(client);
                client.Dispose();
                client = null;
            }

            // After the client, whose connection it would otherwise close under it.
            TentacleEmbeddedCore.Shutdown();

            // The host has to go with it. Leaving it behind would leave a hidden
            // GameObject ticking a client that no longer exists, and the next
            // EnsureCreated would spawn a second one beside it.
            if (host != null)
            {
                var carrier = host.gameObject;
                host = null;
                if (Application.isPlaying) UnityEngine.Object.Destroy(carrier);
                else UnityEngine.Object.DestroyImmediate(carrier);
            }
#if UNITY_EDITOR
            // A Destroy made as play mode ends is deferred, and play mode can end
            // before it runs. The pump object is hidden and not saved, so nothing
            // else would remove it: the shutdown back in edit mode does.
            if (!Application.isPlaying) DestroyStrayHosts();
#endif
        }

#if UNITY_EDITOR
        /// <summary>Destroys any pump object still in the editor's world.</summary>
        private static void DestroyStrayHosts()
        {
            foreach (var stray in Resources.FindObjectsOfTypeAll<TentacleHost>())
            {
                if (stray != null && !EditorUtility.IsPersistent(stray))
                {
                    UnityEngine.Object.DestroyImmediate(stray.gameObject);
                }
            }
        }
#endif

#if UNITY_EDITOR
        /// <summary>
        /// Tears the runtime down before the editor destroys the managed world
        /// underneath it. Without this the receive thread and the OS socket would
        /// outlive the objects that own them: a script recompile or a second
        /// entry into play mode would leave Tentacle showing sessions for a game
        /// that is no longer running.
        /// </summary>
        private static void InstallEditorHooks()
        {
            if (editorHooksInstalled) return;
            editorHooksInstalled = true;

            AssemblyReloadEvents.beforeAssemblyReload += Shutdown;
            EditorApplication.playModeStateChanged += state =>
            {
                // Twice, deliberately. ExitingPlayMode is the shutdown that
                // matters, but MonoBehaviour.OnDestroy runs after it, and a game
                // unregistering a control there touches Tentacle and
                // builds a fresh client and pump object in the middle of
                // teardown. Shutting down again once the editor is back in edit
                // mode disposes anything that came back that way, instead of
                // leaving it parked in statics until the next domain reload.
                if (state == PlayModeStateChange.ExitingPlayMode
                    || state == PlayModeStateChange.EnteredEditMode)
                {
                    Shutdown();
                }
            };
            EditorApplication.quitting += Shutdown;
        }
#else
        /// <summary>
        /// Shuts the runtime down as the player quits. The pump object's
        /// OnApplicationQuit does too, but a player can quit without it (a
        /// mobile OS ending the app, say), and the quitting event is the one
        /// Unity raises however it ends.
        /// </summary>
        private static void InstallEditorHooks()
        {
            if (editorHooksInstalled) return;
            editorHooksInstalled = true;
            Application.quitting += Shutdown;
        }
#endif
    }
}
