// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // No Unreal counterpart as a type: an Unreal user binds the Tentacle actor's
    // delegates straight from the Details panel, and a Unity scene has no such
    // panel for a C# event. Every UnityEvent here is named after the event it
    // relays, so the names are the Unreal delegates' names. Each platform's own
    // events have a relay of their own (TentacleTwitchEventRelay,
    // TentacleKickEventRelay) rather than a place here, because the entry point
    // and Kick both have an OnChatMessage, and one component cannot hold two
    // members of one name. Godot splits its relays the same way for the same
    // reason.
    /// <summary>
    /// The entry point's events as UnityEvents you fill in from the Inspector,
    /// for a project that drives things from the scene rather than from code.
    ///
    /// Each UnityEvent carries the name and the arguments of the event it
    /// relays: the connection status, a viewer arriving, every stream event and
    /// every cross-platform stream event, every custom event, and every timer
    /// fire. It is a convenience over <see cref="Tentacle"/>, not a replacement:
    /// drop it on a GameObject; several may coexist.
    ///
    /// Each platform's own chat message is on <see cref="TentacleTwitchEventRelay"/>
    /// and <see cref="TentacleKickEventRelay"/>, along with the end of Twitch's
    /// incoming raid.
    ///
    /// Subscriptions are made in OnEnable and dropped in OnDisable, so a disabled
    /// object costs nothing and a destroyed one leaves no dangling handler.
    /// </summary>
    [AddComponentMenu("Tentacle/Tentacle Event Relay")]
    public sealed class TentacleEventRelay : MonoBehaviour
    {
        [Tooltip("Raised whenever the connection to Tentacle changes status.")]
        [SerializeField]
        private UnityEvent<ConnectionStatus> onConnectionStatusChanged = new UnityEvent<ConnectionStatus>();

        [Tooltip("Raised the first time a viewer is seen this session.")]
        [SerializeField]
        private UnityEvent<Viewer> onViewerAdded = new UnityEvent<Viewer>();

        [Tooltip("Raised for every stream event, whatever its platform or kind.")]
        [SerializeField]
        private UnityEvent<StreamEventBase, Viewer> onStreamEvent = new UnityEvent<StreamEventBase, Viewer>();

        [Tooltip("Raised when a viewer joins chat. Only Twitch reports joins, up to 30 seconds late.")]
        [SerializeField]
        private UnityEvent<Viewer> onChatJoin = new UnityEvent<Viewer>();

        [Tooltip("Raised for a chat message from either platform. Commands are not included.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> onChatMessage =
            new UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer>();

        [Tooltip("Raised for a chat message the app recognised as a command, from either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> onChatCommand =
            new UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer>();

        [Tooltip("Raised for a chat message or command carrying at least one emoji.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> onChatMessageWithEmojis =
            new UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer>();

        [Tooltip("Raised for a chat message or command carrying at least one emote.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> onChatMessageWithEmotes =
            new UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer>();

        [Tooltip("Raised when a viewer is banned or timed out, on either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Ban, Viewer> onBan =
            new UnityEvent<StreamEvent_Anywhere_Ban, Viewer>();

        [Tooltip("Raised when the channel's title, category, or similar changes. Carries no viewer.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_ChannelUpdate> onChannelUpdate =
            new UnityEvent<StreamEvent_Anywhere_ChannelUpdate>();

        [Tooltip("Raised when a viewer cheers bits on Twitch.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Donation, Viewer> onDonation =
            new UnityEvent<StreamEvent_Anywhere_Donation, Viewer>();

        [Tooltip("Raised on a new follow, on either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Follow, Viewer> onFollow =
            new UnityEvent<StreamEvent_Anywhere_Follow, Viewer>();

        [Tooltip("Raised on a channel-points or reward redemption, on either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Redemption, Viewer> onRedemption =
            new UnityEvent<StreamEvent_Anywhere_Redemption, Viewer>();

        [Tooltip("Raised on a first-time subscription, on either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_Subscription, Viewer> onSubscription =
            new UnityEvent<StreamEvent_Anywhere_Subscription, Viewer>();

        [Tooltip("Raised on gifted subscriptions, on either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_SubscriptionGift, Viewer> onSubscriptionGift =
            new UnityEvent<StreamEvent_Anywhere_SubscriptionGift, Viewer>();

        [Tooltip("Raised when an existing subscription is renewed or resubscribed, on either platform.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Anywhere_SubscriptionRenewal, Viewer> onSubscriptionRenewal =
            new UnityEvent<StreamEvent_Anywhere_SubscriptionRenewal, Viewer>();

        [Tooltip("Raised for any custom event the streamer configured.")]
        [SerializeField]
        private UnityEvent<CustomEvent, Viewer> onCustomEvent = new UnityEvent<CustomEvent, Viewer>();

        [Tooltip("Raised for every fire of any timer the streamer defined.")]
        [SerializeField]
        private UnityEvent<TimerEvent> onTimerFired = new UnityEvent<TimerEvent>();

        /// <summary>The client this relay subscribed to, so it unsubscribes from the same one.</summary>
        private TentacleClient subscribed;

        /// <summary>Relays <see cref="TentacleClient.OnConnectionStatusChanged"/>.</summary>
        public UnityEvent<ConnectionStatus> OnConnectionStatusChanged
        {
            get { return onConnectionStatusChanged; }
        }

        /// <summary>Relays <see cref="Tentacle_Viewers.OnViewerAdded"/>.</summary>
        public UnityEvent<Viewer> OnViewerAdded
        {
            get { return onViewerAdded; }
        }

        /// <summary>Relays <see cref="Tentacle.OnStreamEvent"/>.</summary>
        public UnityEvent<StreamEventBase, Viewer> OnStreamEvent
        {
            get { return onStreamEvent; }
        }

        /// <summary>Relays <see cref="Tentacle.OnChatJoin"/>.</summary>
        public UnityEvent<Viewer> OnChatJoin
        {
            get { return onChatJoin; }
        }

        /// <summary>Relays <see cref="Tentacle.OnChatMessage"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessage
        {
            get { return onChatMessage; }
        }

        /// <summary>Relays <see cref="Tentacle.OnChatCommand"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatCommand
        {
            get { return onChatCommand; }
        }

        /// <summary>Relays <see cref="Tentacle.OnChatMessageWithEmojis"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmojis
        {
            get { return onChatMessageWithEmojis; }
        }

        /// <summary>Relays <see cref="Tentacle.OnChatMessageWithEmotes"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChatMessage, Viewer> OnChatMessageWithEmotes
        {
            get { return onChatMessageWithEmotes; }
        }

        /// <summary>Relays <see cref="Tentacle.OnBan"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Ban, Viewer> OnBan
        {
            get { return onBan; }
        }

        /// <summary>Relays <see cref="Tentacle.OnChannelUpdate"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_ChannelUpdate> OnChannelUpdate
        {
            get { return onChannelUpdate; }
        }

        /// <summary>Relays <see cref="Tentacle.OnDonation"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Donation, Viewer> OnDonation
        {
            get { return onDonation; }
        }

        /// <summary>Relays <see cref="Tentacle.OnFollow"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Follow, Viewer> OnFollow
        {
            get { return onFollow; }
        }

        /// <summary>Relays <see cref="Tentacle.OnRedemption"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Redemption, Viewer> OnRedemption
        {
            get { return onRedemption; }
        }

        /// <summary>Relays <see cref="Tentacle.OnSubscription"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_Subscription, Viewer> OnSubscription
        {
            get { return onSubscription; }
        }

        /// <summary>Relays <see cref="Tentacle.OnSubscriptionGift"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_SubscriptionGift, Viewer> OnSubscriptionGift
        {
            get { return onSubscriptionGift; }
        }

        /// <summary>Relays <see cref="Tentacle.OnSubscriptionRenewal"/>.</summary>
        public UnityEvent<StreamEvent_Anywhere_SubscriptionRenewal, Viewer> OnSubscriptionRenewal
        {
            get { return onSubscriptionRenewal; }
        }

        /// <summary>Relays <see cref="Tentacle_CustomEvents.OnCustomEvent"/>.</summary>
        public UnityEvent<CustomEvent, Viewer> OnCustomEvent
        {
            get { return onCustomEvent; }
        }

        /// <summary>Relays <see cref="Tentacle_Timers.OnTimerFired"/>.</summary>
        public UnityEvent<TimerEvent> OnTimerFired
        {
            get { return onTimerFired; }
        }

        /// <summary>Starts relaying.</summary>
        private void OnEnable()
        {
            StartRelaying();
        }

        /// <summary>Stops relaying.</summary>
        private void OnDisable()
        {
            StopRelaying();
        }

        // Split out of OnEnable and OnDisable for the reason
        // CustomControlComponent.RegisterControl gives: Unity runs the enable
        // lifecycle only in play mode.
        /// <summary>Subscribes to the client. What OnEnable does.</summary>
        internal void StartRelaying()
        {
            if (subscribed != null) return;
            subscribed = TentacleRelay.Client;

            subscribed.OnConnectionStatusChanged += RelayConnectionStatusChanged;
            subscribed.Viewers.OnViewerAdded += RelayViewerAdded;
            subscribed.OnStreamEvent += RelayStreamEvent;
            subscribed.OnChatJoin += RelayChatJoin;
            subscribed.OnChatMessage += RelayChatMessage;
            subscribed.OnChatCommand += RelayChatCommand;
            subscribed.OnChatMessageWithEmojis += RelayChatMessageWithEmojis;
            subscribed.OnChatMessageWithEmotes += RelayChatMessageWithEmotes;
            subscribed.OnBan += RelayBan;
            subscribed.OnChannelUpdate += RelayChannelUpdate;
            subscribed.OnDonation += RelayDonation;
            subscribed.OnFollow += RelayFollow;
            subscribed.OnRedemption += RelayRedemption;
            subscribed.OnSubscription += RelaySubscription;
            subscribed.OnSubscriptionGift += RelaySubscriptionGift;
            subscribed.OnSubscriptionRenewal += RelaySubscriptionRenewal;
            subscribed.CustomEvents.OnCustomEvent += RelayCustomEvent;
            subscribed.Timers.OnTimerFired += RelayTimerFired;
        }

        /// <summary>
        /// Unsubscribes from the client this relay actually subscribed to. What
        /// OnDisable does.
        ///
        /// Deliberately not through Tentacle.Client: leaving play mode
        /// tears the runtime down before components are disabled, and touching
        /// that property here would build a fresh client - and the GameObject
        /// that pumps it - in the middle of the teardown.
        /// </summary>
        internal void StopRelaying()
        {
            if (subscribed == null) return;

            subscribed.OnConnectionStatusChanged -= RelayConnectionStatusChanged;
            subscribed.Viewers.OnViewerAdded -= RelayViewerAdded;
            subscribed.OnStreamEvent -= RelayStreamEvent;
            subscribed.OnChatJoin -= RelayChatJoin;
            subscribed.OnChatMessage -= RelayChatMessage;
            subscribed.OnChatCommand -= RelayChatCommand;
            subscribed.OnChatMessageWithEmojis -= RelayChatMessageWithEmojis;
            subscribed.OnChatMessageWithEmotes -= RelayChatMessageWithEmotes;
            subscribed.OnBan -= RelayBan;
            subscribed.OnChannelUpdate -= RelayChannelUpdate;
            subscribed.OnDonation -= RelayDonation;
            subscribed.OnFollow -= RelayFollow;
            subscribed.OnRedemption -= RelayRedemption;
            subscribed.OnSubscription -= RelaySubscription;
            subscribed.OnSubscriptionGift -= RelaySubscriptionGift;
            subscribed.OnSubscriptionRenewal -= RelaySubscriptionRenewal;
            subscribed.CustomEvents.OnCustomEvent -= RelayCustomEvent;
            subscribed.Timers.OnTimerFired -= RelayTimerFired;
            subscribed = null;
        }

        private void RelayConnectionStatusChanged(ConnectionStatus status) { TentacleRelay.Invoke(onConnectionStatusChanged, status); }

        private void RelayViewerAdded(Viewer viewer) { TentacleRelay.Invoke(onViewerAdded, viewer); }

        private void RelayStreamEvent(StreamEventBase e, Viewer v) { TentacleRelay.Invoke(onStreamEvent, e, v); }

        private void RelayChatJoin(Viewer viewer) { TentacleRelay.Invoke(onChatJoin, viewer); }

        private void RelayChatMessage(StreamEvent_Anywhere_ChatMessage e, Viewer v) { TentacleRelay.Invoke(onChatMessage, e, v); }

        private void RelayChatCommand(StreamEvent_Anywhere_ChatMessage e, Viewer v) { TentacleRelay.Invoke(onChatCommand, e, v); }

        private void RelayChatMessageWithEmojis(StreamEvent_Anywhere_ChatMessage e, Viewer v) { TentacleRelay.Invoke(onChatMessageWithEmojis, e, v); }

        private void RelayChatMessageWithEmotes(StreamEvent_Anywhere_ChatMessage e, Viewer v) { TentacleRelay.Invoke(onChatMessageWithEmotes, e, v); }

        private void RelayBan(StreamEvent_Anywhere_Ban e, Viewer v) { TentacleRelay.Invoke(onBan, e, v); }

        private void RelayChannelUpdate(StreamEvent_Anywhere_ChannelUpdate e) { TentacleRelay.Invoke(onChannelUpdate, e); }

        private void RelayDonation(StreamEvent_Anywhere_Donation e, Viewer v) { TentacleRelay.Invoke(onDonation, e, v); }

        private void RelayFollow(StreamEvent_Anywhere_Follow e, Viewer v) { TentacleRelay.Invoke(onFollow, e, v); }

        private void RelayRedemption(StreamEvent_Anywhere_Redemption e, Viewer v) { TentacleRelay.Invoke(onRedemption, e, v); }

        private void RelaySubscription(StreamEvent_Anywhere_Subscription e, Viewer v) { TentacleRelay.Invoke(onSubscription, e, v); }

        private void RelaySubscriptionGift(StreamEvent_Anywhere_SubscriptionGift e, Viewer v) { TentacleRelay.Invoke(onSubscriptionGift, e, v); }

        private void RelaySubscriptionRenewal(StreamEvent_Anywhere_SubscriptionRenewal e, Viewer v) { TentacleRelay.Invoke(onSubscriptionRenewal, e, v); }

        private void RelayCustomEvent(CustomEvent e, Viewer v) { TentacleRelay.Invoke(onCustomEvent, e, v); }

        private void RelayTimerFired(TimerEvent e) { TentacleRelay.Invoke(onTimerFired, e); }
    }
}
