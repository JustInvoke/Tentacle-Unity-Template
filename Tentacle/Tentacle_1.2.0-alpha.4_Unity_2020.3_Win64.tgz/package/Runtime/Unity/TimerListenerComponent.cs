// Copyright Tentacle. All Rights Reserved.
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Unreal plugin's UTclTimerListenerComponent: the same list of names,
    // the same OnFired, and the same case rule, with CaseSensitive
    // (bCaseSensitive there) to opt into exact matching.
    /// <summary>
    /// Reacts to the timers you name, authored in the scene: list the names in
    /// the Inspector and wire <see cref="OnFired"/> to whatever should happen.
    ///
    /// It listens while its GameObject is enabled and stops when it is disabled
    /// or destroyed, so there is nothing to subscribe or tear down in code.
    ///
    /// Names are matched case-insensitively by default; turn on
    /// <see cref="CaseSensitive"/> if you need exact matching. The list is read
    /// each time a timer fires, so names added while the game runs take effect
    /// at once.
    /// </summary>
    [AddComponentMenu("Tentacle/Timer Listener")]
    public sealed class TimerListenerComponent : MonoBehaviour
    {
        [Tooltip("The timer names to react to, as they are named in Tentacle.")]
        [SerializeField]
        private List<string> timerNames = new List<string>();

        [Tooltip("Match the names exactly, case included. Off matches them whatever their case.")]
        [SerializeField]
        private bool caseSensitive;

        [Tooltip("Raised for each fire of a listed timer.")]
        [SerializeField]
        private UnityEvent<TimerEvent> onFired = new UnityEvent<TimerEvent>();

        /// <summary>
        /// The surface this listener subscribed to, remembered so it unsubscribes
        /// from the same one - not through Tentacle, which leaving play mode may
        /// already have torn down.
        /// </summary>
        private Tentacle_Timers subscribed;

        // The same seam as CustomEventListenerComponent.CustomEventsOverride.
        /// <summary>
        /// The surface listeners subscribe to, or null for the singleton's -
        /// which is what a game always gets.
        /// </summary>
        internal static Tentacle_Timers TimersOverride;

        /// <summary>The timer names this listener reacts to.</summary>
        public List<string> TimerNames
        {
            get { return timerNames; }
        }

        /// <summary>
        /// Whether names must match exactly, case included. False, the default,
        /// matches them whatever their case.
        /// </summary>
        public bool CaseSensitive
        {
            get { return caseSensitive; }
            set { caseSensitive = value; }
        }

        /// <summary>Raised for each fire of a listed timer.</summary>
        public UnityEvent<TimerEvent> OnFired
        {
            get { return onFired; }
        }

        /// <summary>Starts listening.</summary>
        private void OnEnable()
        {
            StartListening();
        }

        /// <summary>Stops listening.</summary>
        private void OnDisable()
        {
            StopListening();
        }

        // Split out of OnEnable and OnDisable for the reason
        // CustomControlComponent.RegisterControl gives: Unity runs the enable
        // lifecycle only in play mode.
        /// <summary>Subscribes to every timer fire. What OnEnable does.</summary>
        internal void StartListening()
        {
            if (subscribed != null) return;
            subscribed = TimersOverride ?? Tentacle.Timers;
            subscribed.OnTimerFired += HandleTimerFired;
        }

        /// <summary>Unsubscribes from the surface it subscribed to. What OnDisable does.</summary>
        internal void StopListening()
        {
            if (subscribed == null) return;
            subscribed.OnTimerFired -= HandleTimerFired;
            subscribed = null;
        }

        /// <summary>Passes a listed timer's fire on.</summary>
        private void HandleTimerFired(TimerEvent fired)
        {
            if (fired == null || !Lists(fired.Name)) return;
            try
            {
                onFired.Invoke(fired);
            }
            catch (Exception exception)
            {
                TentacleLog.Error("Tentacle: a timer listener threw: " + exception);
            }
        }

        /// <summary>Whether <paramref name="name"/> is one of the listed names, under the case rule.</summary>
        private bool Lists(string name)
        {
            if (string.IsNullOrEmpty(name) || timerNames == null) return false;
            var comparison = caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            foreach (var listed in timerNames)
            {
                if (string.Equals(listed, name, comparison)) return true;
            }
            return false;
        }
    }
}
