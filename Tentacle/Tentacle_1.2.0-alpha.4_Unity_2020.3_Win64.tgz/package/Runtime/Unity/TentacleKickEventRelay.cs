// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Kick counterpart of TentacleEventRelay, which says why the relays are
    // split per surface: the entry point and Kick both have an OnChatMessage. Of
    // Tentacle_Kick's per-kind events it relays only the chat message, as
    // TentacleTwitchEventRelay relays only Twitch's.
    /// <summary>
    /// Kick's chat message as a UnityEvent you fill in from the Inspector.
    ///
    /// The UnityEvent carries the name and the arguments of the
    /// <see cref="Tentacle_Kick"/> event it relays, <c>OnChatMessage</c>. Every
    /// other Kick event, such as <c>OnChannelFollow</c>, is for code: subscribe
    /// to it on <c>Tentacle.Kick</c>, or match the kind in a listener on the
    /// <see cref="TentacleEventRelay"/>'s <c>OnStreamEvent</c>, which carries
    /// every one of them.
    ///
    /// Subscriptions are made in OnEnable and dropped in OnDisable, so a disabled
    /// object costs nothing and a destroyed one leaves no dangling handler.
    /// </summary>
    [AddComponentMenu("Tentacle/Tentacle Kick Event Relay")]
    public sealed class TentacleKickEventRelay : MonoBehaviour
    {
        [Tooltip("Raised for every Kick chat message, commands included.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Kick_ChatMessage, Viewer> onChatMessage =
            new UnityEvent<StreamEvent_Kick_ChatMessage, Viewer>();

        /// <summary>The Kick surface this relay subscribed to, so it unsubscribes from the same one.</summary>
        private Tentacle_Kick subscribed;

        /// <summary>Relays <see cref="Tentacle_Kick.OnChatMessage"/>.</summary>
        public UnityEvent<StreamEvent_Kick_ChatMessage, Viewer> OnChatMessage
        {
            get { return onChatMessage; }
        }

        /// <summary>Starts relaying.</summary>
        private void OnEnable()
        {
            StartRelaying();
        }

        /// <summary>Stops relaying.</summary>
        private void OnDisable()
        {
            StopRelaying();
        }

        // Split out of OnEnable and OnDisable for the reason
        // CustomControlComponent.RegisterControl gives: Unity runs the enable
        // lifecycle only in play mode.
        /// <summary>Subscribes to the client's Kick surface. What OnEnable does.</summary>
        internal void StartRelaying()
        {
            if (subscribed != null) return;
            subscribed = TentacleRelay.Client.Kick;

            subscribed.OnChatMessage += RelayChatMessage;
        }

        /// <summary>
        /// Unsubscribes from the surface this relay actually subscribed to, never
        /// through Tentacle, for the reason <see cref="TentacleEventRelay"/> gives.
        /// What OnDisable does.
        /// </summary>
        internal void StopRelaying()
        {
            if (subscribed == null) return;

            subscribed.OnChatMessage -= RelayChatMessage;
            subscribed = null;
        }

        private void RelayChatMessage(StreamEvent_Kick_ChatMessage e, Viewer v) { TentacleRelay.Invoke(onChatMessage, e, v); }
    }
}
