// Copyright Tentacle. All Rights Reserved.

using System;
#if TENTACLE_TEXTMESHPRO
using TMPro;
#endif
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Tcl
{
    // Unreal's UTclSignInButton and Godot's TclSignInButton. A component rather
    // than a Button of its own, so it goes on the game's own styled Button, or on
    // nothing at all, with no look of its own to fight.
    /// <summary>
    /// Makes a button sign the player in to one platform. Add it to any Button
    /// (uGUI or TextMeshPro) and style the button however you like.
    ///
    /// A click does what the button's state says: Connect signs the player in and
    /// opens the sign-in page, Cancel abandons a sign-in in progress, and
    /// Disconnect signs the account out. The first text inside the button (Text
    /// or TextMeshPro) reads the label, unless <see cref="SetLabel"/> is off, and
    /// the button is not interactable while it cannot be pressed. The label,
    /// status, and detail are also UnityEvents, to wire to text of your own, and
    /// <see cref="OnStateChanged"/> hands code the whole state.
    ///
    /// Only Tentacle embedded in the game signs players in; with the Tentacle app
    /// the button stays not interactable.
    /// </summary>
    [AddComponentMenu("Tentacle/Sign In Button")]
    [DisallowMultipleComponent]
    public sealed class SignInButton : MonoBehaviour
    {
        [Tooltip("The platform the button signs in to. Read when the button is enabled.")]
        public StreamPlatform Platform = StreamPlatform.Twitch;

        [Tooltip("Open the sign-in page in the player's browser when signing in needs it. Off, open State.Url yourself.")]
        public bool OpenBrowser = true;

        [Tooltip("Keep the first text inside this object (Text or TextMeshPro) reading the label: Connect, Cancel, Disconnect, or Sign in again.")]
        public bool SetLabel = true;

        [Tooltip("Make the Button on this object not interactable while it cannot be pressed: with the Tentacle app, and while Tentacle starts.")]
        public bool DisableWhenUnavailable = true;

        [Header("Events")]
        [Tooltip("The label changed: Connect, Cancel, Disconnect, or Sign in again. Also raised once as the button starts.")]
        public UnityEvent<string> OnLabelChanged = new UnityEvent<string>();

        [Tooltip("The status line changed, such as \"Connected as Streamer\". Also raised once as the button starts.")]
        public UnityEvent<string> OnStatusChanged = new UnityEvent<string>();

        [Tooltip("The detail line changed: Twitch's code and the time left while signing in, or why a sign-in failed. Often empty.")]
        public UnityEvent<string> OnDetailChanged = new UnityEvent<string>();

        /// <summary>Raised once as the button starts, and whenever what it shows changes, the countdown while signing in included.</summary>
        public event Action<SignInState> OnStateChanged;

        // The same seam as ConnectionsWidget.ConnectionsOverride: it lets the
        // edit-mode tests drive the button against a client of their own.
        /// <summary>A connections surface every button uses instead of <see cref="Tentacle.Connections"/>.</summary>
        internal static Tentacle_Connections ConnectionsOverride;

        private SignInController controller;
        private Button button;
        private SignInState shown;

        /// <summary>What the button shows now, or null while it is disabled.</summary>
        public SignInState State
        {
            get { return controller != null ? controller.State : null; }
        }

        /// <summary>The controller behind the button, for its SignIn, Cancel, Disconnect, and OpenPage; null while it is disabled.</summary>
        public SignInController Controller
        {
            get { return controller; }
        }

        /// <summary>Does what the label says: sign in, cancel, or disconnect. A Button on this object calls it when clicked.</summary>
        public void Press()
        {
            if (controller != null) controller.Press();
        }

        private void OnEnable()
        {
            StartListening();
        }

        private void OnDisable()
        {
            StopListening();
        }

        /// <summary>Follows the platform and takes the Button's clicks; what OnEnable does.</summary>
        internal void StartListening()
        {
            if (controller != null) return;
            var connections = ConnectionsOverride ?? Tentacle.Connections;
            controller = connections.CreateSignInController(Platform, OpenBrowser);
            controller.OnStateChanged += Show;
            button = GetComponent<Button>();
            if (button != null) button.onClick.AddListener(Press);
            shown = null;
            Show(controller.State);
        }

        /// <summary>Stops following the platform and taking clicks; what OnDisable does.</summary>
        internal void StopListening()
        {
            if (controller == null) return;
            // Not ?.: a destroyed Unity object compares equal to null only through ==.
            if (button != null) button.onClick.RemoveListener(Press);
            controller.OnStateChanged -= Show;
            controller.Dispose();
            controller = null;
        }

        private void Show(SignInState state)
        {
            if (SetLabel) WriteLabel(state.Label);
            if (DisableWhenUnavailable && button != null) button.interactable = state.CanPress;

            var previous = shown;
            shown = state;
            if (previous == null || previous.Label != state.Label) Invoke(OnLabelChanged, state.Label);
            if (previous == null || previous.Status != state.Status) Invoke(OnStatusChanged, state.Status);
            if (previous == null || previous.Detail != state.Detail) Invoke(OnDetailChanged, state.Detail);
            TentacleHandlers.Raise(OnStateChanged, state, "sign-in button");
        }

        /// <summary>Writes the label into the first Text or TextMeshPro text inside this object, in hierarchy order.</summary>
        private void WriteLabel(string label)
        {
            foreach (var graphic in GetComponentsInChildren<Graphic>(true))
            {
                // TENTACLE_TEXTMESHPRO is the asmdef's version define: on when the
                // project has TextMeshPro, a package of its own before Unity 6
                // and part of ugui 2.0 from it.
#if TENTACLE_TEXTMESHPRO
                var tmp = graphic as TMP_Text;
                if (tmp != null)
                {
                    tmp.text = label;
                    return;
                }
#endif
                var text = graphic as Text;
                if (text != null)
                {
                    text.text = label;
                    return;
                }
            }
        }

        /// <summary>Invokes a UnityEvent, so a listener that throws is reported rather than stopping the others' updates.</summary>
        private static void Invoke(UnityEvent<string> unityEvent, string value)
        {
            if (unityEvent == null) return;
            try
            {
                unityEvent.Invoke(value);
            }
            catch (Exception exception)
            {
                Debug.LogException(exception);
            }
        }
    }
}
