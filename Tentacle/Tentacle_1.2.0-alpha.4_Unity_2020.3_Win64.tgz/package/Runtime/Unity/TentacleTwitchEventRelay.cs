// Copyright Tentacle. All Rights Reserved.
using UnityEngine;
using UnityEngine.Events;

namespace Tcl
{
    // The Twitch counterpart of TentacleEventRelay, which says why the relays are
    // split per surface. Of Tentacle_Twitch's sixty-one per-kind events it relays
    // only the chat message, the one a scene most often wires up; the rest stay
    // code-only, since a UnityEvent each would bury the Inspector and the entry
    // point relay's OnStreamEvent already carries every one of them. It also
    // relays the one event of Tentacle_TwitchExtras, which the game raises.
    /// <summary>
    /// Twitch's chat message and the end of an incoming raid as UnityEvents you
    /// fill in from the Inspector.
    ///
    /// Each UnityEvent carries the name and the arguments of the event it
    /// relays: <see cref="Tentacle_Twitch"/>'s <c>OnChannelChatMessage</c>, and
    /// <see cref="Tentacle_TwitchExtras"/>'s <c>OnIncomingRaidEnded</c>. Every
    /// other Twitch event, such as <c>OnChannelCheer</c>, is for code: subscribe
    /// to it on <c>Tentacle.Twitch</c>, or match the kind in a listener on the
    /// <see cref="TentacleEventRelay"/>'s <c>OnStreamEvent</c>, which carries
    /// every one of them.
    ///
    /// Subscriptions are made in OnEnable and dropped in OnDisable, so a disabled
    /// object costs nothing and a destroyed one leaves no dangling handler.
    /// </summary>
    [AddComponentMenu("Tentacle/Tentacle Twitch Event Relay")]
    public sealed class TentacleTwitchEventRelay : MonoBehaviour
    {
        [Tooltip("Raised for every Twitch chat message, commands included.")]
        [SerializeField]
        private UnityEvent<StreamEvent_Twitch_ChatMessage, Viewer> onChannelChatMessage =
            new UnityEvent<StreamEvent_Twitch_ChatMessage, Viewer>();

        [Tooltip("Raised when the game calls Tentacle.Twitch.Extras.EndIncomingRaid, since Twitch sends no raid-over event.")]
        [SerializeField]
        private UnityEvent onIncomingRaidEnded = new UnityEvent();

        /// <summary>The Twitch surface this relay subscribed to, so it unsubscribes from the same one.</summary>
        private Tentacle_Twitch subscribed;

        /// <summary>Relays <see cref="Tentacle_Twitch.OnChannelChatMessage"/>.</summary>
        public UnityEvent<StreamEvent_Twitch_ChatMessage, Viewer> OnChannelChatMessage
        {
            get { return onChannelChatMessage; }
        }

        /// <summary>Relays <see cref="Tentacle_TwitchExtras.OnIncomingRaidEnded"/>.</summary>
        public UnityEvent OnIncomingRaidEnded
        {
            get { return onIncomingRaidEnded; }
        }

        /// <summary>Starts relaying.</summary>
        private void OnEnable()
        {
            StartRelaying();
        }

        /// <summary>Stops relaying.</summary>
        private void OnDisable()
        {
            StopRelaying();
        }

        // Split out of OnEnable and OnDisable for the reason
        // CustomControlComponent.RegisterControl gives: Unity runs the enable
        // lifecycle only in play mode.
        /// <summary>Subscribes to the client's Twitch surface and its extras. What OnEnable does.</summary>
        internal void StartRelaying()
        {
            if (subscribed != null) return;
            subscribed = TentacleRelay.Client.Twitch;

            subscribed.OnChannelChatMessage += RelayChannelChatMessage;
            subscribed.Extras.OnIncomingRaidEnded += RelayIncomingRaidEnded;
        }

        /// <summary>
        /// Unsubscribes from the surface this relay actually subscribed to, never
        /// through Tentacle, for the reason <see cref="TentacleEventRelay"/> gives.
        /// What OnDisable does.
        /// </summary>
        internal void StopRelaying()
        {
            if (subscribed == null) return;

            subscribed.OnChannelChatMessage -= RelayChannelChatMessage;
            subscribed.Extras.OnIncomingRaidEnded -= RelayIncomingRaidEnded;
            subscribed = null;
        }

        private void RelayChannelChatMessage(StreamEvent_Twitch_ChatMessage e, Viewer v) { TentacleRelay.Invoke(onChannelChatMessage, e, v); }

        private void RelayIncomingRaidEnded() { TentacleRelay.Invoke(onIncomingRaidEnded); }
    }
}
