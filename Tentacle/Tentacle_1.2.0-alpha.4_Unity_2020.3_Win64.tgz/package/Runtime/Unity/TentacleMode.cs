// Copyright Tentacle. All Rights Reserved.

using System;
using System.Collections.Generic;

namespace Tcl
{
    /// <summary>Where the game finds Tentacle.</summary>
    public enum TentacleMode
    {
        /// <summary>
        /// Paired with the Tentacle app running on the same machine, which holds
        /// the accounts and everything configured in it.
        /// </summary>
        Paired,

        /// <summary>
        /// Run Tentacle inside the game itself, with no app needed: the game
        /// signs the player in to the streaming platforms (see
        /// <see cref="Tentacle_Connections"/>) and receives their events
        /// directly, and ships its config as files exported from the Tentacle
        /// app. Custom controls do not work in this mode.
        /// </summary>
        Embedded,

        // Paired's name before 1.2.0-alpha.3, kept so a script that names it
        // still compiles, with a warning. A settings asset stores the mode as its
        // number, so a saved App loads as Paired, and the Inspector leaves an
        // obsolete value out of the menu.
        /// <summary>The name <see cref="Paired"/> had before.</summary>
        [Obsolete("Renamed Paired.")]
        App = Paired,
    }

    // Unreal's TclTentacleMode::ResolvesToEmbedded. Not part of the surface:
    // a game asks Tentacle.IsEmbedded.
    /// <summary>Where the settings' modes put Tentacle.</summary>
    internal static class TentacleModeResolver
    {
        private const string Argument = "-tentacle-mode";

        /// <summary>
        /// Whether Tentacle runs inside the game: <paramref name="editorMode"/>
        /// in the Editor, <paramref name="buildMode"/> in a build.
        /// <c>-tentacle-mode=paired</c> or <c>-tentacle-mode embedded</c> in
        /// <paramref name="commandLine"/> wins over both, so a build can be
        /// tested against the app; any other value is ignored with a warning.
        /// </summary>
        internal static bool ResolvesToEmbedded(TentacleMode editorMode, TentacleMode buildMode, bool inEditor, IReadOnlyList<string> commandLine)
        {
            var overridden = Override(commandLine);
            if (overridden.HasValue) return overridden.Value;
            return (inEditor ? editorMode : buildMode) == TentacleMode.Embedded;
        }

        /// <summary>The command line's choice, or null when it makes none.</summary>
        private static bool? Override(IReadOnlyList<string> commandLine)
        {
            if (commandLine == null) return null;
            for (var i = 0; i < commandLine.Count; i++)
            {
                var argument = commandLine[i] ?? "";
                string value;
                if (argument.StartsWith(Argument + "=", StringComparison.OrdinalIgnoreCase))
                    value = argument.Substring(Argument.Length + 1);
                else if (string.Equals(argument, Argument, StringComparison.OrdinalIgnoreCase))
                    value = i + 1 < commandLine.Count ? commandLine[i + 1] : "";
                else
                    continue;

                // "app" is what Paired mode was called before 1.2.0-alpha.3.
                if (string.Equals(value, "paired", StringComparison.OrdinalIgnoreCase) || string.Equals(value, "app", StringComparison.OrdinalIgnoreCase)) return false;
                if (string.Equals(value, "embedded", StringComparison.OrdinalIgnoreCase)) return true;
                TentacleLog.Warn("Tentacle: ignoring " + Argument + " " + value + "; it takes paired or embedded");
                return null;
            }
            return null;
        }
    }
}
