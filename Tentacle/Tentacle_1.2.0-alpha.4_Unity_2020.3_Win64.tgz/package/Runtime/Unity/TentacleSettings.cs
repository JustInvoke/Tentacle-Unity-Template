// Copyright Tentacle. All Rights Reserved.
using UnityEngine;

namespace Tcl
{
    // The fields the Unreal plugin's ATentacle also has carry its names
    // (AutoConnect, SessionLabel, DataDirectoryOverride); the rest follow them.
    /// <summary>
    /// Project-wide Tentacle settings.
    ///
    /// Optional by design: with no asset in the project the defaults below apply
    /// and the plugin connects to a locally running Tentacle with no setup at
    /// all. Create one (Assets &gt; Create &gt; Tentacle &gt; Settings) inside any
    /// <c>Resources</c> folder, named <c>TentacleSettings</c>, to change them.
    ///
    /// Deliberately small. Tentacle publishes where it is listening, so there is
    /// no host or port to configure; the fields are the handful of choices a
    /// project genuinely differs on. The ones that matter most are
    /// <see cref="EditorMode"/> and <see cref="BuildMode"/>: whether the game
    /// connects to the Tentacle app, or runs Tentacle inside itself, in the
    /// Editor and in a build. The one credential, <see cref="ConnectionPassword"/>,
    /// is empty unless Tentacle's user set a connection password.
    /// </summary>
    [CreateAssetMenu(fileName = ResourceName, menuName = "Tentacle/Settings")]
    public sealed class TentacleSettings : ScriptableObject
    {
        /// <summary>Name the asset must have inside a Resources folder to be found.</summary>
        public const string ResourceName = "TentacleSettings";

        // The Tentacle app writes here when exporting to a Unity project
        // (ENGINE_CONFIG_FOLDERS in packages/common/src/general/config-export.ts),
        // which packages/app/tests/config-folders.test.ts holds this to.
        /// <summary>
        /// Where <see cref="ConfigFolder"/> points by default: the Tentacle folder
        /// under <c>Assets/StreamingAssets</c>, where the Tentacle app's Data
        /// &gt; Export puts the files for a Unity project.
        /// </summary>
        public const string DefaultConfigFolder = "Tentacle";

        [Header("Connection")]
        [Tooltip("Where Tentacle runs in Play mode. Paired connects to the Tentacle app on this machine. Embedded runs Tentacle inside the game.")]
        public TentacleMode EditorMode = TentacleMode.Paired;

        [Tooltip("Where Tentacle runs in a build. Paired connects to the Tentacle app on the player's machine. Embedded runs Tentacle inside the game, so players need no app. -tentacle-mode paired or embedded on the command line wins over it.")]
        public TentacleMode BuildMode = TentacleMode.Paired;

        [Tooltip("Connect as soon as the game starts. Turn off to call Tentacle.Connect() yourself.")]
        public bool AutoConnect = true;

        [Tooltip("Name shown for this game in Tentacle's session list. Empty uses the product name.")]
        public string SessionLabel = "";

        [Tooltip("Tentacle's data folder, where its sidecar.json lives. Empty uses the platform default. Paired mode only.")]
        public string DataDirectoryOverride = "";

        [Tooltip("Tentacle's connection password, for a Tentacle whose user set one under Settings > System > Connection Password. Empty sends none, which is all Tentacle asks for until a password is set. This asset ships with the game, so a game for other people sets Tentacle.ConnectionPassword from its own settings screen instead. Paired mode only.")]
        public string ConnectionPassword = "";

        [Header("Embedded")]
        [Tooltip("Where embedded Tentacle keeps what it remembers between runs, such as the signed-in accounts. Empty uses a Tentacle folder in the game's persistent data.")]
        public string EmbeddedDataDirectory = "";

        [Tooltip("Your own Twitch application's client ID, to sign in with instead of Tentacle's. Empty uses Tentacle's.")]
        public string TwitchClientId = "";

        [Tooltip("The folder under Assets/StreamingAssets that Tentacle reads its config files from: the timers, custom events, viewer properties, and bot commands the Tentacle app's Data > Export writes there. Every .json file in it is applied when Tentacle starts. A full path reads from that folder instead.")]
        public string ConfigFolder = DefaultConfigFolder;

        [Header("Reconnect")]
        [Tooltip("Delay before the first retry, in seconds.")]
        [Min(0f)]
        public float ReconnectInitialDelaySeconds = 1f;

        [Tooltip("Longest the retry delay is allowed to grow to, in seconds.")]
        [Min(0f)]
        public float ReconnectMaxDelaySeconds = 30f;

        [Header("Behaviour")]
        [Tooltip("Load the viewer-property registry as soon as a session opens. Needed for property reads by name.")]
        public bool RefreshRegistryOnConnect = true;

        [Tooltip("How many recent stream events are remembered, so an event that arrives twice is delivered once.")]
        [Min(1)]
        public int StreamDeduplicationWindow = TentacleDeduplicator.DefaultCapacity;

        [Header("Diagnostics")]
        [Tooltip("Send Tentacle's own diagnostics to the Unity console.")]
        public bool LogToConsole = true;

        [Tooltip("Include routine lifecycle messages (connected, disconnected) as well as problems.")]
        public bool LogLifecycle = true;

        /// <summary>
        /// The defaults instance handed out while the project has no asset. Kept
        /// rather than made per call: CreateInstance produces a real
        /// ScriptableObject that nothing destroys, and no asset is the normal
        /// state, so a fresh one per call would leak one object per call and
        /// Unity would report them all at domain unload. A domain reload clears
        /// this along with everything else.
        /// </summary>
        private static TentacleSettings defaults;

        /// <summary>
        /// The settings asset from Resources, or a defaults instance when the
        /// project has none. Never null: a missing asset is the normal state, not
        /// a misconfiguration.
        /// </summary>
        public static TentacleSettings LoadOrDefault()
        {
            var asset = Resources.Load<TentacleSettings>(ResourceName);
            if (asset != null) return asset;

            if (defaults == null) defaults = CreateInstance<TentacleSettings>();
            return defaults;
        }
    }
}
